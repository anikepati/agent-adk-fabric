"""
Main Entry Point — CLI and programmatic API.

Usage:
    python main.py --list
    python main.py -w create_parent_business_unit -u https://org.crm.dynamics.com \\
        -p '{"bu_name":"ACME","division":"NA","cost_center":"CC-1001"}'
    python main.py --pipeline pipeline.json -u https://org.crm.dynamics.com
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Optional

from orchestrator import WorkflowOrchestrator, WorkflowResult


def execute_workflow(
    workflow_name: str,
    params: dict,
    base_url: str = "",
    config_dir: str = "./config",
    skills_file: Optional[str] = None,
    user_id: str = "default",
    log_level: str = "INFO",
    json_logs: bool = False,
) -> WorkflowResult:
    """Programmatic API — execute a single workflow."""
    orch = WorkflowOrchestrator.from_config(
        config_dir=config_dir,
        skills_file=skills_file,
        log_level=log_level,
        json_logs=json_logs,
    )
    return orch.execute(
        workflow_name=workflow_name,
        params=params,
        base_url=base_url,
        user_id=user_id,
    )


def execute_pipeline(
    steps: list[dict],
    base_url: str = "",
    config_dir: str = "./config",
    stop_on_failure: bool = True,
) -> list[WorkflowResult]:
    """Execute multiple workflows sequentially."""
    orch = WorkflowOrchestrator.from_config(
        config_dir=config_dir, log_level="INFO", json_logs=False,
    )
    results = []
    for step in steps:
        r = orch.execute(
            workflow_name=step["name"],
            params=step["params"],
            base_url=base_url,
        )
        results.append(r)
        if not r.success and stop_on_failure:
            break
    return results


# ═══════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser(
        description="Browser Automation Agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("-w", "--workflow", help="Workflow key")
    ap.add_argument("-p", "--params", default="{}", help="JSON params")
    ap.add_argument("-u", "--base-url", default="", help="Base URL")
    ap.add_argument("-c", "--config-dir", default="./config")
    ap.add_argument("-s", "--skills-file", default=None)
    ap.add_argument("-l", "--list", action="store_true", help="List workflows")
    ap.add_argument("--pipeline", help="Path to pipeline JSON file")
    ap.add_argument("--log-level", default="INFO")
    ap.add_argument("--json-logs", action="store_true")
    args = ap.parse_args()

    if args.list:
        orch = WorkflowOrchestrator.from_config(
            config_dir=args.config_dir,
            skills_file=args.skills_file,
            log_level="WARNING",
            json_logs=False,
        )
        for w in orch.list_workflows():
            print(f"\n  {w['key']}  (v{w['version']})")
            print(f"    {w['description']}")
            print(f"    params: {', '.join(w['params_required'])}")
        print()
        return

    if args.pipeline:
        with open(args.pipeline) as f:
            steps = json.load(f)
        results = execute_pipeline(steps, base_url=args.base_url, config_dir=args.config_dir)
        print(f"\n{'='*60}")
        for i, r in enumerate(results):
            print(f"\n[{i + 1}] {steps[i]['name']}")
            print(r.summary())
        ok = all(r.success for r in results)
        print(f"\nPipeline: {'PASS' if ok else 'FAIL'}")
        print(f"{'='*60}")
        sys.exit(0 if ok else 1)

    if not args.workflow:
        ap.print_help()
        sys.exit(1)

    try:
        params = json.loads(args.params)
    except json.JSONDecodeError as exc:
        print(f"Invalid --params JSON: {exc}", file=sys.stderr)
        sys.exit(1)

    result = execute_workflow(
        workflow_name=args.workflow,
        params=params,
        base_url=args.base_url,
        config_dir=args.config_dir,
        skills_file=args.skills_file,
        log_level=args.log_level,
        json_logs=args.json_logs,
    )

    print(f"\n{'='*60}")
    print(result.summary())
    print(f"{'='*60}")
    sys.exit(0 if result.success else 1)


if __name__ == "__main__":
    main()
