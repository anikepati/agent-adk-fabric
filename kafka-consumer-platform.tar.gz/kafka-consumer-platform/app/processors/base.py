"""
Base processor abstract class. Every processor implements this contract.
The framework wraps all processors uniformly with timeout, circuit breaker,
retry, tracing, and metrics.
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any

from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult

logger = logging.getLogger(__name__)


class ProcessorContext:
    """Injected by the framework into every processor at instantiation."""

    def __init__(
        self,
        cluster_name: str,
        topic: str,
        config: dict[str, Any],
    ) -> None:
        self.cluster_name = cluster_name
        self.topic = topic
        self.config = config
        self.logger = logging.getLogger(f"processor.{topic}")


class BaseProcessor(ABC):
    """Abstract base class for all message processors."""

    def __init__(self, config: dict[str, Any], context: ProcessorContext) -> None:
        self.config = config
        self.context = context
        self.logger = context.logger

    @abstractmethod
    async def process(self, message: ConsumerMessage) -> ProcessorResult:
        """Process a single message. Must return a ProcessorResult."""
        ...

    async def health_check(self) -> bool:
        """Optional health check. Override for processors with external dependencies."""
        return True

    async def startup(self) -> None:
        """Called once after instantiation. Override for initialization logic."""
        pass

    async def shutdown(self) -> None:
        """Called during graceful shutdown. Override for cleanup logic."""
        pass

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(topic={self.context.topic!r})"
