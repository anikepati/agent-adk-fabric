"""
Processor result type — explicit status returned by every processor.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class ResultStatus(str, Enum):
    SUCCESS = "success"
    RETRY = "retry"
    DLQ = "dlq"
    SKIP = "skip"


@dataclass(slots=True)
class ProcessorResult:
    status: ResultStatus
    output: Optional[dict[str, Any]] = None
    error: Optional[str] = None
    exception: Optional[Exception] = None

    @classmethod
    def success(cls, output: dict[str, Any] | None = None) -> ProcessorResult:
        return cls(status=ResultStatus.SUCCESS, output=output)

    @classmethod
    def retry(cls, error: str, exception: Exception | None = None) -> ProcessorResult:
        return cls(status=ResultStatus.RETRY, error=error, exception=exception)

    @classmethod
    def dlq(cls, error: str, exception: Exception | None = None) -> ProcessorResult:
        return cls(status=ResultStatus.DLQ, error=error, exception=exception)

    @classmethod
    def skip(cls, reason: str = "") -> ProcessorResult:
        return cls(status=ResultStatus.SKIP, error=reason)

    @property
    def is_success(self) -> bool:
        return self.status == ResultStatus.SUCCESS

    @property
    def is_retriable(self) -> bool:
        return self.status == ResultStatus.RETRY
