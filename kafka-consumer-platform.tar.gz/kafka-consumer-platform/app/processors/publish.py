"""
Publish processor: produce transformed message to another Kafka topic.
"""
from __future__ import annotations

import json
from typing import Any

from confluent_kafka import Producer

from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult
from app.processors.base import BaseProcessor, ProcessorContext
from app.processors.registry import register_processor


@register_processor("publish")
class PublishProcessor(BaseProcessor):

    def __init__(self, config: dict[str, Any], context: ProcessorContext) -> None:
        super().__init__(config, context)
        self._target_topic: str = config["topic"]
        self._key_field: str | None = config.get("key_field")
        self._producer: Producer | None = None
        # Producer config can be supplied; if not, will need to be set by bootstrap
        self._producer_config: dict[str, Any] = config.get("producer_config", {})

    def set_producer(self, producer: Producer) -> None:
        """Called by bootstrap to inject the cluster's shared producer."""
        self._producer = producer

    async def process(self, message: ConsumerMessage) -> ProcessorResult:
        if self._producer is None:
            return ProcessorResult.dlq("Publish processor has no producer configured")

        try:
            value = message.value
            if isinstance(value, dict):
                value = json.dumps(value).encode()
            elif isinstance(value, str):
                value = value.encode()

            key = None
            if self._key_field and isinstance(message.value, dict):
                key_val = message.value.get(self._key_field)
                if key_val is not None:
                    key = str(key_val).encode()

            self._producer.produce(
                topic=self._target_topic,
                key=key or message.key,
                value=value,
                headers=[
                    ("x-source-topic", message.topic.encode()),
                    ("x-source-offset", str(message.offset).encode()),
                ],
            )
            self._producer.poll(0)

            return ProcessorResult.success({"target_topic": self._target_topic})

        except BufferError:
            return ProcessorResult.retry("Producer buffer full")
        except Exception as e:
            return ProcessorResult.retry(f"Publish error: {e}", e)

    async def shutdown(self) -> None:
        if self._producer:
            self._producer.flush(timeout=10)
