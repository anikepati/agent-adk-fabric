"""
Fanout processor: run N processors in parallel on the same message.
All targets receive a copy of the message. Results are collected.
Overall result is SUCCESS only if all targets succeed.
"""
from __future__ import annotations

import asyncio
import copy
import logging
from typing import Any

from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult, ResultStatus
from app.processors.base import BaseProcessor, ProcessorContext
from app.processors.registry import create_processor, register_processor

logger = logging.getLogger(__name__)


@register_processor("fanout")
class FanoutProcessor(BaseProcessor):

    def __init__(self, config: dict[str, Any], context: ProcessorContext) -> None:
        super().__init__(config, context)
        self._targets: list[BaseProcessor] = []
        self._target_configs: list[dict[str, Any]] = config.get("targets", [])

    async def startup(self) -> None:
        for i, target_conf in enumerate(self._target_configs):
            target_type = target_conf["type"]
            target_config = target_conf.get("config", {})
            target_processor = create_processor(
                processor_type=target_type,
                config=target_config,
                cluster_name=self.context.cluster_name,
                topic=f"{self.context.topic}:fanout-{i}:{target_type}",
            )
            await target_processor.startup()
            self._targets.append(target_processor)

    async def process(self, message: ConsumerMessage) -> ProcessorResult:
        if not self._targets:
            await self.startup()

        # Run all targets concurrently
        tasks = []
        for target in self._targets:
            # Each target gets its own copy of the message value
            msg_copy = copy.copy(message)
            if isinstance(message.value, dict):
                msg_copy.value = copy.deepcopy(message.value)
            tasks.append(target.process(msg_copy))

        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Evaluate results
        failures = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                failures.append(
                    f"Target {i} ({self._targets[i].__class__.__name__}): {result}"
                )
            elif result.status not in (ResultStatus.SUCCESS, ResultStatus.SKIP):
                failures.append(
                    f"Target {i} ({self._targets[i].__class__.__name__}): {result.error}"
                )

        if failures:
            error = "; ".join(failures)
            # If any target is retriable, mark as retry
            has_retriable = any(
                isinstance(r, ProcessorResult) and r.status == ResultStatus.RETRY
                for r in results
            )
            if has_retriable:
                return ProcessorResult.retry(f"Fanout partial failure: {error}")
            return ProcessorResult.dlq(f"Fanout failure: {error}")

        return ProcessorResult.success()

    async def shutdown(self) -> None:
        for target in self._targets:
            try:
                await target.shutdown()
            except Exception as e:
                logger.error(f"Error shutting down fanout target: {e}")
