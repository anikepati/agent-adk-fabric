# Feature: Resumable Sequential Pipeline with AgentGate

**Feature ID**: `resumable-pipeline`
**Status**: Draft
**Owner**: Enterprise AI Architecture
**Constitution**: see `memory/constitution.md`
**ADK Version**: `google-adk >= 1.21.0`

---

## 1. Summary

A sequential agent pipeline built on Google ADK that durably pauses at a
human-in-the-loop gate and resumes — potentially days or weeks later —
exactly where it left off. The pipeline is composed of:

1. A custom `ResumableOrchestrator(BaseAgent)` that walks sub-agents in
   order, skipping any whose `output_key` is already in `session.state`.
2. A custom `AgentGate(BaseAgent)` that pauses the orchestrator by not
   writing its `output_key` until a decision is present in state.
3. Any number of vanilla `LlmAgent` (or `BaseAgent`) instances as
   sub-agents, each declaring an `output_key`.

State durability is delegated entirely to `DatabaseSessionService` (SQLite
for local development; Postgres for production). Resume is initiated by
the caller providing a `session_id` and a decision string.

## 2. Goals and Non-Goals

### Goals

- G1. Pause indefinitely at the gate; resume after arbitrary delay (target:
  40 days) without loss of prior sub-agent outputs.
- G2. Skip already-completed sub-agents on resume; never re-run them.
- G3. Single source of truth for "is this step done?": its `output_key`
  presence in `session.state`.
- G4. Vanilla `LlmAgent`s drop in unmodified as sub-agents.
- G5. Resume by `session_id` + decision payload — no need for the caller
  to know any ADK internal identifiers.
- G6. Denial path halts the pipeline cleanly (no further sub-agents run).

### Non-Goals

- NG1. Parallel/branching execution (sequential only).
- NG2. Custom retry, timeout, audit, or ledger infrastructure on top of
  ADK. If ADK doesn't have it, we don't add it in v1.
- NG3. Resume by anything other than `session_id` (no separate token
  store; no opaque resume tokens).
- NG4. Multi-gate pipelines with multiple distinct pause reasons.
  Supported by construction (any sub-agent that doesn't set its
  `output_key` pauses) but only one gate is exercised in v1.

## 3. Personas and Use Cases

### Persona A — Pipeline Author

Builds the pipeline by composing `LlmAgent`s and one `AgentGate` into
`ResumableOrchestrator(sub_agents=[...])`. No knowledge of ADK
internals beyond `output_key` is required.

### Persona B — Resume Caller

An HTTP API, CLI, or batch job that resumes a paused pipeline. Has only
a `session_id` and a decision string (e.g. "approved").

### Use cases

- UC1. EDR case processing pauses for SAR-review human approval, resumed
  by a compliance officer days later.
- UC2. Mortgage underwriting pipeline pauses for collateral verification
  by a back-office analyst.
- UC3. Long-running KYC pipeline pauses for customer document upload,
  resumed automatically when documents land in object storage.

## 4. Functional Requirements

### 4.1 Orchestration

- **FR-1.** Sub-agents MUST execute in the order declared in
  `sub_agents=[...]`.
- **FR-2.** Before running a sub-agent, the orchestrator MUST check
  `session.state.get(sub.output_key)`. If non-None, the orchestrator MUST
  emit a skip log line and proceed to the next sub-agent without
  invoking the current one.
- **FR-3.** Each sub-agent MUST declare an `output_key`. If a sub-agent
  has no `output_key`, the orchestrator MUST raise a `RuntimeError` at
  the moment it tries to run that sub-agent.
- **FR-4.** After running a sub-agent, the orchestrator MUST check
  whether `session.state[sub.output_key]` is set. If unset, the
  orchestrator MUST return (pause). If set, the orchestrator MUST
  continue to the next sub-agent.
- **FR-5.** If any event yielded by a sub-agent has
  `event.actions.escalate=True`, the orchestrator MUST return
  immediately and not run further sub-agents (stop).

### 4.2 AgentGate

- **FR-6.** The gate MUST read `session.state[decision_key]` (default
  `"approval_decision"`).
- **FR-7.** If the decision is absent or empty, the gate MUST emit an
  informational event and return WITHOUT writing its `output_key`.
- **FR-8.** If the decision matches any value in `approved_values`
  (case-insensitive, exact match or "<value> " prefix), the gate MUST
  emit an event with `state_delta={output_key: "approved"}` and no
  escalate flag.
- **FR-9.** If the decision is non-empty but not in `approved_values`,
  the gate MUST emit an event with `state_delta={output_key: "denied"}`
  AND `escalate=True`.

### 4.3 Resume

- **FR-10.** A resume operation MUST require only:
  (a) a valid `session_id` that exists in the
      `DatabaseSessionService`, and
  (b) a decision string.
- **FR-11.** The resume operation MUST persist the decision via
  `session_service.append_event(...)` with a `state_delta` writing the
  decision string under `decision_key`.
- **FR-12.** Re-running `runner.run_async(user_id, session_id, ...)`
  after resume MUST result in the orchestrator skipping every previously
  completed sub-agent and re-entering the gate.
- **FR-13.** If `decision` is in `approved_values`, the gate's
  `output_key` becomes `"approved"` and the orchestrator MUST proceed to
  the next sub-agent.
- **FR-14.** If `decision` is not in `approved_values`, the orchestrator
  MUST stop after the gate (per FR-5 / FR-9) and not run later
  sub-agents.

### 4.4 Persistence

- **FR-15.** The pipeline MUST be configured with `DatabaseSessionService`
  (not `InMemorySessionService`). The DB URL is read from environment
  configuration.
- **FR-16.** Every `state_delta` emitted by any sub-agent or the
  orchestrator MUST be persisted to the configured database before the
  next sub-agent runs. (This is `DatabaseSessionService`'s default
  behavior; we rely on it.)
- **FR-17.** The `App` MUST be constructed with
  `ResumabilityConfig(is_resumable=True)`.

### 4.5 Observability

- **FR-18.** The orchestrator MUST emit one structured log line per
  sub-agent transition with one of these prefixes: `[skip]`, `[run]`,
  `[done]`, `[pause]`, `[stop]`.
- **FR-19.** A read-only `status(session_id)` helper MUST exist to
  report (a) which `output_key`s are set, (b) whether the pipeline is
  paused, stopped, or done, without running the orchestrator.

## 5. Non-Functional Requirements

- **NFR-1.** A session paused for 40 days MUST resume successfully
  provided the database row still exists. No in-memory state may be
  required.
- **NFR-2.** Database connection pool MUST use `pool_pre_ping` for
  non-SQLite engines (ADK default in ≥ 1.21).
- **NFR-3.** `status(session_id)` MUST complete in < 100 ms on a SQLite
  store and < 250 ms on a Postgres store.
- **NFR-4.** No leakage of `invocation_id`, `function_call_id`, or
  similar ADK internals into the resume API surface.

## 6. Edge Cases

### Pause / resume edge cases

- **EC-1. Resume with unknown session_id.** Return an error to the
  caller; do not create a new session implicitly.
- **EC-2. Resume of already-completed session.** Every sub-agent's
  `output_key` is set, so every sub-agent is skipped; the orchestrator
  emits a terminal event and returns. Calling resume again is a no-op.
- **EC-3. Resume of already-denied session.** The gate's `output_key`
  is `"denied"`. On re-run, the orchestrator skips the gate (FR-2:
  output_key is set) and reaches the next sub-agent — which would
  incorrectly run. To prevent this, the orchestrator MUST treat
  `escalate=True` recorded in any prior event of the session as a
  permanent stop. **Open: see §8 OQ-2.**
- **EC-4. Empty decision.** Treated as "no decision yet" (FR-7); gate
  pauses again.
- **EC-5. Decision with surrounding whitespace.** Stripped before
  matching `approved_values`.
- **EC-6. Decision with a note appended.** `"approved low risk"` MUST
  match `"approved"` via prefix rule (`"<value> "`).
- **EC-7. Double-resume race.** Two callers append a decision event
  concurrently. ADK's session service serializes appends; whichever
  lands first sets the decision. Subsequent appends overwrite, but the
  gate has already produced its outcome on the first re-run; further
  re-runs see the gate as completed (FR-2) and skip.

### State edge cases

- **EC-8. Sub-agent declares no `output_key`.** Construction validation
  (FR-3) raises at the moment we attempt to run that sub-agent. (We
  cannot validate at construction time because LlmAgents construct
  before `output_key` is set in some configurations.)
- **EC-9. Sub-agent writes its `output_key` to `None`.** Treated as
  unset (paused). Sub-agents MUST NOT write `None` for "done"; they
  write a string or omit the write.
- **EC-10. Decision key collides with a sub-agent's output_key.**
  Construction MUST raise. Default decision_key is `"approval_decision"`
  to minimize this risk.

### Persistence edge cases

- **EC-11. Database schema migration after a session was created.** ADK
  ≥ 1.21 introduces a new JSON schema for new databases. Existing
  databases require `adk migrate session` before upgrading. **Open:
  see §8 OQ-3.**
- **EC-12. Database unavailable on resume.** The error MUST propagate
  to the caller; no partial work may be done.
- **EC-13. Connection pool stale after long pause.** Mitigated by
  `pool_pre_ping=True` (NFR-2). No application code change required.

## 7. Acceptance Criteria

Each FR/EC has a corresponding test in `tests/`. Naming:
`test_<id>_<short>`. Examples:

- `test_FR2_skip_completed_subagent`
- `test_FR4_pause_when_output_key_unset`
- `test_FR9_denied_decision_halts_pipeline`
- `test_FR13_approved_resume_proceeds`
- `test_EC3_denied_session_does_not_resume`
- `test_EC6_decision_with_note_matches`

Tests MUST run without a Gemini API key (Article X). Sub-agents in tests
are deterministic `BaseAgent` stubs.

## 8. Open Questions

- **OQ-1.** Should the orchestrator support a configurable
  `decision_key_for_gate` to allow multiple distinct gates with
  different decision keys? Recommendation: defer to v2; one gate per
  pipeline in v1.
- **OQ-2.** How should the orchestrator detect a "permanently stopped"
  session on resume (EC-3)? Option A: scan past session events for a
  prior `escalate=True`. Option B: write a sentinel state key like
  `__pipeline_halted__`. Recommendation: Option B; cheaper and explicit.
- **OQ-3.** Do we ship a one-shot migration tool or wrap
  `adk migrate session` in a deployment script? Recommendation: wrap;
  invoked from `deploy.sh` before the new code rolls out.

## 9. Glossary

- **Sub-agent**: an ADK agent (`LlmAgent` or `BaseAgent`) registered in
  `ResumableOrchestrator(sub_agents=[...])`. Must declare `output_key`.
- **Gate**: an `AgentGate` instance. The pause point.
- **Decision**: a string written under `session.state[decision_key]`
  that the gate reads.
- **output_key**: ADK-standard attribute on an agent indicating the
  state key it writes its primary output to.
- **Pause**: state in which the orchestrator has returned without
  completing the gate, i.e., `state[gate.output_key]` is unset.
