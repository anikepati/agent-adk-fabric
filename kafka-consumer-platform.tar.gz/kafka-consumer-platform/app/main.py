"""
Application entrypoint.
Loads config → bootstraps everything → starts threads → blocks on shutdown.
"""
from __future__ import annotations

import logging
import os
import signal
import sys

from app.config.loader import load_config
from app.core.bootstrap import bootstrap
from app.leader.duties import LeaderDuties
from app.leader.elector import LeaderElector
from app.observability.metrics import IS_LEADER
from app.observability.structured_log import setup_logging
from app.observability.tracing import setup_tracing

logger = logging.getLogger(__name__)


def main() -> None:
    # ── 1. Logging ──
    log_level = os.environ.get("LOG_LEVEL", "INFO")
    setup_logging(level=log_level)
    logger.info("=" * 60)
    logger.info("Kafka Consumer Platform starting")
    logger.info("=" * 60)

    # ── 2. Tracing ──
    setup_tracing()

    # ── 3. Load configuration ──
    try:
        config = load_config()
    except Exception as e:
        logger.error(f"Configuration loading failed: {e}", exc_info=True)
        sys.exit(1)

    # ── 4. Bootstrap ──
    try:
        ctx = bootstrap(config)
    except Exception as e:
        logger.error(f"Bootstrap failed: {e}", exc_info=True)
        sys.exit(1)

    if not ctx.consumer_threads:
        logger.error("No consumer threads created. Check configuration. Exiting.")
        sys.exit(1)

    # ── 5. Leader Election ──
    leader_duties = LeaderDuties(
        config=config,
        consumer_threads=ctx.consumer_threads,
        shutdown_event=ctx.shutdown_event,
    )

    def on_elected():
        IS_LEADER.set(1)
        leader_duties.start()

    def on_demoted():
        IS_LEADER.set(0)
        leader_duties.stop()

    leader_elector = LeaderElector(
        config=config.leader_election,
        shutdown_event=ctx.shutdown_event,
        on_elected=on_elected,
        on_demoted=on_demoted,
    )
    ctx.health_server.register_leader_elector(leader_elector)

    # ── 6. Signal handlers ──
    def signal_handler(signum, frame):
        sig_name = signal.Signals(signum).name
        logger.info(f"Received {sig_name}, initiating graceful shutdown")
        ctx.shutdown_event.set()

    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)

    # ── 7. Start everything ──
    # Health server first (so probes work during startup)
    ctx.health_server.start()

    # Leader election
    leader_elector.start()

    # Consumer threads
    for ct in ctx.consumer_threads:
        ct.start()
        logger.info(f"Started consumer thread: {ct.name}")

    logger.info(
        "All components started. Waiting for shutdown signal.",
        extra={
            "consumer_threads": len(ctx.consumer_threads),
            "pod": os.environ.get("HOSTNAME", "unknown"),
        },
    )

    # ── 8. Block until shutdown ──
    try:
        ctx.shutdown_event.wait()
    except KeyboardInterrupt:
        logger.info("KeyboardInterrupt received")
        ctx.shutdown_event.set()

    # ── 9. Graceful shutdown ──
    logger.info("Graceful shutdown initiated")

    # Phase 1: Stop accepting new work
    ctx.health_server.set_shutting_down()
    leader_elector.stop()
    leader_duties.stop()

    # Phase 2: Wait for consumer threads to drain
    for ct in ctx.consumer_threads:
        ct.join(timeout=60)
        if ct.is_alive():
            logger.warning(f"Consumer thread {ct.name} did not stop in time")

    # Phase 3: Shutdown worker pool
    if ctx.worker_pool:
        ctx.worker_pool.shutdown(wait=True)

    logger.info("Shutdown complete")


if __name__ == "__main__":
    main()
