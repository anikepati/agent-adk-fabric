"""
Processor plugin package.
All processor types are auto-discovered via @register_processor decorator.
"""
