"""
DecisionTreeAgent — A custom deterministic ADK agent.

This agent does NOT use an LLM for evaluation. It receives row data and
YAML config via session state, evaluates decision trees deterministically
using the operator registry, and writes structured results back to state.

Design Principles:
  - Deterministic: same input → same output, every time
  - Config-driven: YAML defines all business logic
  - State-driven: reads from ctx.session.state, writes results back
  - Composable: slots into SequentialAgent / ParallelAgent pipelines
  - No LLM calls: pure Python evaluation, zero tokens consumed

Usage in a pipeline:
  SequentialAgent(
    sub_agents=[
      IngestAgent,           # loads Excel, puts rows in state
      DecisionTreeAgent,     # evaluates rules per row
      ReportAgent,           # formats and sends results
    ]
  )

State Contract:
  INPUT (reads from session.state):
    dt:config_path    — path to YAML config file
    dt:rows           — list of row dicts (from Excel)
    dt:row_id_column  — column name for row ID (default: "ID")
    dt:dry_run        — whether to skip side effects (default: true)
    dt:current_row    — (optional) single row dict for single-row mode

  OUTPUT (writes to session.state):
    dt:results        — list of per-row evaluation reports
    dt:summary        — execution summary dict
    dt:exceptions     — list of exception records (filtered from results)
    dt:status         — "completed" | "failed" | "no_data"
    dt:error          — error message if status is "failed"
"""

import logging
import time
import yaml
from typing import Any, AsyncIterator, Dict, List, Optional

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.genai import types

from models.schemas import DecisionTreeConfig
from engine.evaluator import ConditionEvaluator, OperatorRegistry
from engine.action_dispatcher import ActionDispatcher
from engine.tree_walker import DecisionTreeWalker, generate_row_report
from engine.dag_executor import DAGExecutor

logger = logging.getLogger(__name__)


class DecisionTreeAgent(BaseAgent):
    """
    A deterministic agent that evaluates YAML decision trees against row data.
    No LLM involved — pure config-driven, rule-based execution.
    """

    # ── ADK model fields ─────────────────────────────────────────────────
    # Using Pydantic model fields so ADK can serialize/inspect the agent

    config_path: Optional[str] = None
    """Default YAML config path. Can be overridden via session state."""

    default_dry_run: bool = True
    """Default dry-run mode. Can be overridden via session state."""

    state_prefix: str = "dt"
    """Prefix for all session state keys. Enables multiple DT agents in one pipeline."""

    # ── Internal (non-serialized) ────────────────────────────────────────

    model_config = {"arbitrary_types_allowed": True}

    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncIterator[types.Content]:
        """
        Core execution method. Called by the ADK runner.

        Flow:
          1. Read config and row data from session state
          2. Parse and validate YAML config (Pydantic fail-fast)
          3. Initialize engine components (evaluator, dispatcher, walker)
          4. For each row: walk all trees / execute DAG
          5. Write results, summary, and exceptions back to state
          6. Yield a summary content message
        """
        start_time = time.time()
        prefix = self.state_prefix

        try:
            # ── Step 1: Read inputs from session state ───────────────
            config_path = self._get_state(ctx, "config_path") or self.config_path
            rows = self._get_state(ctx, "rows")
            current_row = self._get_state(ctx, "current_row")
            row_id_column = self._get_state(ctx, "row_id_column") or "ID"
            dry_run = self._get_state(ctx, "dry_run")
            if dry_run is None:
                dry_run = self.default_dry_run
            config_yaml_str = self._get_state(ctx, "config_yaml")

            # Single-row mode: wrap in list
            if current_row and not rows:
                rows = [current_row]

            if not rows:
                self._set_state(ctx, "status", "no_data")
                self._set_state(ctx, "error", "No rows provided in state")
                yield self._make_content("No row data found in session state.")
                return

            # ── Step 2: Load and validate config ─────────────────────
            if config_yaml_str:
                # Config passed as YAML string in state (for dynamic pipelines)
                raw_config = yaml.safe_load(config_yaml_str)
            elif config_path:
                with open(config_path, "r") as f:
                    raw_config = yaml.safe_load(f)
            else:
                self._set_state(ctx, "status", "failed")
                self._set_state(ctx, "error", "No config_path or config_yaml in state")
                yield self._make_content("Error: No decision tree config provided.")
                return

            config = DecisionTreeConfig(**raw_config)
            has_dag = "dag" in raw_config

            logger.info(
                f"[{self.name}] Config loaded: {len(config.decision_trees)} trees, "
                f"DAG={'yes' if has_dag else 'no'}, dry_run={dry_run}"
            )

            # ── Step 3: Initialize engine components ─────────────────
            evaluator = ConditionEvaluator(OperatorRegistry())
            dispatcher = ActionDispatcher(dry_run=dry_run)
            context = {
                "api_base_url": config.settings.api_base_url,
                "db_connection_string": config.settings.db_connection_string,
                "db_table": config.settings.db_table,
                "row_id_column": row_id_column,
            }
            walker = DecisionTreeWalker(evaluator, dispatcher, context)
            tree_map = {tree.id: tree for tree in config.decision_trees}

            # Initialize DAG if present
            dag_executor = None
            if has_dag:
                dag_executor = DAGExecutor(raw_config["dag"])
                logger.info(
                    f"[{self.name}] DAG: {len(dag_executor.layers)} layers, "
                    f"{len(dag_executor.nodes)} nodes"
                )

            # ── Step 4: Process rows ─────────────────────────────────
            all_reports: List[Dict[str, Any]] = []
            all_exceptions: List[Dict[str, Any]] = []
            row_count = 0
            error_count = 0

            for row in rows:
                row_count += 1
                row_id = str(row.get(row_id_column, f"row_{row_count}"))

                logger.info(f"[{self.name}] Processing row {row_count}: {row_id}")

                if dag_executor:
                    # DAG mode
                    dag_report = dag_executor.execute_for_row(
                        row, row_id, tree_map, walker
                    )
                    all_tree_results = []
                    for node in dag_executor.nodes.values():
                        all_tree_results.extend(node.results)
                    report = generate_row_report(row_id, all_tree_results)
                    report["dag"] = dag_report
                else:
                    # Flat mode
                    tree_results = walker.walk_all_trees(
                        config.decision_trees, row, row_id
                    )
                    report = generate_row_report(row_id, tree_results)

                all_reports.append(report)
                error_count += report["error_count"]

                # Extract exceptions for easy downstream consumption
                exceptions = self._extract_exceptions(report, row)
                all_exceptions.extend(exceptions)

            # ── Step 5: Write results to state ───────────────────────
            elapsed = time.time() - start_time
            summary = {
                "mode": "dag" if has_dag else "flat",
                "total_rows": row_count,
                "total_trees": len(config.decision_trees),
                "total_evaluations": sum(
                    r["total_nodes_evaluated"] for r in all_reports
                ),
                "total_errors": error_count,
                "total_exceptions": len(all_exceptions),
                "elapsed_seconds": round(elapsed, 3),
                "dry_run": dry_run,
            }

            self._set_state(ctx, "results", all_reports)
            self._set_state(ctx, "summary", summary)
            self._set_state(ctx, "exceptions", all_exceptions)
            self._set_state(ctx, "status", "completed")
            self._set_state(ctx, "error", None)

            logger.info(
                f"[{self.name}] Completed: {row_count} rows, "
                f"{summary['total_evaluations']} evaluations, "
                f"{len(all_exceptions)} exceptions, "
                f"{elapsed:.3f}s"
            )

            # ── Step 6: Yield summary message ────────────────────────
            summary_text = (
                f"Decision tree evaluation complete.\n"
                f"Mode: {summary['mode'].upper()}\n"
                f"Rows: {summary['total_rows']}\n"
                f"Evaluations: {summary['total_evaluations']}\n"
                f"Exceptions: {summary['total_exceptions']}\n"
                f"Errors: {summary['total_errors']}\n"
                f"Time: {summary['elapsed_seconds']}s\n"
                f"Dry run: {summary['dry_run']}"
            )
            yield self._make_content(summary_text)

        except Exception as e:
            logger.error(f"[{self.name}] Fatal error: {e}", exc_info=True)
            self._set_state(ctx, "status", "failed")
            self._set_state(ctx, "error", str(e))
            yield self._make_content(f"Decision tree evaluation failed: {e}")

    # ── State helpers ────────────────────────────────────────────────────

    def _get_state(self, ctx: InvocationContext, key: str) -> Any:
        """Read from session state with prefix."""
        full_key = f"{self.state_prefix}:{key}"
        return ctx.session.state.get(full_key)

    def _set_state(self, ctx: InvocationContext, key: str, value: Any):
        """Write to session state with prefix."""
        full_key = f"{self.state_prefix}:{key}"
        ctx.session.state[full_key] = value

    # ── Helpers ──────────────────────────────────────────────────────────

    def _extract_exceptions(
        self, report: Dict, row: Dict
    ) -> List[Dict[str, Any]]:
        """
        Walk the tree results and extract any actions that were API calls
        to /exceptions/log — these are the business exceptions.
        """
        exceptions = []

        def _walk(node_result: Dict):
            action = node_result.get("action", {})
            # Check if this action was an exception log
            would_execute = action.get("would_execute", {})
            payload = would_execute.get("payload") or action.get("payload") or {}
            endpoint = would_execute.get("endpoint") or action.get("url", "")

            if "exception" in str(endpoint).lower() or "exception_id" in payload:
                exceptions.append({
                    "row_id": report["row_id"],
                    "node_id": node_result.get("node_id"),
                    "node_name": node_result.get("node_name"),
                    "exception_id": payload.get("exception_id"),
                    "exception_type": payload.get("exception_type"),
                    "message": payload.get("message"),
                    "branch_taken": node_result.get("branch_taken"),
                })

            for child in node_result.get("children", []):
                _walk(child)

        for tree_result in report.get("tree_results", []):
            _walk(tree_result)

        return exceptions

    @staticmethod
    def _make_content(text: str) -> types.Content:
        """Create a Content message for the ADK runner."""
        return types.Content(
            role="model",
            parts=[types.Part.from_text(text=text)],
        )
