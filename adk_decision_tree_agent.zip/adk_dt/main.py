"""
ADK Decision Tree Agent — Runner

Demonstrates all three usage patterns:
  1. Full pipeline (Excel → evaluate → report)
  2. Pre-loaded rows (rows in state → evaluate → report)
  3. Single-row evaluation

Usage:
  python main.py --mode full --config config/lam_full_dag.yaml --excel data/lam_data.xlsx
  python main.py --mode single --config config/lam_full_dag.yaml
"""

import asyncio
import argparse
import logging
import json
import sys
from pathlib import Path

# ADK imports
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService

# Local agents
from agents.pipeline import (
    create_full_pipeline,
    create_evaluation_pipeline,
    create_single_row_agent,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s │ %(levelname)-7s │ %(name)s │ %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("runner")

APP_NAME = "dt_validation"
USER_ID = "system"


async def run_full_pipeline(config_path: str, excel_file: str, dry_run: bool):
    """Pattern 1: Full pipeline — Excel file → evaluate → report."""
    logger.info("=" * 60)
    logger.info("PATTERN 1: Full Pipeline")
    logger.info("=" * 60)

    pipeline = create_full_pipeline(
        config_path=config_path,
        excel_file=excel_file,
        dry_run=dry_run,
    )

    session_service = InMemorySessionService()
    session = await session_service.create_session(
        app_name=APP_NAME, user_id=USER_ID
    )

    runner = Runner(
        agent=pipeline,
        app_name=APP_NAME,
        session_service=session_service,
    )

    # The pipeline reads excel_file from IngestAgent's config,
    # no need to set it in state — but we can override if needed
    from google.genai import types
    user_msg = types.Content(
        role="user",
        parts=[types.Part.from_text(text="Run validation pipeline")],
    )

    async for event in runner.run_async(
        user_id=USER_ID,
        session_id=session.id,
        new_message=user_msg,
    ):
        if event.content and event.content.parts:
            agent_name = event.author or "agent"
            text = event.content.parts[0].text
            logger.info(f"[{agent_name}] {text[:200]}")

    # Read results from session state
    final_session = await session_service.get_session(
        app_name=APP_NAME, user_id=USER_ID, session_id=session.id
    )
    summary = final_session.state.get("dt:summary")
    exceptions = final_session.state.get("dt:exceptions", [])
    report = final_session.state.get("dt:report", "")

    print("\n" + report)

    return summary, exceptions


async def run_preloaded_rows(config_path: str, rows: list, dry_run: bool):
    """Pattern 2: Pre-loaded rows in state → evaluate → report."""
    logger.info("=" * 60)
    logger.info("PATTERN 2: Pre-loaded Rows")
    logger.info("=" * 60)

    pipeline = create_evaluation_pipeline(
        config_path=config_path,
        dry_run=dry_run,
    )

    session_service = InMemorySessionService()
    session = await session_service.create_session(
        app_name=APP_NAME,
        user_id=USER_ID,
        state={
            "dt:rows": rows,
            "dt:row_id_column": "LoanID",
        },
    )

    runner = Runner(
        agent=pipeline,
        app_name=APP_NAME,
        session_service=session_service,
    )

    from google.genai import types
    user_msg = types.Content(
        role="user",
        parts=[types.Part.from_text(text="Evaluate rows")],
    )

    async for event in runner.run_async(
        user_id=USER_ID,
        session_id=session.id,
        new_message=user_msg,
    ):
        if event.content and event.content.parts:
            agent_name = event.author or "agent"
            text = event.content.parts[0].text
            logger.info(f"[{agent_name}] {text[:200]}")

    final_session = await session_service.get_session(
        app_name=APP_NAME, user_id=USER_ID, session_id=session.id
    )
    return final_session.state.get("dt:summary")


async def run_single_row(config_path: str, row: dict, dry_run: bool):
    """Pattern 3: Single row evaluation."""
    logger.info("=" * 60)
    logger.info("PATTERN 3: Single Row")
    logger.info("=" * 60)

    agent = create_single_row_agent(
        config_path=config_path,
        dry_run=dry_run,
    )

    session_service = InMemorySessionService()
    session = await session_service.create_session(
        app_name=APP_NAME,
        user_id=USER_ID,
        state={
            "dt:current_row": row,
            "dt:row_id_column": "LoanID",
        },
    )

    runner = Runner(
        agent=agent,
        app_name=APP_NAME,
        session_service=session_service,
    )

    from google.genai import types
    user_msg = types.Content(
        role="user",
        parts=[types.Part.from_text(text="Evaluate this row")],
    )

    async for event in runner.run_async(
        user_id=USER_ID,
        session_id=session.id,
        new_message=user_msg,
    ):
        if event.content and event.content.parts:
            print(event.content.parts[0].text)

    final_session = await session_service.get_session(
        app_name=APP_NAME, user_id=USER_ID, session_id=session.id
    )
    exceptions = final_session.state.get("dt:exceptions", [])
    return final_session.state.get("dt:summary"), exceptions


async def main_async(args):
    if args.mode == "full":
        if not args.excel:
            print("Error: --excel required for full mode")
            sys.exit(1)
        summary, exceptions = await run_full_pipeline(
            config_path=args.config,
            excel_file=args.excel,
            dry_run=args.dry_run,
        )
        print(f"\nSummary: {json.dumps(summary, indent=2)}")
        print(f"Exceptions: {len(exceptions)}")

    elif args.mode == "single":
        # Demo single row
        sample_row = {
            "LoanID": "LN-DEMO",
            "ChangeInPercentage": "Yes",
            "PercentageProvided": "No",
            "LogicalProgression": "Yes",
            "FromType": "SPEC",
            "ToType": "PRESOLD",
            "ConversionType": "SPEC_TO_PRESOLD",
            "ContractPriceProvided": "Yes",
            "WithinThreshold": "No",
            "PlanNameExistsInLAM": "Yes",
            "AppraisalValueMatched": "Yes",
            "AppraisalAvailable": "Yes",
            "CustomerBDRHasHardCost": "Yes",
            "CustomerBDRHasContractPrice": "Yes",
            "LAMCollateralValueBasis": "Standard",
            "HardCostChange": "No",
            "LotCostChange": "No",
            "ContractPriceChange": "No",
            "AppraisalValueChange": "No",
            "BorrowingBaseChange": "Yes",
            "AvailabilityAmountChange": "No",
        }
        summary, exceptions = await run_single_row(
            config_path=args.config,
            row=sample_row,
            dry_run=args.dry_run,
        )
        print(f"\nSummary: {json.dumps(summary, indent=2)}")
        for exc in exceptions:
            print(f"Exception {exc['exception_id']}: {exc['exception_type']} — {exc['message']}")

    elif args.mode == "preloaded":
        import pandas as pd
        if not args.excel:
            print("Error: --excel required for preloaded mode")
            sys.exit(1)
        df = pd.read_excel(args.excel)
        rows = df.to_dict(orient="records")
        summary = await run_preloaded_rows(
            config_path=args.config,
            rows=rows,
            dry_run=args.dry_run,
        )
        print(f"\nSummary: {json.dumps(summary, indent=2)}")


def main():
    parser = argparse.ArgumentParser(
        description="ADK Decision Tree Agent Runner"
    )
    parser.add_argument(
        "--mode", choices=["full", "single", "preloaded"],
        default="full",
        help="Execution mode",
    )
    parser.add_argument("--config", "-c", required=True, help="YAML config path")
    parser.add_argument("--excel", "-e", help="Excel file path")
    parser.add_argument("--dry-run", "-d", action="store_true", default=True)
    parser.add_argument("--live", action="store_true", help="Disable dry-run")
    args = parser.parse_args()

    if args.live:
        args.dry_run = False

    asyncio.run(main_async(args))


if __name__ == "__main__":
    main()
