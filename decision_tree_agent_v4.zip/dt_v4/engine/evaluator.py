"""
Condition evaluator v4 — operator registry + safe calculated fields.
No eval(). No exec(). Pure dict lookups and typed lambdas.
"""

import re, math, logging
from typing import Any, Callable, Dict, List, Optional
from models.schemas import SimpleCondition, CompoundCondition, Condition, CalculatedField

logger = logging.getLogger(__name__)
RowData = Dict[str, Any]


# ── Null helpers ─────────────────────────────────────────────

def _is_null(v: Any) -> bool:
    return v is None or (isinstance(v, float) and math.isnan(v))

def _to_float(v: Any) -> Optional[float]:
    if _is_null(v): return None
    try: return float(v)
    except: return None

def _safe_cmp(l, r, op):
    if _is_null(l) or _is_null(r): return False
    try: return op(float(l), float(r))
    except: return op(str(l), str(r))

def _safe_eq(l, r):
    if _is_null(l) and _is_null(r): return True
    if _is_null(l) or _is_null(r): return False
    try: return float(l) == float(r)
    except: return str(l).strip() == str(r).strip()

def _str_op(l, r, op):
    return False if _is_null(l) else op(str(l), str(r))


# ── Operator Registry ────────────────────────────────────────

OPERATORS: Dict[str, Callable] = {
    "gt":         lambda l, r, **_: _safe_cmp(l, r, lambda a,b: a>b),
    "gte":        lambda l, r, **_: _safe_cmp(l, r, lambda a,b: a>=b),
    "lt":         lambda l, r, **_: _safe_cmp(l, r, lambda a,b: a<b),
    "lte":        lambda l, r, **_: _safe_cmp(l, r, lambda a,b: a<=b),
    "eq":         lambda l, r, **_: _safe_eq(l, r),
    "neq":        lambda l, r, **_: not _safe_eq(l, r),
    "contains":   lambda l, r, **_: _str_op(l, r, lambda s,v: v in s),
    "starts_with":lambda l, r, **_: _str_op(l, r, lambda s,v: s.startswith(v)),
    "ends_with":  lambda l, r, **_: _str_op(l, r, lambda s,v: s.endswith(v)),
    "is_empty":   lambda l, **_: _is_null(l) or str(l).strip()=="",
    "regex":      lambda l, pattern=None, **_: bool(re.match(pattern or "", str(l or ""))),
    "is_null":    lambda l, **_: _is_null(l),
    "is_not_null":lambda l, **_: not _is_null(l),
    "between":    lambda l, low=None, high=None, **_: (not _is_null(l)) and float(low)<=float(l)<=float(high),
    "in":         lambda l, values=None, **_: l in (values or []),
    "not_in":     lambda l, values=None, **_: l not in (values or []),
}

UNARY_OPS = {"is_null", "is_not_null", "is_empty", "regex"}
KWARGS_ONLY_OPS = {"between", "in", "not_in"}


def evaluate(condition: Condition, row: RowData) -> bool:
    """Evaluate a condition (simple or compound) against a row."""
    if isinstance(condition, CompoundCondition):
        if condition.operator == "and":
            return all(evaluate(c, row) for c in condition.conditions)
        return any(evaluate(c, row) for c in condition.conditions)

    c = condition
    left = row.get(c.left_column)
    right = row.get(c.right_column) if c.right_column else c.right_value
    kwargs = {"pattern": c.pattern, "low": c.low, "high": c.high, "values": c.values}
    op = OPERATORS[c.operator]

    if c.operator in UNARY_OPS:
        return op(left, **kwargs)
    if c.operator in KWARGS_ONLY_OPS:
        return op(left, **kwargs)
    return op(left, right, **kwargs)


# ── Safe Calculated Fields ───────────────────────────────────

CALC_OPERATORS: Dict[str, Callable] = {
    "add":      lambda l, r: l + r if l is not None and r is not None else None,
    "subtract": lambda l, r: l - r if l is not None and r is not None else None,
    "multiply": lambda l, r: l * r if l is not None and r is not None else None,
    "divide":   lambda l, r: l / r if l is not None and r not in (None, 0) else None,
    "percent":  lambda l, r: (l / r * 100) if l is not None and r not in (None, 0) else None,
}


def compute_fields(fields: List[CalculatedField], row: RowData) -> Dict[str, Any]:
    """
    Compute derived fields SAFELY — no eval().
    Adds computed values to row so later fields can reference earlier ones.
    Returns dict of computed key→value pairs.
    """
    computed = {}

    for f in fields:
        try:
            if f.operator == "constant":
                value = f.value

            elif f.operator in ("add", "subtract", "multiply", "divide", "percent"):
                left = _to_float(row.get(f.left_column))
                right = _to_float(row.get(f.right_column)) if f.right_column else _to_float(f.right_value)
                value = CALC_OPERATORS[f.operator](left, right)

            elif f.operator == "coalesce":
                value = None
                for col in (f.columns or []):
                    v = row.get(col)
                    if not _is_null(v):
                        value = v
                        break

            elif f.operator == "concat":
                sep = f.format or ""
                parts = [str(row.get(col, "")) for col in (f.columns or [])]
                value = sep.join(parts)

            elif f.operator == "lookup":
                value = row.get(f.left_column)

            else:
                value = None

            computed[f.output_key] = value
            row[f.output_key] = value  # available to later fields + trees

        except Exception as e:
            logger.warning(f"Calculated field '{f.output_key}' failed: {e}")
            computed[f.output_key] = None
            row[f.output_key] = None

    return computed
