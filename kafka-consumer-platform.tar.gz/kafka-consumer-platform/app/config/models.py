"""
Pydantic models for consumer-config.yaml validation.
Every field maps directly to a YAML key. No profiles, no parameters.
"""
from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field, field_validator


class RetryConfig(BaseModel):
    max_attempts: int = 3
    backoff_base_ms: int = 500
    backoff_max_ms: int = 30000


class CircuitBreakerConfig(BaseModel):
    failure_threshold: int = 5
    recovery_timeout_s: int = 60
    half_open_max: int = 3


class TopicConfig(BaseModel):
    topic: str
    processor: str
    processor_config: dict[str, Any] = Field(default_factory=dict)
    format: str = "json"
    dlq: Optional[str] = None
    retry: Optional[RetryConfig] = None
    timeout_s: Optional[int] = None
    circuit_breaker: Optional[CircuitBreakerConfig] = None

    def effective_dlq(self, dlq_suffix: str) -> str:
        return self.dlq or f"{self.topic}{dlq_suffix}"


class SSLConfig(BaseModel):
    ca_location: str
    certificate_location: Optional[str] = None
    key_location: Optional[str] = None


class SASLConfig(BaseModel):
    mechanism: str = "SCRAM-SHA-512"
    username: str
    password: str


class SchemaRegistryConfig(BaseModel):
    url: str
    auth: Optional[str] = None


class KafkaConsumerConfig(BaseModel):
    auto_offset_reset: str = "earliest"
    enable_auto_commit: bool = False
    max_poll_interval_ms: int = 300000
    session_timeout_ms: int = 45000
    max_poll_records: int = 500
    partition_assignment_strategy: str = "cooperative-sticky"


class ClusterConfig(BaseModel):
    bootstrap_servers: str
    group_id: str
    security_protocol: str = "PLAINTEXT"
    ssl: Optional[SSLConfig] = None
    sasl: Optional[SASLConfig] = None
    schema_registry: Optional[SchemaRegistryConfig] = None
    consumer_config: KafkaConsumerConfig = Field(default_factory=KafkaConsumerConfig)
    topics: list[TopicConfig] = Field(default_factory=list)

    @field_validator("topics")
    @classmethod
    def validate_unique_topics(cls, v: list[TopicConfig]) -> list[TopicConfig]:
        names = [t.topic for t in v]
        dupes = [n for n in names if names.count(n) > 1]
        if dupes:
            raise ValueError(f"Duplicate topic names: {set(dupes)}")
        return v

    def build_consumer_params(self) -> dict[str, Any]:
        """Build confluent-kafka consumer configuration dict."""
        params: dict[str, Any] = {
            "bootstrap.servers": self.bootstrap_servers,
            "group.id": self.group_id,
            "auto.offset.reset": self.consumer_config.auto_offset_reset,
            "enable.auto.commit": self.consumer_config.enable_auto_commit,
            "max.poll.interval.ms": self.consumer_config.max_poll_interval_ms,
            "session.timeout.ms": self.consumer_config.session_timeout_ms,
            "security.protocol": self.security_protocol,
            "partition.assignment.strategy": self.consumer_config.partition_assignment_strategy,
        }
        if self.ssl:
            params["ssl.ca.location"] = self.ssl.ca_location
            if self.ssl.certificate_location:
                params["ssl.certificate.location"] = self.ssl.certificate_location
            if self.ssl.key_location:
                params["ssl.key.location"] = self.ssl.key_location
        if self.sasl:
            params["sasl.mechanism"] = self.sasl.mechanism
            params["sasl.username"] = self.sasl.username
            params["sasl.password"] = self.sasl.password
        return params

    def build_producer_params(self) -> dict[str, Any]:
        """Build confluent-kafka producer configuration for DLQ."""
        params: dict[str, Any] = {
            "bootstrap.servers": self.bootstrap_servers,
            "security.protocol": self.security_protocol,
            "acks": "all",
            "retries": 3,
            "enable.idempotence": True,
        }
        if self.ssl:
            params["ssl.ca.location"] = self.ssl.ca_location
            if self.ssl.certificate_location:
                params["ssl.certificate.location"] = self.ssl.certificate_location
            if self.ssl.key_location:
                params["ssl.key.location"] = self.ssl.key_location
        if self.sasl:
            params["sasl.mechanism"] = self.sasl.mechanism
            params["sasl.username"] = self.sasl.username
            params["sasl.password"] = self.sasl.password
        return params


class WorkerPoolConfig(BaseModel):
    max_workers: int = 10


class LeaderElectionConfig(BaseModel):
    enabled: bool = True
    lease_name: str = "kafka-consumer-leader"
    lease_duration_s: int = 30
    renew_interval_s: int = 10
    retry_interval_s: int = 15


class HealthConfig(BaseModel):
    port: int = 8080
    metrics_port: int = 9090


class DefaultsConfig(BaseModel):
    retry: RetryConfig = Field(default_factory=RetryConfig)
    timeout_s: int = 60
    format: str = "json"
    dlq_suffix: str = ".dlq"
    circuit_breaker: CircuitBreakerConfig = Field(default_factory=CircuitBreakerConfig)


class AppConfig(BaseModel):
    """Root configuration model — mirrors consumer-config.yaml exactly."""

    clusters: dict[str, ClusterConfig]
    worker_pool: WorkerPoolConfig = Field(default_factory=WorkerPoolConfig)
    leader_election: LeaderElectionConfig = Field(default_factory=LeaderElectionConfig)
    health: HealthConfig = Field(default_factory=HealthConfig)
    defaults: DefaultsConfig = Field(default_factory=DefaultsConfig)

    def resolve_topic_defaults(self) -> None:
        """Apply defaults to topics that don't specify their own values."""
        for cluster in self.clusters.values():
            for topic in cluster.topics:
                if topic.retry is None:
                    topic.retry = self.defaults.retry.model_copy()
                if topic.timeout_s is None:
                    topic.timeout_s = self.defaults.timeout_s
                if topic.circuit_breaker is None:
                    topic.circuit_breaker = self.defaults.circuit_breaker.model_copy()
                if topic.format == "json" and self.defaults.format != "json":
                    topic.format = self.defaults.format
