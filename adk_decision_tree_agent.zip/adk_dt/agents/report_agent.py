"""
ReportAgent — Reads decision tree results from state and produces a report.

This agent can operate in two modes:
  1. Deterministic mode (no LLM): generates structured exception summary
  2. LLM mode: uses an LLM to produce natural language analysis of exceptions

State Contract:
  INPUT (reads from session.state):
    dt:results       — list of per-row evaluation reports
    dt:summary       — execution summary dict
    dt:exceptions    — list of exception records
    dt:status        — completion status

  OUTPUT (writes to session.state):
    dt:report        — formatted report string
    dt:exception_summary — aggregated exception counts by type
"""

import logging
from collections import Counter
from typing import Any, AsyncIterator, Dict, List, Optional

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.genai import types

logger = logging.getLogger(__name__)


class ReportAgent(BaseAgent):
    """Generates reports from decision tree evaluation results."""

    state_prefix: str = "dt"
    include_row_details: bool = False

    model_config = {"arbitrary_types_allowed": True}

    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncIterator[types.Content]:
        prefix = self.state_prefix

        status = ctx.session.state.get(f"{prefix}:status")
        if status != "completed":
            error = ctx.session.state.get(f"{prefix}:error", "Unknown error")
            yield self._msg(f"Cannot generate report — evaluation status: {status}. Error: {error}")
            return

        summary = ctx.session.state.get(f"{prefix}:summary", {})
        exceptions = ctx.session.state.get(f"{prefix}:exceptions", [])
        results = ctx.session.state.get(f"{prefix}:results", [])

        # ── Build exception summary ──────────────────────────────────
        exception_counts = Counter()
        exception_by_row: Dict[str, List[Dict]] = {}

        for exc in exceptions:
            exc_type = exc.get("exception_type", "UNKNOWN")
            exc_id = exc.get("exception_id", "?")
            key = f"Exception {exc_id}: {exc_type}"
            exception_counts[key] += 1

            row_id = exc.get("row_id", "?")
            if row_id not in exception_by_row:
                exception_by_row[row_id] = []
            exception_by_row[row_id].append(exc)

        ctx.session.state[f"{prefix}:exception_summary"] = dict(exception_counts)

        # ── Build report ─────────────────────────────────────────────
        lines = [
            "=" * 60,
            "DECISION TREE EVALUATION REPORT",
            "=" * 60,
            "",
            f"Mode:              {summary.get('mode', 'flat').upper()}",
            f"Total Rows:        {summary.get('total_rows', 0)}",
            f"Total Trees:       {summary.get('total_trees', 0)}",
            f"Total Evaluations: {summary.get('total_evaluations', 0)}",
            f"Total Exceptions:  {summary.get('total_exceptions', 0)}",
            f"Total Errors:      {summary.get('total_errors', 0)}",
            f"Elapsed:           {summary.get('elapsed_seconds', 0)}s",
            f"Dry Run:           {summary.get('dry_run', True)}",
            "",
        ]

        if exception_counts:
            lines.append("-" * 60)
            lines.append("EXCEPTIONS BY TYPE")
            lines.append("-" * 60)
            for exc_key, count in exception_counts.most_common():
                lines.append(f"  {exc_key}: {count} occurrence(s)")
            lines.append("")

        if exception_by_row:
            lines.append("-" * 60)
            lines.append("EXCEPTIONS BY ROW")
            lines.append("-" * 60)
            for row_id, row_excs in exception_by_row.items():
                exc_ids = [str(e.get("exception_id", "?")) for e in row_excs]
                lines.append(f"  {row_id}: Exception(s) {', '.join(exc_ids)}")
            lines.append("")

        # Rows with no exceptions
        clean_rows = [
            r["row_id"] for r in results
            if r["row_id"] not in exception_by_row
        ]
        if clean_rows:
            lines.append("-" * 60)
            lines.append(f"CLEAN ROWS ({len(clean_rows)})")
            lines.append("-" * 60)
            for row_id in clean_rows:
                lines.append(f"  {row_id}: All validations passed")
            lines.append("")

        if self.include_row_details:
            lines.append("-" * 60)
            lines.append("PER-ROW DETAIL")
            lines.append("-" * 60)
            for report in results:
                lines.append(
                    f"  {report['row_id']}: "
                    f"evaluated={report['total_nodes_evaluated']} "
                    f"true={report['true_count']} "
                    f"false={report['false_count']} "
                    f"errors={report['error_count']}"
                )
            lines.append("")

        lines.append("=" * 60)

        report_text = "\n".join(lines)
        ctx.session.state[f"{prefix}:report"] = report_text

        logger.info(f"[{self.name}] Report generated: {len(exceptions)} exceptions across {len(exception_by_row)} rows")

        yield self._msg(report_text)

    @staticmethod
    def _msg(text: str) -> types.Content:
        return types.Content(
            role="model",
            parts=[types.Part.from_text(text=text)],
        )
