"""
Thread-safe topic → processor mapping.
Built once at startup from YAML config.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from app.processors.base import BaseProcessor

logger = logging.getLogger(__name__)


class TopicMap:
    """Immutable mapping from topic name to processor instance."""

    def __init__(self) -> None:
        self._map: dict[str, BaseProcessor] = {}

    def register(self, topic: str, processor: BaseProcessor) -> None:
        if topic in self._map:
            raise ValueError(f"Duplicate topic registration: {topic}")
        self._map[topic] = processor
        logger.info(
            "Topic registered",
            extra={
                "topic": topic,
                "processor": processor.__class__.__name__,
            },
        )

    def get(self, topic: str) -> BaseProcessor | None:
        return self._map.get(topic)

    def topics(self) -> list[str]:
        return list(self._map.keys())

    def __len__(self) -> int:
        return len(self._map)

    def __contains__(self, topic: str) -> bool:
        return topic in self._map

    async def shutdown_all(self) -> None:
        for topic, processor in self._map.items():
            try:
                await processor.shutdown()
            except Exception as e:
                logger.error(
                    "Error shutting down processor",
                    extra={"topic": topic, "error": str(e)},
                )
