"""
ADK Tool Functions — bridge between ADK agents and core engine.

Handles the async/sync boundary correctly:
- ADK calls tool functions synchronously
- Playwright is async
- We keep a dedicated event loop for browser operations
"""

from __future__ import annotations

import asyncio
import logging
import threading
from typing import Optional

from core.models import (
    ExecutionResult,
    ErrorAction,
    ScriptAttempt,
    PageState,
    ValidationRule,
    ValidationType,
)
from core.script_executor import ScriptExecutor
from core.browser_manager import BrowserManager
from core.error_classifier import classify_error, is_same_error
from core.config import AppConfig

from playwright.async_api import Page

logger = logging.getLogger("tools")


# ═══════════════════════════════════════════════════════════════
# Async bridge — dedicated loop for Playwright operations
# ═══════════════════════════════════════════════════════════════

class _AsyncBridge:
    """
    Runs a dedicated event loop on a background thread so that
    sync ADK tool calls can await Playwright coroutines safely.
    """

    def __init__(self):
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._loop is not None:
            return
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(
            target=self._loop.run_forever,
            daemon=True,
            name="playwright-loop",
        )
        self._thread.start()

    def run(self, coro):
        """Submit a coroutine and block until it completes."""
        if self._loop is None:
            self.start()
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return future.result(timeout=300)  # 5 min hard ceiling

    def stop(self) -> None:
        if self._loop:
            self._loop.call_soon_threadsafe(self._loop.stop)
            if self._thread:
                self._thread.join(timeout=10)
            self._loop = None
            self._thread = None


_bridge = _AsyncBridge()


# ═══════════════════════════════════════════════════════════════
# Runtime — holds browser + executor, one per application
# ═══════════════════════════════════════════════════════════════

class AgentRuntime:
    """Holds Playwright browser and script executor instances."""

    def __init__(self, config: AppConfig):
        self.config = config
        self.browser_mgr = BrowserManager(config.browser)
        self.executor = ScriptExecutor(config.execution)
        self._page: Optional[Page] = None

    async def ensure_page(self) -> Page:
        if self._page is None:
            await self.browser_mgr.initialize()
            self._page = await self.browser_mgr.new_page()
        return self._page

    async def cleanup(self) -> None:
        if self._page:
            await self.browser_mgr.close_page(self._page)
            self._page = None
        await self.browser_mgr.shutdown()


_runtime: Optional[AgentRuntime] = None


def init_runtime(config: AppConfig) -> None:
    global _runtime
    _runtime = AgentRuntime(config)
    _bridge.start()


def get_runtime() -> AgentRuntime:
    if _runtime is None:
        raise RuntimeError("Call init_runtime() before using tools")
    return _runtime


def shutdown_runtime() -> None:
    global _runtime
    if _runtime:
        try:
            _bridge.run(_runtime.cleanup())
        except Exception as exc:
            logger.warning("Cleanup error: %s", exc)
        _runtime = None
    _bridge.stop()


# ═══════════════════════════════════════════════════════════════
# Tool 1: Run Playwright Script
# ═══════════════════════════════════════════════════════════════

def run_playwright_script(tool_context) -> dict:
    """
    Execute the Playwright script from session state.
    Zero LLM tokens — pure Playwright execution.

    State contract:
      reads:  current_script, workflow_params, validation_rules, attempt_number
      writes: execution_result, needs_replan, task_complete, task_failed,
              error_action, replan_context, script_history
    """
    state = tool_context.state
    rt = get_runtime()

    script = state.get("current_script")
    params = state.get("workflow_params", {})
    attempt = state.get("attempt_number", 1)
    val_raw = state.get("validation_rules", [])

    if not script:
        _terminate(state, "No script to execute")
        return {"status": "error", "error": "No script to execute"}

    # Parse validation rules
    val_rules: list[ValidationRule] = []
    for rd in val_raw:
        try:
            val_rules.append(ValidationRule(
                type=ValidationType(rd["type"]),
                value=rd.get("value", ""),
                selector=rd.get("selector"),
            ))
        except (ValueError, KeyError):
            continue

    # Execute
    try:
        page = _bridge.run(rt.ensure_page())
        result: ExecutionResult = _bridge.run(
            rt.executor.execute(
                script=script,
                params=params,
                page=page,
                validation_rules=val_rules or None,
                screenshot_dir=rt.config.browser.screenshot_dir,
            )
        )
    except Exception as exc:
        _terminate(state, f"Engine error: {str(exc)[:200]}")
        return {"status": "error", "error": str(exc)[:200]}

    result.attempt_number = attempt
    _record_attempt(state, script, result)

    # ── success ───────────────────────────────────────────────
    if result.success:
        state["needs_replan"] = False
        state["task_complete"] = True
        state["task_failed"] = False
        return {
            "status": "success",
            "lines": f"{result.executed_lines}/{result.total_lines}",
            "duration_ms": result.duration_ms,
            "url": result.page_url,
            "attempt": attempt,
        }

    # ── failure — classify & decide ───────────────────────────
    err = result.error
    cat, action = classify_error(err.error_message, err.error_type, err.page_url or "")

    # Detect repeated failure (Replanner not making progress)
    hist = state.get("script_history", [])
    if attempt > 1 and len(hist) >= 2:
        prev_err = hist[-2].get("error", "")
        if prev_err and is_same_error(prev_err, err.error_message):
            logger.warning("Same error repeated — escalating to abort")
            action = ErrorAction.ABORT

    max_retries = state.get("max_retries", 3)
    if attempt > max_retries:
        action = ErrorAction.ABORT

    state["error_action"] = action.value

    if action == ErrorAction.ABORT:
        _terminate(state, f"[{cat.value}] {err.error_message[:200]}")
        return _fail_response(err, cat, result, attempt, "aborted")

    if action == ErrorAction.RETRY:
        state["needs_replan"] = False
        state["task_complete"] = False
        state["attempt_number"] = attempt + 1
        return {
            "status": "retrying",
            "error": err.error_message[:200],
            "category": cat.value,
            "attempt": attempt + 1,
        }

    # REPLAN — build context for Replanner
    ps_dict = err.page_state.to_compact_dict() if err.page_state else {}
    state["needs_replan"] = True
    state["task_complete"] = False
    state["replan_context"] = {
        "error_type": err.error_type,
        "error_message": err.error_message[:300],
        "category": cat.value,
        "failed_line": err.failed_line,
        "failed_line_number": err.failed_line_number,
        "lines_before": err.lines_before,
        "lines_after": err.lines_after,
        "page_url": err.page_url,
        "page_state": ps_dict,
        "screenshot": err.screenshot_path,
        "original_script": script,
        "recovery_hints": state.get("recovery_hints", []),
    }
    return _fail_response(err, cat, result, attempt, "needs_replan")


# ═══════════════════════════════════════════════════════════════
# Tool 2: Apply Rewritten Script
# ═══════════════════════════════════════════════════════════════

def apply_rewritten_script(new_script: str, tool_context) -> dict:
    """
    Replace the current script with the Replanner's rewrite.
    Validates script before accepting.

    Args:
        new_script: Complete rewritten Playwright script
    """
    state = tool_context.state
    attempt = state.get("attempt_number", 1)
    max_retries = state.get("max_retries", 3)

    # Validate
    lines = [
        l.strip() for l in new_script.strip().splitlines()
        if l.strip() and not l.strip().startswith("#")
    ]
    if not lines:
        return {"status": "error", "error": "Rewritten script is empty"}

    clean = [l[6:] if l.startswith("await ") else l for l in lines]
    bad = [l for l in clean if not l.startswith("page.")]
    if bad:
        return {"status": "error", "error": f"Invalid line: {bad[0][:80]}"}

    next_attempt = attempt + 1
    if next_attempt > max_retries + 1:
        _terminate(state, f"Max retries ({max_retries}) exceeded")
        return {"status": "aborted", "reason": f"Max {max_retries} retries"}

    state["current_script"] = new_script.strip()
    state["attempt_number"] = next_attempt
    state["needs_replan"] = False

    h = ScriptAttempt.compute_hash(new_script)
    logger.info("Script rewritten (hash=%s, lines=%d, next_attempt=%d)", h, len(lines), next_attempt)

    return {
        "status": "script_updated",
        "script_hash": h,
        "line_count": len(lines),
        "attempt": next_attempt,
    }


# ═══════════════════════════════════════════════════════════════
# Tool 3: Live Page State
# ═══════════════════════════════════════════════════════════════

def get_live_page_state(tool_context) -> dict:
    """Capture a fresh DOM snapshot for the Replanner."""
    rt = get_runtime()
    try:
        page = _bridge.run(rt.ensure_page())
        ps: PageState = _bridge.run(rt.executor.capture_page_state(page))
        return ps.to_compact_dict()
    except Exception as exc:
        return {"error": f"Capture failed: {str(exc)[:200]}"}


# ═══════════════════════════════════════════════════════════════
# Tool 4: Abort
# ═══════════════════════════════════════════════════════════════

def abort_workflow(reason: str, tool_context) -> dict:
    """Called by Replanner when recovery is impossible."""
    _terminate(tool_context.state, reason[:500])
    logger.warning("Workflow aborted: %s", reason[:200])
    return {"status": "aborted", "reason": reason[:200]}


# ═══════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════

def _terminate(state: dict, reason: str) -> None:
    state["task_complete"] = True
    state["task_failed"] = True
    state["needs_replan"] = False
    state["failure_reason"] = reason


def _record_attempt(state: dict, script: str, result: ExecutionResult) -> None:
    hist = state.get("script_history", [])
    hist.append({
        "attempt": state.get("attempt_number", 1),
        "script_hash": ScriptAttempt.compute_hash(script),
        "success": result.success,
        "progress_pct": result.progress_pct,
        "duration_ms": result.duration_ms,
        "error": result.error.error_message[:200] if result.error else None,
        "failed_line": result.error.failed_line[:100] if result.error else None,
    })
    state["script_history"] = hist


def _fail_response(err, cat, result, attempt, status):
    return {
        "status": status,
        "error": err.error_message[:200],
        "failed_line": err.failed_line[:100],
        "category": cat.value,
        "progress": f"{result.progress_pct}%",
        "attempt": attempt,
        "page_url": err.page_url,
    }
