"""
Observability — structured logging, execution metrics, and audit trail.

All events are JSON-structured for log aggregation.
Audit trail is immutable and captures every script version and decision.
"""

from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Any

from core.models import (
    WorkflowExecution,
    WorkflowStatus,
    ScriptAttempt,
    ExecutionResult,
)


# ═══════════════════════════════════════════════════════════════
# Structured JSON Logging
# ═══════════════════════════════════════════════════════════════

class StructuredFormatter(logging.Formatter):
    """JSON-structured log formatter for production log aggregation."""

    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        # Merge extra fields
        if hasattr(record, "__dict__"):
            for key, value in record.__dict__.items():
                if key not in (
                    "name", "msg", "args", "created", "filename",
                    "funcName", "levelname", "levelno", "lineno",
                    "module", "msecs", "pathname", "process",
                    "processName", "relativeCreated", "stack_info",
                    "thread", "threadName", "exc_info", "exc_text",
                    "message", "taskName",
                ):
                    log_entry[key] = value

        return json.dumps(log_entry, default=str)


def setup_logging(level: str = "INFO", json_format: bool = True):
    """Configure structured logging for the application."""
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, level.upper()))

    handler = logging.StreamHandler()

    if json_format:
        handler.setFormatter(StructuredFormatter())
    else:
        handler.setFormatter(
            logging.Formatter(
                "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
            )
        )

    root_logger.handlers = [handler]


# ═══════════════════════════════════════════════════════════════
# Execution Metrics
# ═══════════════════════════════════════════════════════════════

class MetricsCollector:
    """
    Collects execution metrics for monitoring and alerting.
    In production, replace with Prometheus/StatsD/CloudWatch client.
    """

    def __init__(self):
        self._metrics: dict[str, list[float]] = {}
        self._counters: dict[str, int] = {}

    def record_duration(self, name: str, duration_ms: float):
        """Record a duration metric."""
        self._metrics.setdefault(name, []).append(duration_ms)

    def increment(self, name: str, amount: int = 1):
        """Increment a counter."""
        self._counters[name] = self._counters.get(name, 0) + amount

    def record_workflow_execution(
        self, workflow_name: str, execution: WorkflowExecution
    ):
        """Record metrics for a completed workflow execution."""
        self.record_duration(
            f"workflow.{workflow_name}.duration_ms",
            execution.total_duration_ms,
        )
        self.increment(f"workflow.{workflow_name}.total")
        self.increment(
            f"workflow.{workflow_name}.{execution.status.value}"
        )
        self.increment(
            f"workflow.{workflow_name}.attempts",
            execution.attempt_count,
        )
        if execution.total_llm_tokens > 0:
            self.increment(
                f"workflow.{workflow_name}.llm_tokens",
                execution.total_llm_tokens,
            )

    def get_summary(self) -> dict:
        """Get metrics summary."""
        summary = {"counters": dict(self._counters), "histograms": {}}
        for name, values in self._metrics.items():
            if values:
                sorted_vals = sorted(values)
                summary["histograms"][name] = {
                    "count": len(values),
                    "min": sorted_vals[0],
                    "max": sorted_vals[-1],
                    "avg": sum(values) / len(values),
                    "p50": sorted_vals[len(values) // 2],
                    "p95": sorted_vals[int(len(values) * 0.95)],
                }
        return summary


# ═══════════════════════════════════════════════════════════════
# Audit Trail
# ═══════════════════════════════════════════════════════════════

class AuditTrail:
    """
    Immutable audit trail for workflow executions.
    Records every script version, LLM decision, and outcome.
    In production, replace file storage with database/S3.
    """

    def __init__(self, storage_dir: str = "./audit"):
        self._storage_dir = Path(storage_dir)
        self._storage_dir.mkdir(parents=True, exist_ok=True)

    def record(self, execution: WorkflowExecution):
        """Record a completed workflow execution."""
        audit_record = execution.to_audit_dict()

        # Write to file (replace with DB insert in production)
        filename = f"{execution.execution_id}.json"
        filepath = self._storage_dir / filename

        with open(filepath, "w") as f:
            json.dump(audit_record, f, indent=2, default=str)

        logging.getLogger(__name__).info(
            "Audit record written",
            extra={
                "execution_id": execution.execution_id,
                "workflow": execution.workflow_name,
                "status": execution.status.value,
                "attempts": execution.attempt_count,
                "path": str(filepath),
            },
        )

    def get_recent(self, workflow_name: Optional[str] = None, limit: int = 10) -> list[dict]:
        """Retrieve recent audit records."""
        records = []
        files = sorted(self._storage_dir.glob("*.json"), reverse=True)

        for filepath in files[:limit * 2]:
            try:
                with open(filepath) as f:
                    record = json.load(f)
                if workflow_name and record.get("workflow_name") != workflow_name:
                    continue
                records.append(record)
                if len(records) >= limit:
                    break
            except Exception:
                continue

        return records


# ═══════════════════════════════════════════════════════════════
# Execution Tracker (ties everything together)
# ═══════════════════════════════════════════════════════════════

class ExecutionTracker:
    """
    Tracks a single workflow execution lifecycle.
    Produces structured logs, records metrics, and writes audit trail.
    """

    def __init__(
        self,
        workflow_name: str,
        params: dict,
        metrics: MetricsCollector,
        audit: AuditTrail,
    ):
        self._logger = logging.getLogger(f"workflow.{workflow_name}")
        self._metrics = metrics
        self._audit = audit

        self.execution = WorkflowExecution(
            workflow_name=workflow_name,
            params=params,
            status=WorkflowStatus.RUNNING,
            start_time=datetime.now(timezone.utc),
        )

    def log_attempt_start(self, attempt_number: int, script_hash: str):
        """Log the start of a script execution attempt."""
        self._logger.info(
            "Script execution starting",
            extra={
                "execution_id": self.execution.execution_id,
                "attempt": attempt_number,
                "script_hash": script_hash,
            },
        )

    def log_attempt_result(self, attempt: ScriptAttempt):
        """Log and record a script execution attempt result."""
        self.execution.attempts.append(attempt)

        if attempt.result.success:
            self._logger.info(
                "Script execution succeeded",
                extra={
                    "execution_id": self.execution.execution_id,
                    "attempt": attempt.attempt_number,
                    "duration_ms": attempt.result.duration_ms,
                    "lines": f"{attempt.result.executed_lines}/{attempt.result.total_lines}",
                    "url": attempt.result.page_url,
                },
            )
        else:
            self._logger.warning(
                "Script execution failed",
                extra={
                    "execution_id": self.execution.execution_id,
                    "attempt": attempt.attempt_number,
                    "duration_ms": attempt.result.duration_ms,
                    "progress": f"{attempt.result.progress_pct}%",
                    "error_type": attempt.result.error.error_type if attempt.result.error else None,
                    "error": attempt.result.error.error_message[:200] if attempt.result.error else None,
                    "failed_line": attempt.result.error.failed_line[:100] if attempt.result.error else None,
                },
            )

    def log_replan(self, reason: str, duration_ms: int):
        """Log a replan event."""
        self._logger.info(
            "Script replanned by LLM",
            extra={
                "execution_id": self.execution.execution_id,
                "reason": reason[:200],
                "replan_duration_ms": duration_ms,
            },
        )

    def finalize(
        self,
        status: WorkflowStatus,
        failure_reason: Optional[str] = None,
        final_url: Optional[str] = None,
        llm_tokens: int = 0,
    ):
        """Finalize tracking — write metrics and audit record."""
        self.execution.status = status
        self.execution.end_time = datetime.now(timezone.utc)
        self.execution.failure_reason = failure_reason
        self.execution.final_page_url = final_url
        self.execution.total_llm_tokens = llm_tokens

        self._metrics.record_workflow_execution(
            self.execution.workflow_name, self.execution
        )
        self._audit.record(self.execution)

        self._logger.info(
            "Workflow execution finalized",
            extra={
                "execution_id": self.execution.execution_id,
                "status": status.value,
                "attempts": self.execution.attempt_count,
                "total_duration_ms": self.execution.total_duration_ms,
                "llm_tokens": llm_tokens,
            },
        )
