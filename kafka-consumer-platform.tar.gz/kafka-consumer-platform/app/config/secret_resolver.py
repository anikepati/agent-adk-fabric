"""
Resolves secret placeholders in configuration values.

Supported patterns:
    ${ENV:VAR_NAME}              → os.environ["VAR_NAME"]
    ${FILE:/path/to/secret}      → read file contents
    ${VAULT:secret/path/key}     → HashiCorp Vault lookup (via hvac)
    ${VAR_NAME}                  → os.environ["VAR_NAME"] (shorthand)
"""
from __future__ import annotations

import logging
import os
import re
from typing import Any

logger = logging.getLogger(__name__)

_PLACEHOLDER_RE = re.compile(r"\$\{([^}]+)\}")


def _resolve_single(placeholder: str) -> str:
    """Resolve a single ${...} placeholder."""
    if placeholder.startswith("ENV:"):
        var_name = placeholder[4:]
        value = os.environ.get(var_name)
        if value is None:
            raise ValueError(f"Environment variable not found: {var_name}")
        return value

    if placeholder.startswith("FILE:"):
        file_path = placeholder[5:]
        try:
            with open(file_path) as f:
                return f.read().strip()
        except FileNotFoundError:
            raise ValueError(f"Secret file not found: {file_path}")

    if placeholder.startswith("VAULT:"):
        vault_path = placeholder[6:]
        return _resolve_vault(vault_path)

    # Shorthand: treat as environment variable
    value = os.environ.get(placeholder)
    if value is None:
        raise ValueError(f"Environment variable not found: {placeholder}")
    return value


def _resolve_vault(vault_path: str) -> str:
    """Resolve a Vault secret. Requires hvac client."""
    try:
        import hvac
    except ImportError:
        raise ImportError(
            "hvac package required for Vault secret resolution. "
            "Install with: pip install hvac"
        )

    vault_addr = os.environ.get("VAULT_ADDR", "http://127.0.0.1:8200")
    vault_token = os.environ.get("VAULT_TOKEN")
    vault_role = os.environ.get("VAULT_ROLE")

    client = hvac.Client(url=vault_addr, token=vault_token)

    # If using Kubernetes auth
    if not vault_token and vault_role:
        jwt_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
        if os.path.exists(jwt_path):
            with open(jwt_path) as f:
                jwt = f.read()
            client.auth.kubernetes.login(role=vault_role, jwt=jwt)

    # Parse path: "secret/data/kafka/risk/password" or "secret/kafka/risk#password"
    if "#" in vault_path:
        path, key = vault_path.rsplit("#", 1)
    else:
        parts = vault_path.rsplit("/", 1)
        if len(parts) == 2:
            path, key = parts
        else:
            raise ValueError(f"Invalid Vault path (need path/key or path#key): {vault_path}")

    response = client.secrets.kv.v2.read_secret_version(path=path, raise_on_deleted_version=True)
    data = response["data"]["data"]
    if key not in data:
        raise ValueError(f"Key '{key}' not found in Vault secret at '{path}'")
    return str(data[key])


def resolve_value(value: str) -> str:
    """Resolve all placeholders in a string value."""
    if "${" not in value:
        return value

    def replacer(match: re.Match) -> str:
        return _resolve_single(match.group(1))

    return _PLACEHOLDER_RE.sub(replacer, value)


def resolve_config(obj: Any) -> Any:
    """Recursively resolve all string values in a config dict/list."""
    if isinstance(obj, str):
        return resolve_value(obj)
    if isinstance(obj, dict):
        return {k: resolve_config(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [resolve_config(item) for item in obj]
    return obj
