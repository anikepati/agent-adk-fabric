"""
Configuration Loader — loads and validates all YAML configuration.

Handles:
- Browser configuration (browser.yaml)
- Execution settings
- Skill script registry (skills.yaml) with schema validation
"""

from __future__ import annotations

import yaml
from pathlib import Path
from typing import Optional, Any

from core.models import (
    SkillScript,
    ValidationRule,
    ValidationType,
    BrowserConfig,
    ExecutionConfig,
    ReplannerConfig,
)


class ConfigError(Exception):
    """Raised when configuration is invalid."""
    pass


class SkillRegistry:
    """
    Loads and manages skill scripts from YAML configuration.
    Thread-safe, immutable after load.
    """

    def __init__(self, skills: dict[str, SkillScript]):
        self._skills = skills

    @classmethod
    def from_yaml(cls, path: str | Path) -> SkillRegistry:
        """Load skill registry from YAML file."""
        path = Path(path)
        if not path.exists():
            raise ConfigError(f"Skills file not found: {path}")

        with open(path) as f:
            raw = yaml.safe_load(f)

        if not raw or "scripts" not in raw:
            raise ConfigError(f"Invalid skills file: missing 'scripts' key")

        skills = {}
        for key, definition in raw["scripts"].items():
            skill = cls._parse_skill(key, definition)
            skills[key] = skill

        return cls(skills)

    @staticmethod
    def _parse_skill(key: str, raw: dict) -> SkillScript:
        """Parse and validate a single skill definition."""
        required_fields = ["name", "script", "params_required"]
        for field_name in required_fields:
            if field_name not in raw:
                raise ConfigError(
                    f"Skill '{key}' missing required field: {field_name}"
                )

        # Parse validation rules
        validation_rules = []
        for rule_def in raw.get("validation", []):
            try:
                vtype = ValidationType(rule_def["type"])
            except (ValueError, KeyError):
                raise ConfigError(
                    f"Skill '{key}': invalid validation type: {rule_def.get('type')}"
                )
            validation_rules.append(
                ValidationRule(
                    type=vtype,
                    value=rule_def.get("value", ""),
                    selector=rule_def.get("selector"),
                    description=rule_def.get("description"),
                )
            )

        return SkillScript(
            key=key,
            name=raw["name"],
            description=raw.get("description", ""),
            version=raw.get("version", "1.0.0"),
            script=raw["script"].strip(),
            params_required=raw["params_required"],
            params_optional=raw.get("params_optional", {}),
            tags=raw.get("tags", []),
            timeout_seconds=raw.get("timeout_seconds", 120),
            max_retries=raw.get("max_retries", 3),
            validation=validation_rules,
            recovery_hints=raw.get("recovery_hints", []),
        )

    def get(self, workflow_name: str) -> SkillScript:
        """Get a skill script by name. Raises ConfigError if not found."""
        if workflow_name not in self._skills:
            available = ", ".join(sorted(self._skills.keys()))
            raise ConfigError(
                f"Unknown workflow: '{workflow_name}'. Available: {available}"
            )
        return self._skills[workflow_name]

    def list_skills(self) -> list[dict[str, str]]:
        """List all available skills with metadata."""
        return [
            {
                "key": s.key,
                "name": s.name,
                "version": s.version,
                "description": s.description,
                "tags": s.tags,
                "params_required": s.params_required,
            }
            for s in self._skills.values()
        ]

    @property
    def skill_count(self) -> int:
        return len(self._skills)


class AppConfig:
    """
    Complete application configuration.
    Loads from YAML files with sensible defaults.
    """

    def __init__(
        self,
        browser: BrowserConfig,
        execution: ExecutionConfig,
        replanner: ReplannerConfig,
        skill_registry: SkillRegistry,
    ):
        self.browser = browser
        self.execution = execution
        self.replanner = replanner
        self.skills = skill_registry

    @classmethod
    def load(
        cls,
        config_dir: str | Path = "config",
        skills_file: Optional[str] = None,
        browser_file: Optional[str] = None,
    ) -> AppConfig:
        """
        Load all configuration from a config directory.

        Args:
            config_dir: Directory containing YAML config files
            skills_file: Override path to skills.yaml
            browser_file: Override path to browser.yaml
        """
        config_dir = Path(config_dir)

        # Load browser config
        browser_path = Path(browser_file) if browser_file else config_dir / "browser.yaml"
        browser_config = BrowserConfig()
        execution_config = ExecutionConfig()
        replanner_config = ReplannerConfig()

        if browser_path.exists():
            with open(browser_path) as f:
                raw = yaml.safe_load(f) or {}

            browser_raw = raw.get("browser", {})
            browser_config = BrowserConfig(
                engine=browser_raw.get("engine", "chromium"),
                headless=browser_raw.get("headless", False),
                viewport_width=browser_raw.get("viewport", {}).get("width", 1280),
                viewport_height=browser_raw.get("viewport", {}).get("height", 900),
                default_timeout_ms=browser_raw.get("default_timeout_ms", 30000),
                navigation_timeout_ms=browser_raw.get("navigation_timeout_ms", 60000),
                blocked_patterns=browser_raw.get("blocked_patterns", []),
                storage_state_path=browser_raw.get("auth", {}).get("storage_state_path"),
                screenshot_dir=browser_raw.get("debug", {}).get("screenshot_dir", "./screenshots"),
                trace_on_failure=browser_raw.get("debug", {}).get("trace_on_failure", True),
                record_video=browser_raw.get("debug", {}).get("record_video", False),
            )

            exec_raw = raw.get("execution", {})
            execution_config = ExecutionConfig(
                max_retries=exec_raw.get("max_retries", 3),
                auto_retry_on_transient=exec_raw.get("auto_retry_on_transient", True),
                script_timeout_seconds=exec_raw.get("script_timeout_seconds", 120),
                page_state_max_elements=exec_raw.get("page_state_max_elements", 40),
            )

            replan_raw = raw.get("replanner", {})
            replanner_config = ReplannerConfig(
                model=replan_raw.get("model", "gemini-2.0-flash"),
                max_tokens=replan_raw.get("max_tokens", 4096),
                temperature=replan_raw.get("temperature", 0.1),
            )

        # Load skill registry
        skills_path = Path(skills_file) if skills_file else config_dir / "skills.yaml"
        skill_registry = SkillRegistry.from_yaml(skills_path)

        return cls(
            browser=browser_config,
            execution=execution_config,
            replanner=replanner_config,
            skill_registry=skill_registry,
        )
