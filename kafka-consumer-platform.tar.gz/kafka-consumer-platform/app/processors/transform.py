"""
Transform processor: apply JMESPath or mapping-based transformation.
"""
from __future__ import annotations

from typing import Any

import jmespath

from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult
from app.processors.base import BaseProcessor, ProcessorContext
from app.processors.registry import register_processor


@register_processor("transform")
class TransformProcessor(BaseProcessor):

    def __init__(self, config: dict[str, Any], context: ProcessorContext) -> None:
        super().__init__(config, context)
        self._mapping_expr: str | None = config.get("mapping_expr")
        self._mapping: dict[str, str] | None = config.get("mapping")
        self._compiled_expr = None
        if self._mapping_expr:
            self._compiled_expr = jmespath.compile(self._mapping_expr)

    async def process(self, message: ConsumerMessage) -> ProcessorResult:
        try:
            data = message.value
            if not isinstance(data, dict):
                return ProcessorResult.dlq(f"Expected dict, got {type(data).__name__}")

            if self._compiled_expr:
                result = self._compiled_expr.search(data)
                message.value = result
            elif self._mapping:
                transformed = {}
                for target_key, source_expr in self._mapping.items():
                    expr = jmespath.compile(source_expr)
                    transformed[target_key] = expr.search(data)
                message.value = transformed

            return ProcessorResult.success()

        except Exception as e:
            return ProcessorResult.dlq(f"Transform error: {e}", e)
