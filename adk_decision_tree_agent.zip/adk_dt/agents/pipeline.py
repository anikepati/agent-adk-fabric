"""
Pipeline Assembly — SequentialAgent combining Ingest → DecisionTree → Report.

Three usage patterns:

  1. Full pipeline (Excel file → evaluation → report):
     Uses IngestAgent → DecisionTreeAgent → ReportAgent

  2. Pre-loaded rows (rows already in state):
     Uses DecisionTreeAgent → ReportAgent (skip IngestAgent)

  3. Single-row evaluation (one row at a time):
     Uses DecisionTreeAgent alone with dt:current_row

All three patterns use the same DecisionTreeAgent — the difference
is just which companion agents you include in the pipeline.
"""

from google.adk.agents import SequentialAgent

from agents.ingest_agent import IngestAgent
from agents.decision_tree_agent import DecisionTreeAgent
from agents.report_agent import ReportAgent


def create_full_pipeline(
    config_path: str,
    excel_file: str,
    sheet_name: str = "Sheet1",
    dry_run: bool = True,
) -> SequentialAgent:
    """
    Full pipeline: Excel file → evaluation → report.

    Usage:
        pipeline = create_full_pipeline(
            config_path="config/lam_full_dag.yaml",
            excel_file="data/lam_data.xlsx",
        )
        runner = Runner(agent=pipeline, ...)
        async for event in runner.run_async(...):
            print(event)
    """
    return SequentialAgent(
        name="ValidationPipeline",
        description="Full Excel validation pipeline: ingest → evaluate → report",
        sub_agents=[
            IngestAgent(
                name="Ingest",
                description="Load Excel data into session state",
                excel_file=excel_file,
                sheet_name=sheet_name,
            ),
            DecisionTreeAgent(
                name="Evaluate",
                description="Evaluate decision trees against row data",
                config_path=config_path,
                default_dry_run=dry_run,
            ),
            ReportAgent(
                name="Report",
                description="Generate validation report from results",
                include_row_details=True,
            ),
        ],
    )


def create_evaluation_pipeline(
    config_path: str,
    dry_run: bool = True,
) -> SequentialAgent:
    """
    Evaluation pipeline: rows pre-loaded in state → evaluate → report.

    Pre-set dt:rows in session state before running.
    """
    return SequentialAgent(
        name="EvaluationPipeline",
        description="Evaluate pre-loaded rows against decision trees",
        sub_agents=[
            DecisionTreeAgent(
                name="Evaluate",
                description="Evaluate decision trees",
                config_path=config_path,
                default_dry_run=dry_run,
            ),
            ReportAgent(
                name="Report",
                description="Generate report",
            ),
        ],
    )


def create_single_row_agent(
    config_path: str,
    dry_run: bool = True,
) -> DecisionTreeAgent:
    """
    Single-row evaluation agent.

    Set dt:current_row in session state with a single row dict.
    """
    return DecisionTreeAgent(
        name="SingleRowEvaluator",
        description="Evaluate a single row against decision trees",
        config_path=config_path,
        default_dry_run=dry_run,
    )
