"""
Pipeline processor: chains N processors in sequential order.
Short-circuits on failure (RETRY or DLQ).
Each step receives the (potentially modified) message from the previous step.
"""
from __future__ import annotations

import logging
from typing import Any

from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult, ResultStatus
from app.processors.base import BaseProcessor, ProcessorContext
from app.processors.registry import create_processor, register_processor

logger = logging.getLogger(__name__)


@register_processor("pipeline")
class PipelineProcessor(BaseProcessor):

    def __init__(self, config: dict[str, Any], context: ProcessorContext) -> None:
        super().__init__(config, context)
        self._steps: list[BaseProcessor] = []
        self._step_configs: list[dict[str, Any]] = config.get("steps", [])

    async def startup(self) -> None:
        """Instantiate each step processor from config."""
        for i, step_conf in enumerate(self._step_configs):
            step_type = step_conf["type"]
            step_config = step_conf.get("config", {})
            step_processor = create_processor(
                processor_type=step_type,
                config=step_config,
                cluster_name=self.context.cluster_name,
                topic=f"{self.context.topic}:step-{i}:{step_type}",
            )
            await step_processor.startup()
            self._steps.append(step_processor)

        logger.info(
            "Pipeline initialized",
            extra={
                "topic": self.context.topic,
                "steps": [s.__class__.__name__ for s in self._steps],
            },
        )

    async def process(self, message: ConsumerMessage) -> ProcessorResult:
        if not self._steps:
            await self.startup()

        for i, step in enumerate(self._steps):
            try:
                result = await step.process(message)

                if result.status == ResultStatus.SUCCESS:
                    continue  # Proceed to next step
                elif result.status == ResultStatus.SKIP:
                    continue  # Skip this step but continue pipeline
                else:
                    # RETRY or DLQ: short-circuit the pipeline
                    logger.warning(
                        "Pipeline short-circuited",
                        extra={
                            "topic": self.context.topic,
                            "step": i,
                            "step_type": step.__class__.__name__,
                            "status": result.status.value,
                            "error": result.error,
                        },
                    )
                    return result

            except Exception as e:
                logger.error(
                    f"Pipeline step {i} raised exception",
                    extra={
                        "topic": self.context.topic,
                        "step": i,
                        "step_type": step.__class__.__name__,
                        "error": str(e),
                    },
                )
                return ProcessorResult.retry(
                    f"Pipeline step {i} ({step.__class__.__name__}) failed: {e}", e
                )

        return ProcessorResult.success()

    async def health_check(self) -> bool:
        return all(await step.health_check() for step in self._steps)

    async def shutdown(self) -> None:
        for step in self._steps:
            try:
                await step.shutdown()
            except Exception as e:
                logger.error(f"Error shutting down pipeline step: {e}")
