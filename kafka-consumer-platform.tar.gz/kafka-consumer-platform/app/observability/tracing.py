"""
OpenTelemetry tracing setup for distributed trace propagation.
"""
from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)


def setup_tracing(service_name: str = "kafka-consumer-platform") -> None:
    """Initialize OpenTelemetry tracing. No-op if dependencies are missing."""
    try:
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanExporter
        from opentelemetry.sdk.resources import Resource

        resource = Resource.create({
            "service.name": service_name,
            "service.instance.id": os.environ.get("HOSTNAME", "unknown"),
            "deployment.environment": os.environ.get("ENVIRONMENT", "production"),
        })

        provider = TracerProvider(resource=resource)

        # Configure exporter based on environment
        otlp_endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
        if otlp_endpoint:
            try:
                from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
                    OTLPSpanExporter,
                )
                exporter = OTLPSpanExporter(endpoint=otlp_endpoint)
                provider.add_span_processor(BatchSpanExporter(exporter))
            except ImportError:
                logger.warning("OTLP exporter not available")

        trace.set_tracer_provider(provider)
        logger.info("OpenTelemetry tracing initialized", extra={"service": service_name})

    except ImportError:
        logger.info("OpenTelemetry SDK not installed, tracing disabled")


def get_tracer(name: str = "kafka-consumer"):
    """Get a tracer instance. Returns a no-op tracer if OTel is not configured."""
    try:
        from opentelemetry import trace
        return trace.get_tracer(name)
    except ImportError:
        return None
