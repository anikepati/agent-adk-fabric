"""
Notify processor: send alert notifications via webhook/Slack/email.
"""
from __future__ import annotations

import json
from typing import Any

import httpx

from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult
from app.processors.base import BaseProcessor, ProcessorContext
from app.processors.registry import register_processor


@register_processor("notify")
class NotifyProcessor(BaseProcessor):

    def __init__(self, config: dict[str, Any], context: ProcessorContext) -> None:
        super().__init__(config, context)
        self._channel: str = config.get("channel", "webhook")
        self._webhook: str | None = config.get("webhook")
        self._template: str | None = config.get("template")
        self._condition: str | None = config.get("condition")
        self._client: httpx.AsyncClient | None = None

    async def startup(self) -> None:
        self._client = httpx.AsyncClient(timeout=httpx.Timeout(10.0))

    async def process(self, message: ConsumerMessage) -> ProcessorResult:
        if self._client is None:
            await self.startup()

        # Check condition if specified
        if self._condition:
            import jmespath
            expr = jmespath.compile(self._condition)
            if not expr.search(message.value if isinstance(message.value, dict) else {}):
                return ProcessorResult.skip("Notification condition not met")

        try:
            if self._channel == "slack" and self._webhook:
                return await self._send_slack(message)
            elif self._webhook:
                return await self._send_webhook(message)
            else:
                self.logger.warning("No notification channel configured")
                return ProcessorResult.success()

        except httpx.TimeoutException as e:
            # Notifications are best-effort; don't block processing
            self.logger.warning(f"Notification timeout: {e}")
            return ProcessorResult.success()
        except Exception as e:
            self.logger.warning(f"Notification failed: {e}")
            return ProcessorResult.success()

    async def _send_slack(self, message: ConsumerMessage) -> ProcessorResult:
        text = self._format_message(message)
        payload = {"text": text}

        response = await self._client.post(
            self._webhook,
            content=json.dumps(payload),
            headers={"Content-Type": "application/json"},
        )
        if response.status_code == 200:
            return ProcessorResult.success({"channel": "slack"})
        self.logger.warning(f"Slack webhook returned {response.status_code}")
        return ProcessorResult.success()

    async def _send_webhook(self, message: ConsumerMessage) -> ProcessorResult:
        payload = {
            "topic": message.topic,
            "partition": message.partition,
            "offset": message.offset,
            "data": message.value if isinstance(message.value, dict) else str(message.value),
        }
        response = await self._client.post(
            self._webhook,
            content=json.dumps(payload),
            headers={"Content-Type": "application/json"},
        )
        return ProcessorResult.success({"status_code": response.status_code})

    def _format_message(self, message: ConsumerMessage) -> str:
        if self._template:
            try:
                data = message.value if isinstance(message.value, dict) else {}
                return self._template.format(
                    topic=message.topic,
                    partition=message.partition,
                    offset=message.offset,
                    **data,
                )
            except (KeyError, IndexError):
                pass
        return f"[{message.topic}] New message at partition={message.partition} offset={message.offset}"

    async def shutdown(self) -> None:
        if self._client:
            await self._client.aclose()
