"""DAG executor v4 — topological sort into parallel-ready layers."""

import logging
from collections import defaultdict, deque
from typing import Any, Dict, List
from models.schemas import DAGConfig, DecisionNode

logger = logging.getLogger(__name__)


class DAGExecutor:
    def __init__(self, dag_config: DAGConfig):
        self.on_failure = dag_config.on_dependency_failure
        self.nodes: Dict[str, Dict] = {}
        self.layers: List[List[str]] = []

        for n in dag_config.nodes:
            tree_ids = n.tree_ids or ([n.tree_id] if n.tree_id else [])
            self.nodes[n.id] = {
                "tree_ids": tree_ids,
                "depends_on": n.depends_on,
                "status": "pending",
                "results": [],
            }

        self._validate()
        self.layers = self._topo_sort()
        logger.info(f"DAG: {len(self.nodes)} nodes, {len(self.layers)} layers")

    def _validate(self):
        ids = set(self.nodes.keys())
        for nid, n in self.nodes.items():
            for dep in n["depends_on"]:
                if dep not in ids:
                    raise ValueError(f"DAG node '{nid}' depends on unknown '{dep}'")

    def _topo_sort(self) -> List[List[str]]:
        in_deg = {nid: 0 for nid in self.nodes}
        adj = defaultdict(list)
        for nid, n in self.nodes.items():
            for dep in n["depends_on"]:
                adj[dep].append(nid)
                in_deg[nid] += 1

        queue = deque(nid for nid, d in in_deg.items() if d == 0)
        layers, done = [], 0
        while queue:
            layer = list(queue)
            layers.append(layer)
            queue.clear()
            for nid in layer:
                done += 1
                for nb in adj[nid]:
                    in_deg[nb] -= 1
                    if in_deg[nb] == 0:
                        queue.append(nb)
        if done != len(self.nodes):
            raise ValueError("Cycle detected in DAG")
        return layers

    def execute(self, row, row_id, tree_map, walk_tree_fn) -> Dict[str, Any]:
        for n in self.nodes.values():
            n["status"] = "pending"
            n["results"] = []

        report = {"row_id": row_id, "layers": [], "executed": 0, "skipped": 0}

        for layer_idx, layer in enumerate(self.layers):
            lr = {"layer": layer_idx, "nodes": []}
            for nid in layer:
                node = self.nodes[nid]
                if not self._deps_ok(node):
                    node["status"] = "skipped"
                    report["skipped"] += 1
                    lr["nodes"].append({"id": nid, "status": "skipped"})
                    continue

                node["status"] = "running"
                for tid in node["tree_ids"]:
                    tree = tree_map.get(tid)
                    if tree:
                        node["results"].append(walk_tree_fn(tree, row))
                node["status"] = "completed"
                report["executed"] += 1
                lr["nodes"].append({"id": nid, "status": "completed", "trees": len(node["results"])})
            report["layers"].append(lr)
        return report

    def _deps_ok(self, node) -> bool:
        for dep_id in node["depends_on"]:
            dep = self.nodes.get(dep_id)
            if not dep or dep["status"] != "completed":
                if self.on_failure == "abort":
                    raise RuntimeError(f"DAG abort: dependency '{dep_id}' not completed")
                if self.on_failure == "skip":
                    return False
        return True

    def all_results(self) -> List[Dict]:
        out = []
        for n in self.nodes.values():
            out.extend(n["results"])
        return out
