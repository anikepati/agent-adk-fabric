"""Enterprise Kafka Consumer Platform."""
