"""
agents/lien_validation_agent.py
=================================
LienValidationAgent — PACE/HERO, lien position, judgment/HOA/tax liens.

Reads BOTH title extracts to cross-validate lien data:
  - title_primary   : authoritative lien arrays
  - title_compare   : second source — flag discrepancies
  - ecar.action_log : prior TRU review history

ADK Integration:
  - Input  : reads {title_primary}, {title_compare}, {ecar} from state
  - Output : writes "lien_result" to session state
"""

from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm


LIEN_INSTRUCTION = """
You are LienValidationAgent in a Senior Lien Verification QA pipeline.

You receive BOTH title extracts plus the ECaR record.

Your scope: PACE/HERO detection, lien position validation, and
judgment/HOA/tax liens recorded before our mortgage.

CRITICAL: Reconcile lien arrays across BOTH extracts. If one extract
contains a lien the other missed, that is itself a high-severity finding.

───────────────────────────────────────────────────────────────
STEP 1 — PACE / HERO detection
───────────────────────────────────────────────────────────────
PACE/HERO liens may NOT be labelled "PACE" or "HERO" explicitly — they
can appear as "contractual assessment", "fixture filing", or assessment
related to solar/energy financing. HERO is a program under the PACE umbrella.

Check pace_hero_liens in BOTH title_primary AND title_compare.
If EITHER has non-empty pace_hero_liens → flag CRITICAL PACE_HERO_LIEN_DETECTED.
Set end_process=true. Generate ARROW activity:
  Type=Request, Party=Internal, Result=Additional Research Needed,
  Activity text="Lien position issue, referred to TRU for resolution.",
  Deficiency status=Satisfied.

If only ONE extract found a PACE/HERO lien, add an additional MEDIUM flag
EXTRACT_PACE_MISMATCH — one extraction may have missed it.

───────────────────────────────────────────────────────────────
STEP 2 — Lien position validation  (skip if end_process=true)
───────────────────────────────────────────────────────────────
Find our lien in title_primary.mortgage_information (where our_lien=true).
Get its position.
- If position is not "1st" → flag HIGH WRONG_LIEN_POSITION with the same
  ARROW activity as above.

Check the same field in title_compare. If the positions differ between
extracts → flag HIGH LIEN_POSITION_EXTRACT_MISMATCH.

───────────────────────────────────────────────────────────────
STEP 3 — Position changed since TRU  (skip if end_process=true)
───────────────────────────────────────────────────────────────
Check ecar.action_log for any entry where:
  - category contains "HEQ Title Issue" OR "TRU"
  - action mentions confirmed lien position
If a prior TRU review exists AND the current title_primary position
differs from what TRU previously confirmed → flag HIGH
LIEN_POSITION_CHANGED_SINCE_TRU. Include the same ARROW activity
PLUS an ECaR Senior Review comment block.

───────────────────────────────────────────────────────────────
STEP 4 — Judgment / HOA / tax / other liens  (skip if end_process=true)
───────────────────────────────────────────────────────────────
Collect all entries with recorded_before_our_mortgage=true from BOTH
title_primary.judgment_lien_information and
title_compare.judgment_lien_information.

If the counts differ between extracts → flag HIGH
JUDGMENT_LIEN_COUNT_MISMATCH listing which liens are unique to each extract.

If the UNION of both lists is non-empty → flag HIGH JUDGMENT_LIENS_PRESENT
listing every such lien; route to "Sending File to TRU" section.

───────────────────────────────────────────────────────────────
CASE CONTEXT
───────────────────────────────────────────────────────────────
case_id: {case_id}

title_primary:
{title_primary}

title_compare:
{title_compare}

ecar:
{ecar}

───────────────────────────────────────────────────────────────
OUTPUT
───────────────────────────────────────────────────────────────
Return ONLY a valid JSON object (no markdown, no code fences, no preamble):

{{
  "pace_hero_detected": true | false,
  "pace_extract_mismatch": true | false,
  "lien_position_primary": "<string>" | null,
  "lien_position_compare": "<string>" | null,
  "lien_position_valid": true | false,
  "lien_position_changed_since_tru": true | false | null,
  "judgment_liens_prior_primary": <int>,
  "judgment_liens_prior_compare": <int>,
  "judgment_liens_found": true | false,
  "end_process": true | false,
  "flags": [
    {{
      "severity": "info" | "medium" | "high" | "critical",
      "code": "<UPPER_SNAKE_CODE>",
      "message": "<human readable>",
      "arrow_activity": null | {{
        "type": "Request",
        "party": "Internal",
        "result": "Additional Research Needed",
        "activity_text": "...",
        "deficiency_status": "Satisfied"
      }}
    }}
  ],
  "ecar_senior_review_comment": null | {{
    "screen": "ECaR Contacts → Actions",
    "category": "Verification",
    "action_type": "HEQ Senior Review",
    "comment_lines": ["..."]
  }},
  "summary": "<one-sentence summary>"
}}
"""


def build_lien_validation_agent(model: str = "gemini-2.0-flash") -> LlmAgent:
    """Returns the configured LienValidationAgent."""
    return LlmAgent(
        name="LienValidationAgent",
        model=LiteLlm(model=f"gemini/{model}"),
        description=(
            "Validates lien data from two title report extracts: "
            "PACE/HERO detection, lien position, and judgment/HOA/tax "
            "liens recorded before our mortgage."
        ),
        instruction=LIEN_INSTRUCTION,
        output_key="lien_result",
    )
