"""
Database Action Handler — upserts validation results.
Supports SQLite, PostgreSQL, MySQL via connection string.
"""

import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)

_engines: Dict[str, Any] = {}


def _get_engine(connection_string: str):
    if connection_string not in _engines:
        try:
            from sqlalchemy import create_engine
            _engines[connection_string] = create_engine(connection_string, pool_pre_ping=True, echo=False)
        except ImportError:
            _engines[connection_string] = None
    return _engines[connection_string]


def update_db(
    connection_string: str,
    table: str,
    row_id: str,
    row_id_column: str,
    values: Dict[str, Any],
) -> Dict[str, Any]:
    try:
        engine = _get_engine(connection_string)

        if engine is None:
            return _fallback_sqlite(connection_string, table, row_id, row_id_column, values)

        from sqlalchemy import text

        set_clause = ", ".join(f"{k} = :{k}" for k in values.keys())
        columns = ", ".join(values.keys())
        placeholders = ", ".join(f":{k}" for k in values.keys())

        with engine.begin() as conn:
            check = conn.execute(text(f"SELECT 1 FROM {table} WHERE {row_id_column} = :rid"), {"rid": row_id})
            if check.fetchone():
                conn.execute(text(f"UPDATE {table} SET {set_clause} WHERE {row_id_column} = :rid"), {**values, "rid": row_id})
                logger.info(f"  [DB] Updated row {row_id}")
            else:
                conn.execute(text(f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"), values)
                logger.info(f"  [DB] Inserted row {row_id}")

        return {"status": "success", "operation": "upsert", "row_id": row_id}

    except Exception as e:
        logger.error(f"  [DB] Error: {e}")
        return {"status": "error", "error": str(e), "row_id": row_id}


def _fallback_sqlite(connection_string, table, row_id, row_id_column, values):
    import sqlite3
    db_path = connection_string.replace("sqlite:///", "")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cols_def = ", ".join(f"{k} TEXT" for k in values.keys())
    cursor.execute(f"CREATE TABLE IF NOT EXISTS {table} ({cols_def})")
    columns = ", ".join(values.keys())
    placeholders = ", ".join("?" for _ in values)
    cursor.execute(f"INSERT INTO {table} ({columns}) VALUES ({placeholders})", list(values.values()))
    conn.commit()
    conn.close()
    return {"status": "success", "operation": "insert", "row_id": row_id}
