"""
Workflow Orchestrator — the enterprise entry point.

Ties together:  config → runtime → ADK agents → observability
"""

from __future__ import annotations

import logging
from typing import Optional

from google.adk.sessions import InMemorySessionService
from google.adk.runners import Runner
from google.genai import types

from core.config import AppConfig, ConfigError
from core.models import WorkflowStatus
from tools.adk_tools import init_runtime, shutdown_runtime
from agents.agent import build_agents
from observability.tracker import (
    ExecutionTracker,
    MetricsCollector,
    AuditTrail,
    setup_logging,
)

logger = logging.getLogger("orchestrator")


# ═══════════════════════════════════════════════════════════════
# Result
# ═══════════════════════════════════════════════════════════════

class WorkflowResult:
    """Public result object returned by the orchestrator."""

    def __init__(
        self,
        success: bool,
        status: WorkflowStatus,
        attempts: int = 0,
        error: Optional[str] = None,
        script_history: Optional[list] = None,
        execution_id: Optional[str] = None,
        duration_ms: int = 0,
    ):
        self.success = success
        self.status = status
        self.attempts = attempts
        self.error = error
        self.script_history = script_history or []
        self.execution_id = execution_id
        self.duration_ms = duration_ms

    def __repr__(self):
        return (
            f"WorkflowResult(success={self.success}, status={self.status.value}, "
            f"attempts={self.attempts}, duration_ms={self.duration_ms})"
        )

    def summary(self) -> str:
        parts = [
            f"Status     : {self.status.value.upper()}",
            f"Attempts   : {self.attempts}",
            f"Duration   : {self.duration_ms}ms",
        ]
        if self.success and self.attempts == 1:
            parts.append("LLM tokens : 0 (happy path)")
        elif self.success:
            parts.append(f"Replans    : {self.attempts - 1}")
        if self.error:
            parts.append(f"Error      : {self.error}")
        if self.execution_id:
            parts.append(f"Exec ID    : {self.execution_id}")

        if self.script_history:
            parts.append("\nAttempt history:")
            for e in self.script_history:
                tag = "OK" if e.get("success") else "FAIL"
                parts.append(
                    f"  [{tag}] #{e['attempt']}  "
                    f"{e.get('progress_pct', 0):.0f}%  "
                    f"{e.get('duration_ms', 0)}ms"
                )
                if e.get("error"):
                    parts.append(f"        → {e['error'][:120]}")
        return "\n".join(parts)


# ═══════════════════════════════════════════════════════════════
# Orchestrator
# ═══════════════════════════════════════════════════════════════

class WorkflowOrchestrator:
    """
    Execute browser automation workflows.

    Usage:
        orch = WorkflowOrchestrator.from_config("./config")
        result = orch.execute(
            "create_parent_business_unit",
            params={"bu_name": "ACME", ...},
            base_url="https://org.crm.dynamics.com",
        )
        print(result.summary())
    """

    def __init__(self, config: AppConfig):
        self._config = config
        self._metrics = MetricsCollector()
        self._audit = AuditTrail()
        self._session_svc = InMemorySessionService()

    @classmethod
    def from_config(
        cls,
        config_dir: str = "./config",
        skills_file: Optional[str] = None,
        log_level: str = "INFO",
        json_logs: bool = True,
    ) -> WorkflowOrchestrator:
        setup_logging(level=log_level, json_format=json_logs)
        cfg = AppConfig.load(config_dir=config_dir, skills_file=skills_file)
        logger.info(
            "Config loaded (%d skills, engine=%s)",
            cfg.skills.skill_count,
            cfg.browser.engine,
        )
        return cls(cfg)

    # ── public API ────────────────────────────────────────────

    def execute(
        self,
        workflow_name: str,
        params: dict,
        base_url: str = "",
        user_id: str = "default",
    ) -> WorkflowResult:
        """Execute a single workflow."""

        # Resolve skill
        try:
            skill = self._config.skills.get(workflow_name)
        except ConfigError as exc:
            return WorkflowResult(success=False, status=WorkflowStatus.FAILED, error=str(exc))

        # Merge params
        all_params = {**params}
        if base_url:
            all_params["base_url"] = base_url
        missing = skill.validate_params(all_params)
        if missing:
            return WorkflowResult(
                success=False, status=WorkflowStatus.FAILED,
                error=f"Missing parameters: {missing}",
            )

        # Tracking
        tracker = ExecutionTracker(
            workflow_name=workflow_name,
            params=all_params,
            metrics=self._metrics,
            audit=self._audit,
        )

        # Runtime lifecycle
        init_runtime(self._config)
        try:
            return self._run(skill, all_params, user_id, tracker)
        except Exception as exc:
            logger.error("Workflow crashed: %s", exc, exc_info=True)
            tracker.finalize(
                status=WorkflowStatus.FAILED,
                failure_reason=f"Orchestrator error: {exc}",
            )
            return WorkflowResult(
                success=False, status=WorkflowStatus.FAILED,
                error=str(exc),
                execution_id=tracker.execution.execution_id,
            )
        finally:
            shutdown_runtime()

    def list_workflows(self) -> list[dict]:
        return self._config.skills.list_skills()

    def get_metrics(self) -> dict:
        return self._metrics.get_summary()

    # ── private ───────────────────────────────────────────────

    def _run(self, skill, params, user_id, tracker) -> WorkflowResult:
        agent = build_agents(model=self._config.replanner.model)
        runner = Runner(
            agent=agent,
            app_name="browser_agent",
            session_service=self._session_svc,
        )
        session = self._session_svc.create_session(
            app_name="browser_agent",
            user_id=user_id,
        )

        # Seed state
        s = session.state
        s["workflow_name"] = skill.key
        s["workflow_params"] = params
        s["current_script"] = skill.script
        s["max_retries"] = skill.max_retries
        s["recovery_hints"] = skill.recovery_hints
        s["validation_rules"] = [
            {"type": r.type.value, "value": r.value, "selector": r.selector}
            for r in skill.validation
        ]
        s["attempt_number"] = 1
        s["needs_replan"] = False
        s["task_complete"] = False
        s["task_failed"] = False
        s["script_history"] = []

        logger.info(
            "Starting workflow=%s params=%s",
            skill.key,
            {k: v for k, v in params.items() if k not in ("password", "token", "secret")},
        )

        msg = types.Content(
            role="user",
            parts=[types.Part.from_text(f"Execute workflow: {skill.key}")],
        )

        for event in runner.run(
            user_id=user_id,
            session_id=session.id,
            new_message=msg,
        ):
            if event.is_final_response() and event.content:
                for p in event.content.parts:
                    if hasattr(p, "text") and p.text:
                        logger.debug("[%s] %s", getattr(event, "agent_name", "?"), p.text[:200])

            if s.get("task_complete"):
                break

        # Build result
        failed = s.get("task_failed", False)
        status = WorkflowStatus.FAILED if failed else WorkflowStatus.SUCCESS
        tracker.finalize(status=status, failure_reason=s.get("failure_reason"))

        return WorkflowResult(
            success=not failed,
            status=status,
            attempts=s.get("attempt_number", 1),
            error=s.get("failure_reason"),
            script_history=s.get("script_history", []),
            execution_id=tracker.execution.execution_id,
            duration_ms=tracker.execution.total_duration_ms,
        )
