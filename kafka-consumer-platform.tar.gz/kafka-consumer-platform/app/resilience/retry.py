"""
Retry logic with exponential backoff and jitter.
"""
from __future__ import annotations

import logging
import random
import time

from app.config.models import RetryConfig

logger = logging.getLogger(__name__)


class RetryHandler:
    """Manages retry attempts for a single message processing cycle."""

    def __init__(self, config: RetryConfig) -> None:
        self._config = config

    def should_retry(self, attempt: int) -> bool:
        return attempt < self._config.max_attempts

    def compute_delay_seconds(self, attempt: int) -> float:
        """Exponential backoff with jitter."""
        base_delay_ms = self._config.backoff_base_ms * (2**attempt)
        jitter_ms = random.uniform(0, self._config.backoff_base_ms)
        delay_ms = min(base_delay_ms + jitter_ms, self._config.backoff_max_ms)
        return delay_ms / 1000.0

    def wait(self, attempt: int) -> None:
        delay = self.compute_delay_seconds(attempt)
        logger.debug(
            "Retry backoff",
            extra={"attempt": attempt + 1, "delay_s": round(delay, 2)},
        )
        time.sleep(delay)
