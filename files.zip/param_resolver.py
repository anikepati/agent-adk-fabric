"""
Parameter Resolver — resolves {placeholder} tokens in script text.

Handles:
- Simple substitution: {bu_name} → "ACME Corp"
- Missing parameter detection
- Unresolved placeholder warnings
- Injection prevention (basic sanitization)
"""

from __future__ import annotations

import re
from typing import Any


class ParamResolutionError(Exception):
    """Raised when parameter resolution fails."""
    pass


# Pattern matches {param_name} but not {{escaped_braces}}
_PLACEHOLDER_PATTERN = re.compile(r"\{(\w+)\}")


def resolve_params(template: str, params: dict[str, Any]) -> str:
    """
    Resolve {placeholder} tokens in a script template.

    Args:
        template: Script text with {param} placeholders
        params: Parameter values to substitute

    Returns:
        Resolved script text

    Raises:
        ParamResolutionError: If required placeholders have no value
    """
    unresolved = []

    def replacer(match: re.Match) -> str:
        key = match.group(1)
        if key in params:
            value = str(params[key])
            return _sanitize_value(value)
        unresolved.append(key)
        return match.group(0)

    result = _PLACEHOLDER_PATTERN.sub(replacer, template)

    if unresolved:
        raise ParamResolutionError(
            f"Unresolved parameters in script: {sorted(set(unresolved))}"
        )

    return result


def find_placeholders(template: str) -> list[str]:
    """Extract all placeholder names from a template."""
    return list(set(_PLACEHOLDER_PATTERN.findall(template)))


def _sanitize_value(value: str) -> str:
    """
    Basic sanitization to prevent script injection.
    Escapes characters that could break Playwright API calls.
    """
    # Escape backslashes and quotes that would break string literals
    value = value.replace("\\", "\\\\")
    value = value.replace('"', '\\"')
    value = value.replace("'", "\\'")
    # Remove control characters
    value = "".join(c for c in value if ord(c) >= 32 or c in ("\n", "\t"))
    return value


def validate_params(
    params: dict[str, Any],
    required: list[str],
    optional: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Validate and merge parameters with defaults.

    Args:
        params: Provided parameters
        required: Required parameter names
        optional: Optional parameters with default values

    Returns:
        Complete parameter dict with defaults applied

    Raises:
        ParamResolutionError: If required parameters are missing
    """
    missing = [p for p in required if p not in params]
    if missing:
        raise ParamResolutionError(
            f"Missing required parameters: {missing}"
        )

    merged = {}
    if optional:
        merged.update(optional)
    merged.update(params)

    return merged
