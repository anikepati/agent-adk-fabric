# Senior Lien Verification QA Pipeline — Google ADK

A genuine Google Agent Development Kit (ADK) implementation. Every agent
is a real `LlmAgent`; the orchestrator is a real `SequentialAgent`; the
runner is the real `InMemoryRunner`. No fallbacks, no stubs.

---

## Input Contract

The pipeline consumes **five** data sources per case, loaded into ADK
session state before the pipeline runs:

| State Key       | Type               | Purpose                                      |
| --------------- | ------------------ | -------------------------------------------- |
| `ecar`          | ECaR DB record     | Source of truth for borrower, address, vesting |
| `si_primary`    | Security Instrument JSON | Authoritative SI extraction            |
| `si_compare`    | Security Instrument JSON | Second SI extraction to cross-validate |
| `title_primary` | Title Report JSON  | Authoritative title report extraction        |
| `title_compare` | Title Report JSON  | Second title extraction to cross-validate    |

Each agent reads what it needs via `{state_key}` placeholders in its
`instruction`. Each agent writes its output to state via `output_key`.

---

## Agents

### 1. `IngestAgent` → writes `ingest_result`
Reads `{case_id}`, `{ecar}`. Validates required ECaR fields; derives
ICMP account number by stripping first 3 digits.

### 2. `SecurityInstrumentAgent` → writes `si_result`
Reads `{si_primary}`, `{si_compare}`, `{ecar}`. Performs **three-way
reconciliation**:
- Step 1 — `si_primary` vs `si_compare`: extraction consistency
- Step 2 — `si_primary` vs `ecar`: SI vs DB authority
- Step 3 — `si_compare` vs `ecar`: cross-check

Emits `SI_PRIMARY_VS_COMPARE_*` flags when the two extracts disagree
(data quality issue from extraction layer).

### 3. `TitleReportAgent` → writes `title_result`
Reads `{title_primary}`, `{title_compare}`, `{ecar}`. Handles:
- Extract consistency (deed, mortgage, lien counts, CBR, ADCON)
- ADCON alert → email action
- CBR address discrepancy → ARROW deficiency
- Deed grantees vs ECaR vesting
- Our mortgage presence on title

### 4. `LienValidationAgent` → writes `lien_result`
Reads `{title_primary}`, `{title_compare}`, `{ecar}`. Handles:
- PACE/HERO detection from **either** extract → halt pipeline
- Lien position validation (cross-checks between extracts)
- Position changed since prior TRU review
- Judgment/HOA/tax liens recorded before our mortgage
  (union across both extracts; count-mismatch also flagged)

### 5. `ReportAgent` → writes `report`
Reads `{ingest_result}`, `{si_result}`, `{title_result}`, `{lien_result}`.
Deduplicates flags by code, ranks by severity, determines disposition,
and consolidates all ARROW activities, ECaR actions, and email actions.

---

## Disposition Rules

| Disposition    | Trigger                                          |
| -------------- | ------------------------------------------------ |
| `END_PROCESS`  | `lien_result.end_process == true` (PACE/HERO)    |
| `REFER_TRU`    | Any critical or high flag                        |
| `CAUTION`      | Only medium flags                                |
| `CLEAR`        | No flags, or only info flags                     |

---

## Running

```bash
# 1. Install ADK with LiteLLM support
pip install "google-adk[extensions]"

# 2. Set your Gemini API key
export GOOGLE_API_KEY=your-key-here

# 3. Run a single case
python main.py --case ECAR-2024-001

# 4. Run all cases
python main.py

# 5. List available cases
python main.py --list

# 6. Override the model
python main.py --case ECAR-2024-002 --model gemini-2.0-flash
```

---

## How the ADK Pieces Fit

```
┌───────────────────────────────────────────────────────────────┐
│  context_loader.build_session_state(case_id)                  │
│    → { ecar, si_primary, si_compare,                          │
│        title_primary, title_compare, case_id }                │
└──────────────────────────┬────────────────────────────────────┘
                           │ state_delta
                           ▼
┌───────────────────────────────────────────────────────────────┐
│  InMemoryRunner(agent=SequentialAgent, app_name=...)          │
│    session_service.create_session(state=...)                  │
│    run_async(user_id, session_id, new_message)                │
└──────────────────────────┬────────────────────────────────────┘
                           ▼
┌───────────────────────────────────────────────────────────────┐
│  SequentialAgent "SeniorLienVerificationPipeline"             │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │ IngestAgent              → output_key: ingest_result    │  │
│  │ SecurityInstrumentAgent  → output_key: si_result        │  │
│  │ TitleReportAgent         → output_key: title_result     │  │
│  │ LienValidationAgent      → output_key: lien_result      │  │
│  │ ReportAgent              → output_key: report           │  │
│  └─────────────────────────────────────────────────────────┘  │
└──────────────────────────┬────────────────────────────────────┘
                           ▼
┌───────────────────────────────────────────────────────────────┐
│  session.state["report"]  — final QA disposition              │
└───────────────────────────────────────────────────────────────┘
```

Each agent's `instruction` contains `{placeholder}` tokens. ADK
substitutes these from the session state at invocation time. This is
how state flows between agents — no manual chaining.

---

## Project Structure

```
lien_qa_adk/
├── agents/
│   ├── ingest_agent.py              LlmAgent + instruction + output_key
│   ├── security_instrument_agent.py LlmAgent (3-way reconciliation)
│   ├── title_report_agent.py        LlmAgent (3-way reconciliation)
│   ├── lien_validation_agent.py     LlmAgent (union of liens from both extracts)
│   ├── report_agent.py              LlmAgent (aggregates all 4 prior results)
│   └── pipeline.py                  SequentialAgent factory
├── tools/
│   └── context_loader.py            Builds the session state dict
├── data/sample_inputs/
│   ├── ecar_db.json
│   ├── security_instrument_primary.json
│   ├── security_instrument_compare.json
│   ├── title_report_primary.json
│   └── title_report_compare.json
├── main.py                          InMemoryRunner entry point
└── requirements.txt
```

---

## requirements.txt

```
google-adk[extensions]>=1.31.0
```
