"""
agents/ingest_agent.py
=======================
IngestAgent — ECaR database validation + ICMP account derivation.

ADK Integration:
  - Input  : reads {ecar} and {case_id} from session state
  - Output : writes "ingest_result" to session state via output_key
"""

from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm


INGEST_INSTRUCTION = """
You are IngestAgent in a Senior Lien Verification QA pipeline.

You will receive an ECaR database record for a single case. Your job:

1. Derive the ICMP account number: strip the FIRST THREE digits from
   ecar.account_number.
   Example: 6506501234567 → 6501234567.
2. Confirm the pre-computed ecar.icmp_account_number matches your derivation.
3. Validate all required ECaR fields are present (non-null, non-empty):
   - ecar.real_estate.property_address
   - ecar.real_estate.city
   - ecar.real_estate.state
   - ecar.real_estate.zip
   - ecar.real_estate.county
   - ecar.real_estate.vesting
   - ecar.borrowers (must be non-empty list)

CASE CONTEXT:
case_id: {case_id}
ecar: {ecar}

Return ONLY a valid JSON object (no markdown, no code fences, no preamble)
with this exact schema:

{{
  "icmp_account_number": "<string>",
  "icmp_derivation_valid": true | false,
  "ecar_validated": true | false,
  "missing_fields": ["<field_path>"],
  "borrower_count": <int>,
  "summary": "<one sentence>",
  "flags": [
    {{
      "severity": "info" | "medium" | "high" | "critical",
      "code": "<UPPER_SNAKE_CODE>",
      "message": "<human readable>"
    }}
  ]
}}
"""


def build_ingest_agent(model: str = "gemini-2.0-flash") -> LlmAgent:
    """Returns the configured IngestAgent."""
    return LlmAgent(
        name="IngestAgent",
        model=LiteLlm(model=f"gemini/{model}"),
        description=(
            "Validates ECaR database fields and derives the ICMP account "
            "number by stripping the first 3 digits from the ECaR account."
        ),
        instruction=INGEST_INSTRUCTION,
        output_key="ingest_result",
    )
