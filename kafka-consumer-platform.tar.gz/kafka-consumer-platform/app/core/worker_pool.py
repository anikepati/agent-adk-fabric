"""
Worker pool wrapper providing lifecycle management and metrics.
"""
from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger(__name__)


class WorkerPool:
    """Managed ThreadPoolExecutor for message processing."""

    def __init__(self, max_workers: int = 10) -> None:
        self._max_workers = max_workers
        self._executor = ThreadPoolExecutor(
            max_workers=max_workers,
            thread_name_prefix="worker",
        )
        logger.info("Worker pool created", extra={"max_workers": max_workers})

    @property
    def executor(self) -> ThreadPoolExecutor:
        return self._executor

    @property
    def max_workers(self) -> int:
        return self._max_workers

    def shutdown(self, wait: bool = True, timeout: float = 30.0) -> None:
        logger.info("Worker pool shutting down", extra={"wait": wait})
        self._executor.shutdown(wait=wait)
        logger.info("Worker pool stopped")
