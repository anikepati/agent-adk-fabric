"""
ADK Agent Entry Point — __init__.py for `adk web` and `adk run`.

This file exposes the root agent for ADK discovery.
"""

from agents.pipeline import create_full_pipeline

# Default agent for `adk web` / `adk run`
root_agent = create_full_pipeline(
    config_path="config/lam_full_dag.yaml",
    excel_file="data/lam_data.xlsx",
    dry_run=True,
)
