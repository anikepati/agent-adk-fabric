"""
agents/pipeline.py
===================
Assembles the five LlmAgents into a SequentialAgent that executes:

  IngestAgent → SecurityInstrumentAgent → TitleReportAgent
              → LienValidationAgent → ReportAgent

Each agent writes its output to session state via output_key,
and downstream agents reference earlier outputs via {state_key}
placeholders in their instructions.
"""

from google.adk.agents import SequentialAgent

from .ingest_agent              import build_ingest_agent
from .security_instrument_agent import build_si_agent
from .title_report_agent        import build_title_report_agent
from .lien_validation_agent     import build_lien_validation_agent
from .report_agent              import build_report_agent


def build_pipeline(model: str = "gemini-2.0-flash") -> SequentialAgent:
    """
    Build the full Senior Lien Verification QA pipeline as a
    Google ADK SequentialAgent.

    Args:
        model: The Gemini model name (default: gemini-2.0-flash).

    Returns:
        A SequentialAgent that runs the 5 sub-agents in order.
    """
    return SequentialAgent(
        name="SeniorLienVerificationPipeline",
        description=(
            "End-to-end Senior Lien Verification QA pipeline. "
            "Reconciles two Security Instrument extracts and two Title "
            "Report extracts against the ECaR database, then produces a "
            "final disposition with ARROW activities, ECaR actions, and "
            "processor next-steps."
        ),
        sub_agents=[
            build_ingest_agent(model),
            build_si_agent(model),
            build_title_report_agent(model),
            build_lien_validation_agent(model),
            build_report_agent(model),
        ],
    )
