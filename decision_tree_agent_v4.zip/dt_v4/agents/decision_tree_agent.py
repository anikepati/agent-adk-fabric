"""
DecisionTreeAgent v4 — merged best of both approaches.

From eval()-based version:
  ✓ output_key for easy SequentialAgent chaining
  ✓ decision_tree accepts str | dict (YAML string or pre-parsed)
  ✓ calculated_fields for derived values
  ✓ state_delta in Event for clean state propagation

From operator-registry version:
  ✓ 14-operator registry (no eval, no exec)
  ✓ Pydantic schema validation (fail-fast)
  ✓ Recursive tree nesting (on_true/on_false/next_decision)
  ✓ Null/NaN-safe type coercion
  ✓ Full decision path audit trail
  ✓ DAG support with topological sort
  ✓ Exception detection from actions
  ✓ dt:passed boolean for downstream routing

New in v4:
  ✓ Safe calculated_fields (add, subtract, multiply, divide, percent,
    coalesce, concat, lookup, constant — no eval)
  ✓ Three config sources: constructor dict/str, state yaml, state path
  ✓ state_prefix for multi-instance pipelines
  ✓ Flat + DAG mode auto-detected from config

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STATE CONTRACT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  INPUT:
    {p}:row              — dict of column→value (the row)
    {p}:config_path      — (optional) YAML file path
    {p}:config_yaml      — (optional) raw YAML string

  OUTPUT:
    {p}:decisions         — per-tree decision records (nested)
    {p}:actions           — flat action list (non-none only)
    {p}:exceptions        — exception actions only
    {p}:calculated_fields — computed derived values
    {p}:passed            — True if zero exceptions
    {p}:status            — completed | failed | no_data
    {p}:error             — error message on failure
    {p}:dag_report        — (DAG mode only) layer execution report

  Where {p} is the state_prefix (default: "dt").
"""

import logging
import yaml
from typing import Any, AsyncIterator, Dict, List, Optional, Union

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.genai import types

from models.schemas import DecisionTreeConfig
from engine.evaluator import evaluate, compute_fields
from engine.walker import walk_tree, walk_all, collect_actions
from engine.dag_executor import DAGExecutor

logger = logging.getLogger(__name__)


class DecisionTreeAgent(BaseAgent):
    """
    Deterministic decision tree evaluator. No LLM calls.
    One row + YAML config → structured decisions.

    Accepts config as:
      - Constructor: decision_tree="yaml string" or decision_tree={dict}
      - Constructor: config_path="path/to/file.yaml"
      - State: dt:config_yaml or dt:config_path
    """

    # ── Constructor fields ───────────────────────────────────
    decision_tree: Optional[Union[str, Dict]] = None
    """YAML string or pre-parsed dict. Highest priority config source."""

    config_path: Optional[str] = None
    """File path to YAML config."""

    output_key: str = "decision_tree_result"
    """Key under which the full output dict is stored in state.
    Useful for SequentialAgent chaining: downstream reads state[output_key]."""

    state_prefix: str = "dt"
    """Prefix for individual state keys (dt:row, dt:actions, etc.).
    Change to run multiple DT agents in one pipeline."""

    model_config = {"arbitrary_types_allowed": True}

    # ── Core execution ───────────────────────────────────────

    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncIterator[types.Content]:
        p = self.state_prefix

        try:
            # 1. Read row from state
            row = ctx.session.state.get(f"{p}:row")
            if not row:
                self._set(ctx, "status", "no_data")
                self._set(ctx, "error", "No row in state")
                yield self._text(f"No data. Set {p}:row before calling.")
                return

            # Make a copy so calculated fields don't mutate the original
            row = dict(row)

            # 2. Load config
            config = self._load_config(ctx)
            if not config:
                self._set(ctx, "status", "failed")
                self._set(ctx, "error", "No config found")
                yield self._text("No config. Set decision_tree, config_path, or state config.")
                return

            # 3. Compute calculated fields (safe, no eval)
            calc_output = {}
            if config.calculated_fields:
                calc_output = compute_fields(config.calculated_fields, row)

            # 4. Evaluate decision trees
            tree_map = {t.id: t for t in config.decision_trees}
            has_dag = config.dag is not None
            dag_report = None

            if has_dag:
                dag = DAGExecutor(config.dag)
                dag_report = dag.execute(row, str(row.get("ID", "?")), tree_map, walk_tree)
                decisions = dag.all_results()
            else:
                decisions = walk_all(config.decision_trees, row)

            # 5. Flatten actions + extract exceptions
            all_actions = []
            for d in decisions:
                all_actions.extend(collect_actions(d))

            exceptions = [
                a for a in all_actions
                if "exception" in str(a.get("endpoint", "")).lower()
                or "exception_id" in (a.get("payload") or {})
            ]

            passed = len(exceptions) == 0

            # 6. Build full output (for output_key)
            output = {
                "decisions": decisions,
                "actions": all_actions,
                "exceptions": exceptions,
                "calculated_fields": calc_output,
                "passed": passed,
                "status": "completed",
                "mode": "dag" if has_dag else "flat",
            }
            if dag_report:
                output["dag_report"] = dag_report

            # 7. Write to state — both output_key (single dict) and individual keys
            ctx.session.state[self.output_key] = output

            self._set(ctx, "decisions", decisions)
            self._set(ctx, "actions", all_actions)
            self._set(ctx, "exceptions", exceptions)
            self._set(ctx, "calculated_fields", calc_output)
            self._set(ctx, "passed", passed)
            self._set(ctx, "status", "completed")
            self._set(ctx, "error", None)
            if dag_report:
                self._set(ctx, "dag_report", dag_report)

            # 8. Summary message
            mode = "DAG" if has_dag else "FLAT"
            if exceptions:
                exc_ids = [str(e.get("payload",{}).get("exception_id","?")) for e in exceptions]
                summary = (
                    f"[{mode}] {len(all_actions)} actions, "
                    f"{len(exceptions)} exception(s): [{', '.join(exc_ids)}]"
                )
            else:
                summary = f"[{mode}] {len(all_actions)} actions, all validations passed."

            if calc_output:
                summary += f" Calculated: {list(calc_output.keys())}"

            yield self._text(summary)

        except Exception as e:
            logger.error(f"[{self.name}] Error: {e}", exc_info=True)
            self._set(ctx, "status", "failed")
            self._set(ctx, "error", str(e))
            yield self._text(f"Evaluation failed: {e}")

    # ── Config loading (3 sources, priority order) ───────────

    def _load_config(self, ctx: InvocationContext) -> Optional[DecisionTreeConfig]:
        p = self.state_prefix

        # Priority 1: constructor decision_tree (str or dict)
        if self.decision_tree:
            raw = self.decision_tree
            if isinstance(raw, str):
                raw = yaml.safe_load(raw)
            return DecisionTreeConfig(**raw)

        # Priority 2: state config_yaml (raw YAML string)
        yaml_str = ctx.session.state.get(f"{p}:config_yaml")
        if yaml_str:
            return DecisionTreeConfig(**yaml.safe_load(yaml_str))

        # Priority 3: state config_path or constructor config_path
        path = ctx.session.state.get(f"{p}:config_path") or self.config_path
        if path:
            with open(path, "r") as f:
                return DecisionTreeConfig(**yaml.safe_load(f))

        return None

    # ── Helpers ───────────────────────────────────────────────

    def _set(self, ctx: InvocationContext, key: str, value: Any):
        ctx.session.state[f"{self.state_prefix}:{key}"] = value

    @staticmethod
    def _text(msg: str) -> types.Content:
        return types.Content(role="model", parts=[types.Part.from_text(text=msg)])
