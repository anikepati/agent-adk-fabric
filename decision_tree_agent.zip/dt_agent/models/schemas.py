"""Decision tree YAML schema — minimal, eval-only."""

from __future__ import annotations
from typing import Any, Dict, List, Literal, Optional, Union
from pydantic import BaseModel, Field, model_validator


class SimpleCondition(BaseModel):
    operator: Literal[
        "gt", "gte", "lt", "lte", "eq", "neq",
        "contains", "starts_with", "ends_with", "regex", "is_empty",
        "is_null", "is_not_null", "between", "in", "not_in",
    ]
    left_column: str
    right_column: Optional[str] = None
    right_value: Optional[Any] = None
    pattern: Optional[str] = None
    low: Optional[Union[int, float]] = None
    high: Optional[Union[int, float]] = None
    values: Optional[List[Any]] = None

    @model_validator(mode="after")
    def check(self):
        op = self.operator
        if op in ("gt","gte","lt","lte","eq","neq","contains","starts_with","ends_with"):
            if self.right_column is None and self.right_value is None:
                raise ValueError(f"'{op}' needs right_column or right_value")
        if op == "regex" and not self.pattern:
            raise ValueError("'regex' needs 'pattern'")
        if op == "between" and (self.low is None or self.high is None):
            raise ValueError("'between' needs 'low' and 'high'")
        if op in ("in","not_in") and not self.values:
            raise ValueError(f"'{op}' needs 'values'")
        return self


class CompoundCondition(BaseModel):
    operator: Literal["and", "or"]
    conditions: List[Union[SimpleCondition, "CompoundCondition"]]

Condition = Union[SimpleCondition, CompoundCondition]


class ActionBranch(BaseModel):
    action: Literal["api_call", "db_update", "log_only", "none"] = "none"
    method: Optional[str] = "POST"
    endpoint: Optional[str] = None
    payload: Optional[Dict[str, Any]] = None
    set: Optional[Dict[str, Any]] = None
    next_decision: Optional["DecisionNode"] = None


class DecisionNode(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    condition: Condition
    on_true: ActionBranch = Field(default_factory=lambda: ActionBranch(action="none"))
    on_false: ActionBranch = Field(default_factory=lambda: ActionBranch(action="none"))


class DecisionTreeConfig(BaseModel):
    model_config = {"extra": "allow"}
    decision_trees: List[DecisionNode]


CompoundCondition.model_rebuild()
ActionBranch.model_rebuild()
DecisionNode.model_rebuild()
DecisionTreeConfig.model_rebuild()
