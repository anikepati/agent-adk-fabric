"""Walk decision trees for a single row. Returns structured decisions."""

import logging
from typing import Any, Dict, List
from models.schemas import DecisionNode, ActionBranch
from engine.evaluator import evaluate

logger = logging.getLogger(__name__)
RowData = Dict[str, Any]


def walk_tree(node: DecisionNode, row: RowData, depth: int = 0) -> Dict[str, Any]:
    """Walk a single decision tree node recursively. Returns the full decision path."""
    result = evaluate(node.condition, row)
    branch: ActionBranch = node.on_true if result else node.on_false
    label = "on_true" if result else "on_false"

    # Build the action output
    action_output = {"action": branch.action}
    if branch.endpoint:
        action_output["endpoint"] = branch.endpoint
    if branch.payload:
        action_output["payload"] = branch.payload
    if branch.set:
        action_output["set"] = branch.set
    if branch.method and branch.action == "api_call":
        action_output["method"] = branch.method

    record = {
        "node_id": node.id,
        "node_name": node.name,
        "result": result,
        "branch": label,
        "action": action_output,
        "children": [],
    }

    # Recurse into next_decision if present
    if branch.next_decision:
        child = walk_tree(branch.next_decision, row, depth + 1)
        record["children"].append(child)

    return record


def walk_all(trees: List[DecisionNode], row: RowData) -> List[Dict[str, Any]]:
    """Walk all decision trees for a single row."""
    return [walk_tree(tree, row) for tree in trees]


def collect_actions(tree_result: Dict) -> List[Dict]:
    """Flatten a tree result into a list of actions taken (leaf actions only)."""
    actions = []
    if tree_result["action"]["action"] != "none":
        actions.append({
            "node_id": tree_result["node_id"],
            "node_name": tree_result["node_name"],
            "result": tree_result["result"],
            "branch": tree_result["branch"],
            **tree_result["action"],
        })
    for child in tree_result.get("children", []):
        actions.extend(collect_actions(child))
    return actions
