"""Tests for core.script_executor — parsing and dispatch logic."""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from core.script_executor import (
    _parse_script_lines,
    _parse_method_call,
    _safe_parse_args,
)


class TestParseScriptLines:
    def test_strips_blanks_and_comments(self):
        script = """
        # This is a comment
        page.goto("https://example.com")

        # Another comment
        page.click("#btn")
        """
        lines = _parse_script_lines(script)
        assert len(lines) == 2
        assert lines[0] == 'page.goto("https://example.com")'
        assert lines[1] == 'page.click("#btn")'

    def test_strips_await(self):
        script = 'await page.goto("url")\nawait page.click("#x")'
        lines = _parse_script_lines(script)
        assert lines[0] == 'page.goto("url")'
        assert lines[1] == 'page.click("#x")'

    def test_empty_script(self):
        assert _parse_script_lines("") == []
        assert _parse_script_lines("# only comments") == []


class TestParseMethodCall:
    def test_simple_method(self):
        m, a = _parse_method_call('page.click("#btn")')
        assert m == "click"
        assert a == '"#btn"'

    def test_no_args(self):
        m, a = _parse_method_call("page.reload()")
        assert m == "reload"
        assert a == ""

    def test_multiple_args(self):
        m, a = _parse_method_call('page.fill("#input", "hello")')
        assert m == "fill"
        assert '"#input"' in a and '"hello"' in a

    def test_kwargs(self):
        m, a = _parse_method_call('page.goto("url", wait_until="networkidle")')
        assert m == "goto"
        assert "wait_until" in a

    def test_blocked_method(self):
        with pytest.raises(ValueError, match="not in the allowed whitelist"):
            _parse_method_call('page.evaluate_handle("evil()")')

    def test_invalid_line(self):
        with pytest.raises(ValueError, match="Cannot parse"):
            _parse_method_call('import os; os.system("rm -rf /")')


class TestSafeParseArgs:
    def test_string_args(self):
        pos, kw = _safe_parse_args('"hello", "world"')
        assert pos == ["hello", "world"]
        assert kw == {}

    def test_int_arg(self):
        pos, kw = _safe_parse_args("5000")
        assert pos == [5000]

    def test_kwargs(self):
        pos, kw = _safe_parse_args('"sel", timeout=5000')
        assert pos == ["sel"]
        assert kw == {"timeout": 5000}

    def test_bool_arg(self):
        pos, kw = _safe_parse_args("full_page=False")
        assert kw == {"full_page": False}

    def test_no_args(self):
        pos, kw = _safe_parse_args("")
        assert pos == []
        assert kw == {}

    def test_rejects_code(self):
        with pytest.raises(ValueError):
            _safe_parse_args("__import__('os').system('ls')")
