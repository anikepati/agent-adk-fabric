"""
Enterprise Data Models for Browser Automation Agent.

All structured data types used across the system. Immutable where possible,
serializable for audit trails, and type-annotated for IDE support.
"""

from __future__ import annotations

import uuid
import hashlib
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Optional, Any


# ═══════════════════════════════════════════════════════════════
# Enums
# ═══════════════════════════════════════════════════════════════

class WorkflowStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    ABORTED = "aborted"


class ErrorAction(str, Enum):
    """What to do when a script fails."""
    RETRY = "retry"        # Same script, auto-retry (transient errors)
    REPLAN = "replan"      # Send to LLM for script rewrite
    ABORT = "abort"        # Stop workflow, unrecoverable


class ErrorCategory(str, Enum):
    TRANSIENT = "transient"          # Network glitch, stale element — auto-retry
    SELECTOR_NOT_FOUND = "selector_not_found"
    ELEMENT_NOT_INTERACTABLE = "element_not_interactable"
    UNEXPECTED_DIALOG = "unexpected_dialog"
    PAGE_STRUCTURE_CHANGED = "page_structure_changed"
    TIMEOUT = "timeout"
    NAVIGATION_ERROR = "navigation_error"
    AUTH_FAILURE = "auth_failure"     # Terminal
    SERVER_ERROR = "server_error"    # Terminal
    BROWSER_ERROR = "browser_error"  # Terminal
    VALIDATION_FAILED = "validation_failed"
    UNKNOWN = "unknown"


class ValidationType(str, Enum):
    TEXT_PRESENT = "text_present"
    TEXT_NOT_PRESENT = "text_not_present"
    URL_CONTAINS = "url_contains"
    ELEMENT_VISIBLE = "element_visible"
    ELEMENT_NOT_VISIBLE = "element_not_visible"
    FIELD_VALUE = "field_value"


# ═══════════════════════════════════════════════════════════════
# Page & Element Models
# ═══════════════════════════════════════════════════════════════

@dataclass
class ElementInfo:
    """Compact representation of an interactive DOM element."""
    tag: str
    selector: Optional[str] = None
    text: Optional[str] = None
    aria_label: Optional[str] = None
    element_type: Optional[str] = None
    name: Optional[str] = None
    role: Optional[str] = None
    value: Optional[str] = None
    is_enabled: bool = True
    is_visible: bool = True

    def best_selector(self) -> Optional[str]:
        """Return the most reliable selector available."""
        if self.selector and self.selector.startswith("#"):
            return self.selector
        if self.name:
            return f'[name="{self.name}"]'
        if self.aria_label:
            return f'[aria-label="{self.aria_label}"]'
        return self.selector


@dataclass
class PageState:
    """Compact snapshot of current page state for LLM context."""
    url: str
    title: str
    interactive_elements: list[ElementInfo] = field(default_factory=list)
    alerts: list[str] = field(default_factory=list)
    visible_text_snippet: Optional[str] = None

    def to_compact_dict(self) -> dict:
        """Token-optimized dict for LLM context."""
        elements = []
        for el in self.interactive_elements[:40]:
            entry = {"tag": el.tag}
            if el.selector:
                entry["sel"] = el.selector
            if el.text:
                entry["txt"] = el.text[:60]
            if el.aria_label:
                entry["aria"] = el.aria_label
            if el.element_type:
                entry["type"] = el.element_type
            if el.value:
                entry["val"] = el.value[:40]
            if el.role:
                entry["role"] = el.role
            if not el.is_enabled:
                entry["disabled"] = True
            elements.append(entry)

        result = {"url": self.url, "title": self.title, "elements": elements}
        if self.alerts:
            result["alerts"] = self.alerts
        return result


# ═══════════════════════════════════════════════════════════════
# Error Context
# ═══════════════════════════════════════════════════════════════

@dataclass
class ErrorContext:
    """Rich error context captured on script failure."""
    error_type: str
    error_message: str
    category: ErrorCategory
    failed_line: str
    failed_line_number: int
    lines_before: list[str] = field(default_factory=list)
    lines_after: list[str] = field(default_factory=list)
    page_url: Optional[str] = None
    page_title: Optional[str] = None
    page_state: Optional[PageState] = None
    screenshot_path: Optional[str] = None
    elapsed_ms: int = 0


# ═══════════════════════════════════════════════════════════════
# Validation
# ═══════════════════════════════════════════════════════════════

@dataclass
class ValidationRule:
    """A single validation check to run after script execution."""
    type: ValidationType
    value: str
    selector: Optional[str] = None
    description: Optional[str] = None


@dataclass
class ValidationResult:
    """Outcome of a single validation check."""
    rule: ValidationRule
    passed: bool
    actual_value: Optional[str] = None
    message: Optional[str] = None


# ═══════════════════════════════════════════════════════════════
# Execution Results
# ═══════════════════════════════════════════════════════════════

@dataclass
class ExecutionResult:
    """Result of a single script execution attempt."""
    success: bool
    executed_lines: int
    total_lines: int
    duration_ms: int
    page_url: Optional[str] = None
    page_title: Optional[str] = None
    error: Optional[ErrorContext] = None
    validation_results: list[ValidationResult] = field(default_factory=list)
    attempt_number: int = 1

    @property
    def progress_pct(self) -> float:
        if self.total_lines == 0:
            return 0.0
        return round(self.executed_lines / self.total_lines * 100, 1)

    @property
    def all_validations_passed(self) -> bool:
        return all(v.passed for v in self.validation_results)


@dataclass
class ScriptAttempt:
    """Audit record for a single script execution attempt."""
    attempt_number: int
    script_text: str
    script_hash: str
    result: ExecutionResult
    replan_reason: Optional[str] = None
    replan_duration_ms: Optional[int] = None
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @staticmethod
    def compute_hash(script: str) -> str:
        return hashlib.sha256(script.encode()).hexdigest()[:16]


# ═══════════════════════════════════════════════════════════════
# Workflow Execution Record
# ═══════════════════════════════════════════════════════════════

@dataclass
class WorkflowExecution:
    """Complete record of a workflow execution — the audit trail."""
    execution_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    workflow_name: str = ""
    params: dict = field(default_factory=dict)
    status: WorkflowStatus = WorkflowStatus.PENDING
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    attempts: list[ScriptAttempt] = field(default_factory=list)
    total_llm_tokens: int = 0
    failure_reason: Optional[str] = None
    final_page_url: Optional[str] = None

    @property
    def total_duration_ms(self) -> int:
        if self.start_time and self.end_time:
            delta = self.end_time - self.start_time
            return int(delta.total_seconds() * 1000)
        return sum(a.result.duration_ms for a in self.attempts)

    @property
    def attempt_count(self) -> int:
        return len(self.attempts)

    def to_audit_dict(self) -> dict:
        """Serializable audit record."""
        return {
            "execution_id": self.execution_id,
            "workflow_name": self.workflow_name,
            "params": {k: v for k, v in self.params.items()
                       if k not in ("password", "token", "secret")},
            "status": self.status.value,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "attempt_count": self.attempt_count,
            "total_duration_ms": self.total_duration_ms,
            "total_llm_tokens": self.total_llm_tokens,
            "failure_reason": self.failure_reason,
            "attempts": [
                {
                    "attempt": a.attempt_number,
                    "script_hash": a.script_hash,
                    "success": a.result.success,
                    "progress_pct": a.result.progress_pct,
                    "duration_ms": a.result.duration_ms,
                    "error": a.result.error.error_message if a.result.error else None,
                    "replan_reason": a.replan_reason,
                }
                for a in self.attempts
            ],
        }


# ═══════════════════════════════════════════════════════════════
# Skill Script Definition
# ═══════════════════════════════════════════════════════════════

@dataclass
class SkillScript:
    """A loaded, validated skill script definition."""
    name: str
    key: str
    description: str
    version: str
    script: str
    params_required: list[str]
    params_optional: dict[str, Any] = field(default_factory=dict)
    tags: list[str] = field(default_factory=list)
    timeout_seconds: int = 120
    max_retries: int = 3
    validation: list[ValidationRule] = field(default_factory=list)
    recovery_hints: list[str] = field(default_factory=list)

    def validate_params(self, params: dict) -> list[str]:
        """Return list of missing required parameters."""
        return [p for p in self.params_required if p not in params]


# ═══════════════════════════════════════════════════════════════
# Browser Configuration
# ═══════════════════════════════════════════════════════════════

@dataclass
class BrowserConfig:
    engine: str = "chromium"
    headless: bool = False
    viewport_width: int = 1280
    viewport_height: int = 900
    default_timeout_ms: int = 30000
    navigation_timeout_ms: int = 60000
    blocked_patterns: list[str] = field(default_factory=list)
    storage_state_path: Optional[str] = None
    screenshot_dir: str = "./screenshots"
    trace_on_failure: bool = True
    record_video: bool = False


@dataclass
class ExecutionConfig:
    max_retries: int = 3
    auto_retry_on_transient: bool = True
    script_timeout_seconds: int = 120
    page_state_max_elements: int = 40


@dataclass
class ReplannerConfig:
    model: str = "gemini-2.0-flash"
    max_tokens: int = 4096
    temperature: float = 0.1
