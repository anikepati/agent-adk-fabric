"""
main.py
========
Runs the Senior Lien Verification QA pipeline using the real Google ADK
InMemoryRunner.

Usage:
    export GOOGLE_API_KEY=<your-gemini-api-key>
    python main.py                             # runs all cases
    python main.py --case ECAR-2024-001        # runs a single case
    python main.py --list                      # lists available cases

Data flow:
    1. context_loader.build_session_state(case_id) → initial state dict
       with keys: case_id, ecar, si_primary, si_compare,
                  title_primary, title_compare
    2. Runner creates a session, seeding state via state_delta
    3. SequentialAgent runs IngestAgent → ... → ReportAgent
    4. Each LlmAgent uses output_key to write its result back to state
    5. Final report is read from session state["report"]
"""

import argparse
import asyncio
import json
import sys
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from google.adk.runners import InMemoryRunner
from google.genai import types

from agents.pipeline import build_pipeline
from tools.context_loader import build_session_state, list_cases

APP_NAME = "senior_lien_qa"
USER_ID  = "qa_processor"

_DISPOSITION_ICON = {
    "CLEAR": "✅", "CAUTION": "⚠️ ",
    "REFER_TRU": "🔴", "END_PROCESS": "🛑",
}


async def run_case(case_id: str, model: str = "gemini-2.0-flash") -> dict:
    """
    Run the pipeline for a single case and return the final report.
    """
    state = build_session_state(case_id)
    if not state:
        raise ValueError(f"Case '{case_id}' not found in ECaR extract.")

    pipeline = build_pipeline(model)
    runner   = InMemoryRunner(agent=pipeline, app_name=APP_NAME)

    # Create a session pre-seeded with all five data sources.
    session_id = str(uuid.uuid4())
    await runner.session_service.create_session(
        app_name=APP_NAME,
        user_id=USER_ID,
        session_id=session_id,
        state=state,
    )

    print(f"\n{'='*68}")
    print(f"  Senior Lien Verification QA Pipeline  (ADK SequentialAgent)")
    print(f"  Case: {case_id}")
    print(f"  Model: {model}  |  Session: {session_id[:8]}…")
    print(f"{'='*68}")

    # A trivial user message triggers the sequential run — the agents
    # work off session state, not the message.
    trigger = types.Content(
        role="user",
        parts=[types.Part(text=f"Run QA pipeline for case {case_id}.")],
    )

    agent_banner = {
        "IngestAgent":              "[1/5] IngestAgent",
        "SecurityInstrumentAgent":  "[2/5] SecurityInstrumentAgent",
        "TitleReportAgent":         "[3/5] TitleReportAgent",
        "LienValidationAgent":      "[4/5] LienValidationAgent",
        "ReportAgent":              "[5/5] ReportAgent",
    }

    last_author = None
    async for event in runner.run_async(
        user_id=USER_ID,
        session_id=session_id,
        new_message=trigger,
    ):
        if event.author and event.author != last_author and event.author in agent_banner:
            print(f"\n{agent_banner[event.author]} …")
            last_author = event.author

    # Retrieve the final session state
    session = await runner.session_service.get_session(
        app_name=APP_NAME, user_id=USER_ID, session_id=session_id,
    )
    final_state = session.state

    report = final_state.get("report", {})
    if isinstance(report, str):
        try:
            report = json.loads(report)
        except json.JSONDecodeError:
            pass

    _print_report(case_id, report)
    return {
        "case_id":      case_id,
        "ingest_result": final_state.get("ingest_result"),
        "si_result":     final_state.get("si_result"),
        "title_result":  final_state.get("title_result"),
        "lien_result":   final_state.get("lien_result"),
        "report":        report,
    }


def _print_report(case_id: str, report) -> None:
    """Pretty-print the final report."""
    if not report or not isinstance(report, dict):
        print(f"\n⚠️  No report produced for {case_id}")
        print(f"   Raw value: {report!r}")
        return

    disposition = report.get("disposition", "UNKNOWN")
    icon        = _DISPOSITION_ICON.get(disposition, "❓")

    print(f"\n{'─'*68}")
    print(f"  {icon} DISPOSITION : {disposition}")
    print(f"     REASON      : {report.get('disposition_reason', '')}")
    print(f"     FLAGS       : critical={report.get('critical_count',0)}  "
          f"high={report.get('high_count',0)}  "
          f"medium={report.get('medium_count',0)}  "
          f"info={report.get('info_count',0)}")

    flags = report.get("all_flags", [])
    if flags:
        print(f"\n  FLAGS ({len(flags)}):")
        for f in flags:
            print(f"    [{f.get('severity','?').upper():<8}] {f.get('code','?')}")
            msg = (f.get('message') or '').replace('\n', ' ').strip()
            print(f"      {msg[:160]}")

    acts = report.get("arrow_activities", [])
    if acts:
        print(f"\n  ARROW ACTIVITIES ({len(acts)}):")
        for a in acts:
            print(f"    Type={a.get('type')}  Party={a.get('party')}  "
                  f"Result={a.get('result')}")
            if a.get("activity_text"):
                print(f"    Text: {a['activity_text']}")

    ecar_actions = report.get("ecar_actions", [])
    if ecar_actions:
        print(f"\n  ECAR ACTIONS ({len(ecar_actions)}):")
        for a in ecar_actions:
            print(f"    • {a.get('screen','ECaR')}: {a.get('action','')[:140]}")

    emails = report.get("email_actions", [])
    if emails:
        print(f"\n  EMAIL ACTIONS ({len(emails)}):")
        for e in emails:
            print(f"    → {e.get('to')}  |  {e.get('subject')}")

    print(f"\n  NEXT STEPS:\n  {report.get('processor_next_steps','')}")
    print(f"{'='*68}\n")


async def run_all(model: str = "gemini-2.0-flash") -> list:
    """Run the pipeline for every case in the ECaR extract."""
    results = []
    for case_id in list_cases():
        try:
            results.append(await run_case(case_id, model))
        except Exception as e:
            print(f"\n❌ Error running {case_id}: {type(e).__name__}: {e}")

    # Batch summary
    print("\n" + "═"*68)
    print("  BATCH SUMMARY")
    print("═"*68)
    for r in results:
        d    = (r.get("report") or {}).get("disposition", "UNKNOWN")
        icon = _DISPOSITION_ICON.get(d, "❓")
        print(f"  {r['case_id']:<22} {icon} {d}")
    print("═"*68 + "\n")
    return results


def main():
    parser = argparse.ArgumentParser(
        description="Senior Lien Verification QA Pipeline (Google ADK)"
    )
    parser.add_argument("--case", type=str, default=None,
                        help="Run a single case by ID")
    parser.add_argument("--list", action="store_true",
                        help="List available case IDs")
    parser.add_argument("--model", type=str, default="gemini-2.0-flash",
                        help="Gemini model to use")
    args = parser.parse_args()

    if args.list:
        print("Available cases:")
        for cid in list_cases():
            print(f"  {cid}")
        return

    if args.case:
        asyncio.run(run_case(args.case, args.model))
    else:
        asyncio.run(run_all(args.model))


if __name__ == "__main__":
    main()
