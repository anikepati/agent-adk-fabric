"""Unit tests for configuration, processors, and resilience components."""
from __future__ import annotations

import json
import os
import tempfile
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import yaml

from app.config.loader import load_config
from app.config.models import (
    AppConfig,
    CircuitBreakerConfig,
    ClusterConfig,
    RetryConfig,
    TopicConfig,
)
from app.config.secret_resolver import resolve_config, resolve_value
from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult, ResultStatus
from app.core.topic_map import TopicMap
from app.resilience.circuit_breaker import CircuitBreaker, CircuitState
from app.resilience.retry import RetryHandler


# ── Config Models ──


class TestTopicConfig:
    def test_effective_dlq_explicit(self):
        tc = TopicConfig(topic="test.topic", processor="http_forward", dlq="test.topic.dead")
        assert tc.effective_dlq(".dlq") == "test.topic.dead"

    def test_effective_dlq_default(self):
        tc = TopicConfig(topic="test.topic", processor="http_forward")
        assert tc.effective_dlq(".dlq") == "test.topic.dlq"


class TestClusterConfig:
    def test_build_consumer_params_ssl(self):
        from app.config.models import SSLConfig, KafkaConsumerConfig

        cc = ClusterConfig(
            bootstrap_servers="broker1:9093",
            group_id="test-grp",
            security_protocol="SSL",
            ssl=SSLConfig(
                ca_location="/certs/ca.pem",
                certificate_location="/certs/client.pem",
                key_location="/certs/client.key",
            ),
        )
        params = cc.build_consumer_params()
        assert params["bootstrap.servers"] == "broker1:9093"
        assert params["group.id"] == "test-grp"
        assert params["security.protocol"] == "SSL"
        assert params["ssl.ca.location"] == "/certs/ca.pem"

    def test_build_consumer_params_sasl(self):
        from app.config.models import SASLConfig

        cc = ClusterConfig(
            bootstrap_servers="broker1:9093",
            group_id="test-grp",
            security_protocol="SASL_SSL",
            sasl=SASLConfig(
                mechanism="SCRAM-SHA-512",
                username="user",
                password="pass",
            ),
        )
        params = cc.build_consumer_params()
        assert params["sasl.mechanism"] == "SCRAM-SHA-512"
        assert params["sasl.username"] == "user"
        assert params["sasl.password"] == "pass"

    def test_duplicate_topics_rejected(self):
        with pytest.raises(Exception):
            ClusterConfig(
                bootstrap_servers="broker:9093",
                group_id="grp",
                topics=[
                    TopicConfig(topic="dup.topic", processor="http_forward"),
                    TopicConfig(topic="dup.topic", processor="db_write"),
                ],
            )


class TestAppConfig:
    def test_resolve_topic_defaults(self):
        config = AppConfig(
            clusters={
                "test": ClusterConfig(
                    bootstrap_servers="broker:9093",
                    group_id="grp",
                    topics=[
                        TopicConfig(topic="test.topic", processor="http_forward"),
                    ],
                )
            }
        )
        config.resolve_topic_defaults()
        tc = config.clusters["test"].topics[0]
        assert tc.retry is not None
        assert tc.retry.max_attempts == 3
        assert tc.timeout_s == 60
        assert tc.circuit_breaker is not None


# ── Secret Resolver ──


class TestSecretResolver:
    def test_resolve_env_shorthand(self):
        with patch.dict(os.environ, {"MY_VAR": "my_value"}):
            assert resolve_value("${MY_VAR}") == "my_value"

    def test_resolve_env_explicit(self):
        with patch.dict(os.environ, {"MY_VAR": "my_value"}):
            assert resolve_value("${ENV:MY_VAR}") == "my_value"

    def test_resolve_no_placeholder(self):
        assert resolve_value("plain_string") == "plain_string"

    def test_resolve_multiple(self):
        with patch.dict(os.environ, {"HOST": "broker", "PORT": "9093"}):
            assert resolve_value("${HOST}:${PORT}") == "broker:9093"

    def test_resolve_config_dict(self):
        with patch.dict(os.environ, {"DB_HOST": "localhost"}):
            result = resolve_config({"host": "${DB_HOST}", "port": 5432})
            assert result == {"host": "localhost", "port": 5432}

    def test_missing_env_raises(self):
        with pytest.raises(ValueError, match="not found"):
            resolve_value("${NONEXISTENT_VAR_12345}")


# ── Config Loader ──


class TestConfigLoader:
    def test_load_valid_config(self, tmp_path):
        config_data = {
            "clusters": {
                "test-kafka": {
                    "bootstrap_servers": "localhost:9092",
                    "group_id": "test-grp",
                    "topics": [
                        {
                            "topic": "test.topic",
                            "processor": "http_forward",
                            "processor_config": {"url": "http://api.local", "success_codes": [200]},
                        }
                    ],
                }
            }
        }
        config_file = tmp_path / "test-config.yaml"
        config_file.write_text(yaml.dump(config_data))

        config = load_config(str(config_file))
        assert "test-kafka" in config.clusters
        assert len(config.clusters["test-kafka"].topics) == 1

    def test_load_missing_file_raises(self):
        with pytest.raises(FileNotFoundError):
            load_config("/nonexistent/path.yaml")


# ── ProcessorResult ──


class TestProcessorResult:
    def test_success(self):
        r = ProcessorResult.success({"key": "val"})
        assert r.is_success
        assert r.output == {"key": "val"}

    def test_retry(self):
        r = ProcessorResult.retry("timeout")
        assert r.is_retriable
        assert r.error == "timeout"

    def test_dlq(self):
        r = ProcessorResult.dlq("bad data")
        assert r.status == ResultStatus.DLQ
        assert not r.is_success

    def test_skip(self):
        r = ProcessorResult.skip("filtered")
        assert r.status == ResultStatus.SKIP


# ── TopicMap ──


class TestTopicMap:
    def test_register_and_get(self):
        tm = TopicMap()
        proc = MagicMock()
        tm.register("test.topic", proc)
        assert tm.get("test.topic") is proc
        assert "test.topic" in tm
        assert len(tm) == 1

    def test_duplicate_registration_raises(self):
        tm = TopicMap()
        proc = MagicMock()
        tm.register("test.topic", proc)
        with pytest.raises(ValueError, match="Duplicate"):
            tm.register("test.topic", proc)

    def test_get_missing_returns_none(self):
        tm = TopicMap()
        assert tm.get("nonexistent") is None


# ── CircuitBreaker ──


class TestCircuitBreaker:
    def _make_cb(self, threshold=3, recovery_s=1) -> CircuitBreaker:
        return CircuitBreaker(
            "test",
            CircuitBreakerConfig(
                failure_threshold=threshold,
                recovery_timeout_s=recovery_s,
                half_open_max=2,
            ),
        )

    def test_starts_closed(self):
        cb = self._make_cb()
        assert cb.state == CircuitState.CLOSED
        assert cb.allow_request()

    def test_opens_after_threshold(self):
        cb = self._make_cb(threshold=3)
        for _ in range(3):
            cb.record_failure()
        assert cb.state == CircuitState.OPEN
        assert not cb.allow_request()

    def test_success_resets_count(self):
        cb = self._make_cb(threshold=3)
        cb.record_failure()
        cb.record_failure()
        cb.record_success()
        # Should not be open — success reset the count
        cb.record_failure()
        assert cb.state == CircuitState.CLOSED

    def test_reset(self):
        cb = self._make_cb(threshold=1)
        cb.record_failure()
        assert cb.state == CircuitState.OPEN
        cb.reset()
        assert cb.state == CircuitState.CLOSED


# ── RetryHandler ──


class TestRetryHandler:
    def test_should_retry(self):
        rh = RetryHandler(RetryConfig(max_attempts=3))
        assert rh.should_retry(0)
        assert rh.should_retry(1)
        assert rh.should_retry(2)
        assert not rh.should_retry(3)

    def test_compute_delay(self):
        rh = RetryHandler(RetryConfig(backoff_base_ms=100, backoff_max_ms=5000))
        d0 = rh.compute_delay_seconds(0)
        d1 = rh.compute_delay_seconds(1)
        d2 = rh.compute_delay_seconds(2)
        assert d0 < d1 < d2
        assert d2 <= 5.0  # max cap


# ── ConsumerMessage ──


class TestConsumerMessage:
    def test_partition_key(self):
        msg = ConsumerMessage(
            topic="test", partition=2, offset=100,
            key=None, value={}, raw_value=b"{}",
            headers={}, timestamp_ms=0, cluster_name="test-cluster",
        )
        assert msg.partition_key == ("test", 2)

    def test_header_access(self):
        msg = ConsumerMessage(
            topic="test", partition=0, offset=0,
            key=None, value={}, raw_value=b"{}",
            headers={"x-trace": "abc123"}, timestamp_ms=0,
            cluster_name="test",
        )
        assert msg.header("x-trace") == "abc123"
        assert msg.header("missing", "default") == "default"


# ── Processor Registry ──


class TestProcessorRegistry:
    def test_discover_and_create(self):
        from app.processors.registry import discover_processors, get_registered_types, is_registered

        discover_processors()
        types = get_registered_types()
        assert "http_forward" in types
        assert "pipeline" in types
        assert "fanout" in types
        assert "route" in types
        assert "validate_and_store" in types
        assert "db_write" in types
        assert "transform" in types
        assert "filter" in types
        assert "enrich" in types
        assert "notify" in types
        assert "actimize_submit" in types
        assert "compliance_check" in types
        assert "edr_qa_evaluate" in types
        assert "rro_validate" in types
        assert is_registered("http_forward")

    def test_create_unknown_raises(self):
        from app.processors.registry import create_processor, discover_processors

        discover_processors()
        with pytest.raises(ValueError, match="Unknown processor"):
            create_processor("nonexistent_processor", {}, "cluster", "topic")
