"""
Filter processor: drop messages that don't match JMESPath conditions.
"""
from __future__ import annotations

from typing import Any

import jmespath

from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult
from app.processors.base import BaseProcessor, ProcessorContext
from app.processors.registry import register_processor


@register_processor("filter")
class FilterProcessor(BaseProcessor):

    def __init__(self, config: dict[str, Any], context: ProcessorContext) -> None:
        super().__init__(config, context)
        self._conditions: list[str] = config.get("conditions", [])
        self._compiled = [jmespath.compile(c) for c in self._conditions]

    async def process(self, message: ConsumerMessage) -> ProcessorResult:
        data = message.value
        if not isinstance(data, dict):
            return ProcessorResult.skip("Non-dict message filtered out")

        for i, expr in enumerate(self._compiled):
            result = expr.search(data)
            if not result:
                return ProcessorResult.skip(
                    f"Condition not met: {self._conditions[i]}"
                )

        return ProcessorResult.success()
