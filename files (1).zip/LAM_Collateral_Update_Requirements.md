# LAM Collateral Update Process — Functional Requirements Document

**Version:** 4.0
**Author:** Sunil — Principal Engineer, Enterprise AI Architecture
**Status:** Production-Ready
**Last Updated:** April 2026

---

## 1. Executive Summary

This document specifies the complete LAM (Loan Asset Management) Collateral Update
validation process implemented as a YAML-driven decision tree executed by a
deterministic ADK agent. The process covers 10 validation sections, 19 exception
types, and a conditional two-phase execution model.

The key business rule: **Analysis 1 (Sections 2-3) runs first. If Section 3
(Conversion) produces no LAM updates, then Analysis 2 (Sections 5-10) runs to
detect unexpected field changes. If Section 3 DID produce LAM updates, Analysis 2
is skipped because the field changes are expected consequences of the conversion.**

---

## 2. Business Context

When a loan's collateral undergoes a change (percentage update, type conversion,
cost adjustment), the system must validate that the change is legitimate, the
required supporting data exists, and the LAM record is updated correctly. Invalid
or unexpected changes must be logged as numbered exceptions for compliance review.

### 2.1 Process Ownership

| Role | Responsibility |
|------|---------------|
| Credit Operations | Triggers collateral updates, reviews exceptions |
| Compliance | Audits exception logs, approves exception resolutions |
| LAM System | Source of truth for collateral records |
| BDR System | Source for hard cost, contract price data |
| Appraisal System | Source for appraisal values and plan names |

---

## 3. Two-Phase Conditional Execution Model

### 3.1 Phase Overview

```
PHASE 1: Analysis 1
├── Section 2: Percentage Update (independent)
└── Section 3: Conversion (9 sub-trees, produces LAM updates or exceptions)
        │
        ├── LAM updates produced? → YES → STOP. Sections 5-10 skipped.
        │                                  (field changes are expected)
        │
        └── No LAM updates?     → Continue to Phase 2
                                          │
PHASE 2: Analysis 2                       │
├── Section 5: Hard Cost    ◄─────────────┘
├── Section 6: Lot Cost
├── Section 7: Contract Price
├── Section 8: Appraisal
├── Section 9: Borrowing Base
└── Section 10: Availability
```

### 3.2 Conditional Logic

**Why this matters:** When a conversion like LOT→SPEC happens, the system
legitimately updates CollateralType, ConversionDate, and HardCost in LAM.
If Analysis 2 were to run unconditionally, it would flag the hard cost change
as Exception 14 — a false positive, since the change was part of the valid
conversion. By gating Analysis 2 on "no LAM updates from Section 3", we
eliminate these false positives.

**Implementation:** The DecisionTreeAgent evaluates Phase 1 trees first.
After Phase 1, a calculated field `has_lam_updates` is derived by checking
whether any Section 3 tree produced an `api_call` to `/lam/update`. Phase 2
trees are wrapped in a gate condition: they only evaluate their actual logic
if `has_lam_updates` is false. If `has_lam_updates` is true, they skip
evaluation entirely.

### 3.3 Edge Cases

| Scenario | Phase 1 Result | Phase 2 Behavior |
|----------|---------------|-----------------|
| Valid conversion (e.g., LOT→SPEC, all checks pass) | LAM update produced | Phase 2 skipped — field changes are expected |
| Invalid conversion (e.g., illogical progression) | Exception 13, no LAM update | Phase 2 runs — unexpected field changes are flagged |
| No conversion at all (percentage-only change) | No LAM update from Sec 3 | Phase 2 runs — field changes need scrutiny |
| Conversion with missing data (e.g., plan not in LAM) | Exception logged, no LAM update | Phase 2 runs — conversion failed, so field changes are suspicious |
| Valid conversion with collateral basis = Custom | LAM update + Exception 12 | Phase 2 skipped — LAM was updated even though an exception was raised |

---

## 4. Section-by-Section Specification

### 4.1 Section 2: Percentage Update

**Purpose:** Validate percentage completion changes.

| Input Column | Description |
|-------------|-------------|
| `ChangeInPercentage` | Whether a percentage change occurred (Yes/No) |
| `PercentageProvided` | Whether the new percentage value was provided (Yes/No) |

**Decision tree:**
```
Change in Percentage?
├── YES → Percentage Provided?
│         ├── YES → Update LAM: Percentage Completion + Date
│         └── NO  → Exception 1: Percentage not provided
└── NO  → No action
```

**Exception 1:** Change in percentage detected but percentage value not provided.

---

### 4.2 Section 3: Conversion

**Purpose:** Validate collateral type conversions. This is the most complex
section with 9 sub-trees handling different conversion paths.

**Input columns:**

| Column | Description |
|--------|-------------|
| `LogicalProgression` | Whether the type change is valid (Yes/No) |
| `FromType` | Source collateral type (SPEC, MODEL, LAND, LUD, LOT, PRESOLD) |
| `ToType` | Target collateral type |
| `ConversionType` | Combined key (e.g., "SPEC_TO_PRESOLD") |
| `ContractPriceProvided` | Contract price available (Yes/No) |
| `WithinThreshold` | Contract price within acceptable range (Yes/No) |
| `PlanNameExistsInLAM` | Plan name found in LAM system (Yes/No) |
| `AppraisalValueMatched` | Appraisal value matches expectations (Yes/No) |
| `AppraisalAvailable` | Appraisal data available (Yes/No) |
| `CustomerBDRHasHardCost` | Hard cost exists in BDR (Yes/No) |
| `CustomerBDRHasContractPrice` | Contract price exists in BDR (Yes/No) |
| `LAMCollateralValueBasis` | Current collateral value basis in LAM |

**Conversion sub-trees:**

#### 3.1 Logical Progression Gate

First check for all conversions. If the type change is not a logical
progression (e.g., PRESOLD→LAND), the conversion is invalid.

```
Logical Progression?
├── YES → Continue to specific conversion tree
└── NO  → Exception 13: Illogical type progression
```

#### 3.2 SPEC/MODEL → PRESOLD

```
FromType in [SPEC, MODEL] AND ToType = PRESOLD?
├── YES → Contract Price Provided AND Within Threshold?
│         ├── YES → Update LAM: Collateral Type + Contract Price
│         └── NO  → Exception 2: Contract price issue
└── NO  → (check next conversion type)
```

#### 3.3 SPEC → MODEL

```
FromType = SPEC AND ToType = MODEL?
├── YES → Update LAM: Collateral Type
└── NO  → (check next)
```

#### 3.4 LAND → LUD

```
FromType = LAND AND ToType = LUD?
├── YES → Plan Name exists in LAM?
│         ├── YES → Appraisal Value Matched?
│         │         ├── YES → Update LAM: Collateral Type
│         │         └── NO  → Exception 4: Appraisal mismatch
│         └── NO  → Exception 3: Plan name missing
└── NO  → (check next)
```

#### 3.5 LUD → LOT

```
FromType = LUD AND ToType = LOT?
├── YES → Plan Name exists in LAM?
│         ├── YES → Appraisal Value Matched?
│         │         ├── YES → Update LAM: Collateral Type + Conversion Date
│         │         └── NO  → Exception 5: Appraisal mismatch
│         └── NO  → Exception 5: Plan name missing
└── NO  → (check next)
```

#### 3.6 LOT/LUD → SPEC/MODEL

```
FromType in [LOT, LUD] AND ToType in [SPEC, MODEL]?
├── YES → Appraisal Available?
│         ├── YES → Plan Name exists in LAM?
│         │         ├── YES → Appraisal Matched?
│         │         │         ├── YES → BDR Has Hard Cost?
│         │         │         │         ├── YES → Update LAM: Collateral Type + Conversion Date + Hard Cost
│         │         │         │         └── NO  → Exception 7: No hard cost
│         │         │         └── NO  → Exception 6: Appraisal mismatch
│         │         └── NO  → Exception 5: Plan name missing
│         └── NO  → Exception 8: No appraisal
└── NO  → (check next)
```

#### 3.7 LOT/LUD → PRESOLD

```
FromType in [LOT, LUD] AND ToType = PRESOLD?
├── YES → Appraisal Available?
│         ├── YES → BDR Has Hard Cost?
│         │         ├── YES → BDR Has Contract Price?
│         │         │         ├── YES → Plan Name in LAM?
│         │         │         │         ├── YES → Appraisal Matched?
│         │         │         │         │         ├── YES → Update LAM: Collateral Type + Conversion Date + Hard Cost + Contract Price
│         │         │         │         │         └── NO  → Exception 9: Appraisal mismatch
│         │         │         │         └── NO  → Exception 10: Plan name missing
│         │         │         └── NO  → Exception 11: No contract price
│         │         └── NO  → Exception 8: No hard cost
│         └── NO  → Exception 8: No appraisal
└── NO  → (check next)
```

#### 3.8 PRESOLD → SPEC/MODEL

```
FromType = PRESOLD AND ToType in [SPEC, MODEL]?
├── YES → Update LAM: Collateral Type (remove Contract Price)
│         └── Collateral Value Basis = Custom?
│               ├── YES → Exception 12: Custom collateral basis
│               └── NO  → OK
└── NO  → (check next)
```

#### 3.9 Catch-All

```
Logical Progression = YES AND ConversionType not in any handled type?
├── YES → Exception 11: Unhandled conversion type
└── NO  → No action
```

---

### 4.3 Conditional Gate: Analysis 1 → Analysis 2

After all Section 3 trees execute, the agent checks whether any tree produced
a LAM update action (`action: "api_call"`, `endpoint` containing `/lam/update`).

| Analysis 1 Outcome | `has_lam_updates` | Analysis 2 |
|--------------------|-------------------|-----------|
| At least one LAM update produced | `true` | **Skipped entirely** |
| Only exceptions, no LAM updates | `false` | **Runs all sections** |
| No conversion matched (non-conversion row) | `false` | **Runs all sections** |

---

### 4.4 Section 5: Hard Cost (Analysis 2 — conditional)

**Purpose:** If the conversion type is NOT one that legitimately changes hard
cost (LOT/LUD→SPEC/MODEL), flag any hard cost changes.

**Gate:** Only runs if `has_lam_updates` = false.

```
ConversionType NOT IN [LOT_TO_SPEC, LUD_TO_SPEC, LOT_TO_MODEL, LUD_TO_MODEL]
  AND HardCostChange = Yes?
├── YES → Exception 14: Unexpected hard cost change
└── NO  → OK
```

---

### 4.5 Section 6: Lot Cost (Analysis 2 — conditional)

**Purpose:** Flag any lot cost changes.

**Gate:** Only runs if `has_lam_updates` = false.

```
LotCostChange = Yes?
├── YES → Exception 15: Lot cost change detected
└── NO  → OK
```

---

### 4.6 Section 7: Contract Price (Analysis 2 — conditional)

**Purpose:** If the conversion type is NOT one that legitimately involves
contract price changes, flag any contract price changes.

**Gate:** Only runs if `has_lam_updates` = false.

```
ConversionType NOT IN [SPEC_TO_PRESOLD, MODEL_TO_PRESOLD,
  LOT_TO_PRESOLD, LUD_TO_PRESOLD, PRESOLD_TO_SPEC, PRESOLD_TO_MODEL]
  AND ContractPriceChange = Yes?
├── YES → Exception 16: Unexpected contract price change
└── NO  → OK
```

---

### 4.7 Section 8: Appraisal (Analysis 2 — conditional)

**Purpose:** If the conversion type is NOT one that legitimately involves
appraisal validation, flag any appraisal value changes.

**Gate:** Only runs if `has_lam_updates` = false.

```
ConversionType NOT IN [LAND_TO_LUD, LUD_TO_LOT, LOT_TO_SPEC, LUD_TO_SPEC,
  LOT_TO_MODEL, LUD_TO_MODEL, LOT_TO_PRESOLD, LUD_TO_PRESOLD]
  AND AppraisalValueChange = Yes?
├── YES → Exception 17: Unexpected appraisal change
└── NO  → OK
```

---

### 4.8 Section 9: Borrowing Base (Analysis 2 — conditional)

**Purpose:** Flag any borrowing base changes.

**Gate:** Only runs if `has_lam_updates` = false.

```
BorrowingBaseChange = Yes?
├── YES → Exception 18: Borrowing base change detected
└── NO  → OK
```

---

### 4.9 Section 10: Availability (Analysis 2 — conditional)

**Purpose:** Flag any availability amount changes.

**Gate:** Only runs if `has_lam_updates` = false.

```
AvailabilityAmountChange = Yes?
├── YES → Exception 19: Availability amount change detected
└── NO  → OK
```

---

## 5. Exception Registry

| ID | Section | Type | Description |
|----|---------|------|-------------|
| 1 | 2 | PERCENTAGE_NOT_PROVIDED | Percentage change detected but value not provided |
| 2 | 3 | CONTRACT_PRICE_ISSUE | Contract price not provided or not within threshold |
| 3 | 3 | PLAN_NAME_MISSING | Plan name does not exist in LAM |
| 4 | 3 | APPRAISAL_MISMATCH | Appraisal value not matched (LAND→LUD) |
| 5 | 3 | PLAN_OR_APPRAISAL_ISSUE | Plan name missing or appraisal mismatch (LUD→LOT, LOT/LUD→SPEC/MODEL) |
| 6 | 3 | APPRAISAL_MISMATCH_SPEC_MODEL | Appraisal not matched (LOT/LUD→SPEC/MODEL) |
| 7 | 3 | NO_HARD_COST | BDR does not have hard cost |
| 8 | 3 | NO_APPRAISAL | Appraisal not available |
| 9 | 3 | APPRAISAL_MISMATCH_PRESOLD | Appraisal not matched (LOT/LUD→PRESOLD) |
| 10 | 3 | PLAN_NAME_MISSING_PRESOLD | Plan name missing (LOT/LUD→PRESOLD) |
| 11 | 3 | NO_CONTRACT_PRICE / UNHANDLED | BDR has no contract price, or unhandled conversion type |
| 12 | 3 | CUSTOM_COLLATERAL_BASIS | Collateral value basis is Custom (PRESOLD→SPEC/MODEL) |
| 13 | 3 | ILLOGICAL_PROGRESSION | Conversion type change is not a logical progression |
| 14 | 5 | UNEXPECTED_HARD_COST_CHANGE | Hard cost changed on non-applicable conversion |
| 15 | 6 | LOT_COST_CHANGE | Lot cost change detected |
| 16 | 7 | UNEXPECTED_CONTRACT_PRICE_CHANGE | Contract price changed on non-applicable conversion |
| 17 | 8 | UNEXPECTED_APPRAISAL_CHANGE | Appraisal changed on non-applicable conversion |
| 18 | 9 | BORROWING_BASE_CHANGE | Borrowing base change detected |
| 19 | 10 | AVAILABILITY_CHANGE | Availability amount change detected |

---

## 6. LAM Update Actions

| Conversion Path | Fields Updated |
|-----------------|---------------|
| Percentage Update (valid) | PercentageCompletion, Date |
| SPEC/MODEL → PRESOLD | CollateralType, ContractPrice |
| SPEC → MODEL | CollateralType |
| LAND → LUD | CollateralType |
| LUD → LOT | CollateralType, ConversionDate |
| LOT/LUD → SPEC/MODEL | CollateralType, ConversionDate, HardCost |
| LOT/LUD → PRESOLD | CollateralType, ConversionDate, HardCost, ContractPrice |
| PRESOLD → SPEC/MODEL | CollateralType (remove ContractPrice) |

---

## 7. Input Data Columns

### 7.1 Core columns (all rows)

| Column | Type | Description |
|--------|------|-------------|
| `LoanID` | string | Unique loan identifier (row ID) |
| `ChangeInPercentage` | Yes/No | Percentage completion changed |
| `PercentageProvided` | Yes/No | New percentage value provided |
| `LogicalProgression` | Yes/No | Type change is valid progression |
| `FromType` | string | Source collateral type |
| `ToType` | string | Target collateral type |
| `ConversionType` | string | Combined key (e.g., SPEC_TO_PRESOLD) |

### 7.2 Conversion validation columns

| Column | Type | Description |
|--------|------|-------------|
| `ContractPriceProvided` | Yes/No | Contract price available |
| `WithinThreshold` | Yes/No | Contract price within range |
| `PlanNameExistsInLAM` | Yes/No | Plan name found in LAM |
| `AppraisalValueMatched` | Yes/No | Appraisal value matches |
| `AppraisalAvailable` | Yes/No | Appraisal data available |
| `CustomerBDRHasHardCost` | Yes/No | Hard cost in BDR |
| `CustomerBDRHasContractPrice` | Yes/No | Contract price in BDR |
| `LAMCollateralValueBasis` | string | Current value basis |

### 7.3 Analysis 2 columns (field change flags)

| Column | Type | Description |
|--------|------|-------------|
| `HardCostChange` | Yes/No | Hard cost field changed |
| `LotCostChange` | Yes/No | Lot cost field changed |
| `ContractPriceChange` | Yes/No | Contract price field changed |
| `AppraisalValueChange` | Yes/No | Appraisal value field changed |
| `BorrowingBaseChange` | Yes/No | Borrowing base changed |
| `AvailabilityAmountChange` | Yes/No | Availability amount changed |

---

## 8. Output Specification

### 8.1 Agent state outputs

| Key | Type | Description |
|-----|------|-------------|
| `dt:passed` | boolean | True if zero exceptions across all phases |
| `dt:actions` | list | All actions from all trees (flat) |
| `dt:exceptions` | list | Exception actions only |
| `dt:decisions` | list | Full tree traversal with decision paths |
| `dt:calculated_fields` | dict | `has_lam_updates` and any other computed values |
| `dt:status` | string | completed / failed / no_data |

### 8.2 Per-exception record

```json
{
  "node_id": "sec3_land_lud_plan",
  "node_name": "Plan Name in LAM",
  "result": false,
  "branch": "on_false",
  "action": "api_call",
  "endpoint": "/exceptions/log",
  "payload": {
    "exception_id": 3,
    "exception_type": "PLAN_NAME_MISSING",
    "message": "Plan name does not exist in LAM",
    "section": "3. Conversion"
  }
}
```

---

## 9. DAG Execution Plan

```
PHASE 1 — Layer 0 (parallel):
  sec2_percentage       — 1 tree, no dependencies
  sec3_conversion       — 9 trees, no dependencies

Gate check: scan sec3 actions for /lam/update → set has_lam_updates

PHASE 2 — Layer 1 (parallel, conditional on has_lam_updates = false):
  sec5_hard_cost        — 1 tree, depends on [sec3_conversion]
  sec6_lot_cost         — 1 tree, depends on [sec3_conversion]
  sec7_contract_price   — 1 tree, depends on [sec3_conversion]
  sec8_appraisal        — 1 tree, depends on [sec3_conversion]
  sec9_borrowing_base   — 1 tree, depends on [sec3_conversion]
  sec10_availability    — 1 tree, depends on [sec3_conversion]
```

### 9.1 Gate Implementation

The gate is implemented as a calculated field that runs AFTER Phase 1 trees
but BEFORE Phase 2 trees. Each Phase 2 tree wraps its real condition inside
an outer gate:

```yaml
condition:
  operator: "and"
  conditions:
    - operator: "eq"
      left_column: "has_lam_updates"
      right_value: "No"
    - (actual section condition)
```

If `has_lam_updates` is "Yes", the `and` short-circuits and the tree evaluates
to false without checking the actual condition. The `on_false` action is
`action: "none"` — the section is silently skipped.

---

## 10. Testing Requirements

### 10.1 Phase 1 Only (LAM update produced → Phase 2 skipped)

| Test Row | Conversion | Expected |
|----------|-----------|----------|
| T1 | SPEC→PRESOLD, contract OK | LAM update, Phase 2 skipped |
| T2 | LOT→SPEC, all checks pass | LAM update (3 fields), Phase 2 skipped |
| T3 | LOT→PRESOLD, all checks pass | LAM update (4 fields), Phase 2 skipped |
| T4 | PRESOLD→MODEL, basis=Standard | LAM update, Phase 2 skipped |

### 10.2 Phase 1 → Phase 2 (no LAM update → Phase 2 runs)

| Test Row | Conversion | Expected |
|----------|-----------|----------|
| T5 | Illogical progression | Exc 13, Phase 2 runs, flags field changes |
| T6 | LOT→SPEC, plan missing | Exc 5, no LAM update, Phase 2 runs |
| T7 | No conversion, hard cost changed | No Sec 3 action, Phase 2 → Exc 14 |
| T8 | No conversion, borrowing base changed | Phase 2 → Exc 18 |

### 10.3 Edge Cases

| Test Row | Scenario | Expected |
|----------|---------|----------|
| T9 | PRESOLD→MODEL, basis=Custom | LAM update + Exc 12, Phase 2 skipped (LAM WAS updated) |
| T10 | Percentage change only, no conversion | Exc 1 (if not provided), Phase 2 runs |
| T11 | All fields clean, no changes | Zero exceptions, dt:passed = true |
