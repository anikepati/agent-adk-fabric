"""
Database write processor: insert or upsert message payload into a table.
"""
from __future__ import annotations

from typing import Any

from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult
from app.processors.base import BaseProcessor, ProcessorContext
from app.processors.registry import register_processor


@register_processor("db_write")
class DbWriteProcessor(BaseProcessor):

    def __init__(self, config: dict[str, Any], context: ProcessorContext) -> None:
        super().__init__(config, context)
        self._dsn: str = config["dsn"]
        self._table: str = config["table"]
        self._column_map: dict[str, str] = config.get("column_map", {})
        self._upsert_keys: list[str] = config.get("upsert_keys", [])
        self._engine = None
        self._async_engine = None

    async def startup(self) -> None:
        from sqlalchemy.ext.asyncio import create_async_engine

        self._async_engine = create_async_engine(
            self._dsn,
            pool_size=5,
            max_overflow=10,
            pool_pre_ping=True,
        )

    async def process(self, message: ConsumerMessage) -> ProcessorResult:
        if self._async_engine is None:
            await self.startup()

        try:
            data = message.value
            if not isinstance(data, dict):
                return ProcessorResult.dlq(f"Expected dict payload, got {type(data).__name__}")

            # Apply column mapping
            if self._column_map:
                mapped = {}
                for src, dst in self._column_map.items():
                    if src in data:
                        mapped[dst] = data[src]
                data = mapped

            from sqlalchemy import text
            from sqlalchemy.ext.asyncio import AsyncSession
            from sqlalchemy.orm import sessionmaker

            async_session = sessionmaker(self._async_engine, class_=AsyncSession, expire_on_commit=False)

            columns = ", ".join(data.keys())
            placeholders = ", ".join(f":{k}" for k in data.keys())
            sql = f"INSERT INTO {self._table} ({columns}) VALUES ({placeholders})"

            async with async_session() as session:
                async with session.begin():
                    await session.execute(text(sql), data)

            return ProcessorResult.success({"table": self._table, "rows": 1})

        except Exception as e:
            error_str = str(e)
            # Transient DB errors are retriable
            if any(kw in error_str.lower() for kw in ["timeout", "connection", "deadlock"]):
                return ProcessorResult.retry(f"DB error (transient): {error_str}", e)
            return ProcessorResult.dlq(f"DB error: {error_str}", e)

    async def shutdown(self) -> None:
        if self._async_engine:
            await self._async_engine.dispose()
