"""
Normalized message wrapper around confluent-kafka Message.
Processors receive this instead of the raw Kafka message.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass(slots=True)
class ConsumerMessage:
    """Immutable message wrapper passed to processors."""

    topic: str
    partition: int
    offset: int
    key: Optional[bytes]
    value: Any  # deserialized payload
    raw_value: bytes  # original bytes
    headers: dict[str, str]
    timestamp_ms: int
    cluster_name: str

    # Set by framework at dispatch time
    received_at: float = field(default_factory=time.monotonic)

    @property
    def partition_key(self) -> tuple[str, int]:
        return (self.topic, self.partition)

    @property
    def age_ms(self) -> float:
        return (time.monotonic() - self.received_at) * 1000

    def header(self, key: str, default: str = "") -> str:
        return self.headers.get(key, default)

    def __repr__(self) -> str:
        return (
            f"ConsumerMessage(topic={self.topic!r}, partition={self.partition}, "
            f"offset={self.offset}, cluster={self.cluster_name!r})"
        )
