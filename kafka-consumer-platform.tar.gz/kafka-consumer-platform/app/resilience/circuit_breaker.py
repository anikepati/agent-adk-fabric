"""
Per-handler circuit breaker with three states: CLOSED, OPEN, HALF_OPEN.
"""
from __future__ import annotations

import logging
import time
from enum import Enum
from threading import Lock

from app.config.models import CircuitBreakerConfig

logger = logging.getLogger(__name__)


class CircuitState(str, Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """Thread-safe circuit breaker for a single handler/topic."""

    def __init__(self, name: str, config: CircuitBreakerConfig) -> None:
        self.name = name
        self._config = config
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._half_open_calls = 0
        self._last_failure_time: float = 0
        self._lock = Lock()

    @property
    def state(self) -> CircuitState:
        with self._lock:
            if self._state == CircuitState.OPEN:
                elapsed = time.monotonic() - self._last_failure_time
                if elapsed >= self._config.recovery_timeout_s:
                    self._state = CircuitState.HALF_OPEN
                    self._half_open_calls = 0
                    logger.info(
                        "Circuit breaker transitioning to HALF_OPEN",
                        extra={"handler": self.name},
                    )
            return self._state

    @property
    def is_open(self) -> bool:
        return self.state == CircuitState.OPEN

    def allow_request(self) -> bool:
        """Check if a request is allowed through the circuit breaker."""
        current_state = self.state
        if current_state == CircuitState.CLOSED:
            return True
        if current_state == CircuitState.OPEN:
            return False
        # HALF_OPEN: allow limited calls
        with self._lock:
            if self._half_open_calls < self._config.half_open_max:
                self._half_open_calls += 1
                return True
            return False

    def record_success(self) -> None:
        with self._lock:
            if self._state == CircuitState.HALF_OPEN:
                self._half_open_calls -= 1
                if self._half_open_calls <= 0:
                    self._state = CircuitState.CLOSED
                    self._failure_count = 0
                    logger.info(
                        "Circuit breaker CLOSED (recovered)",
                        extra={"handler": self.name},
                    )
            else:
                self._failure_count = 0

    def record_failure(self) -> None:
        with self._lock:
            self._failure_count += 1
            self._last_failure_time = time.monotonic()

            if self._state == CircuitState.HALF_OPEN:
                self._state = CircuitState.OPEN
                logger.warning(
                    "Circuit breaker OPEN (half-open test failed)",
                    extra={"handler": self.name},
                )
            elif self._failure_count >= self._config.failure_threshold:
                self._state = CircuitState.OPEN
                logger.warning(
                    "Circuit breaker OPEN (threshold reached)",
                    extra={
                        "handler": self.name,
                        "failure_count": self._failure_count,
                        "threshold": self._config.failure_threshold,
                    },
                )

    def reset(self) -> None:
        with self._lock:
            self._state = CircuitState.CLOSED
            self._failure_count = 0
            self._half_open_calls = 0
