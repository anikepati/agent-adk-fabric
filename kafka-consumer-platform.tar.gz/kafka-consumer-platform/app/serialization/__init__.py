"""
Message deserialization strategy pattern.
Supports json, avro, protobuf, and raw formats.
"""
from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from typing import Any

logger = logging.getLogger(__name__)


class DeserializationError(Exception):
    """Raised when message deserialization fails (poison pill)."""
    pass


class Deserializer(ABC):
    @abstractmethod
    def deserialize(self, data: bytes) -> Any:
        ...


class JsonDeserializer(Deserializer):
    def deserialize(self, data: bytes) -> Any:
        try:
            return json.loads(data)
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            raise DeserializationError(f"JSON deserialization failed: {e}") from e


class RawDeserializer(Deserializer):
    def deserialize(self, data: bytes) -> bytes:
        return data


class AvroDeserializer(Deserializer):
    def __init__(self, schema_registry_url: str | None = None, auth: str | None = None):
        self._deserializer = None
        if schema_registry_url:
            try:
                from confluent_kafka.schema_registry import SchemaRegistryClient
                from confluent_kafka.schema_registry.avro import AvroDeserializer as _AvroDeser

                sr_conf = {"url": schema_registry_url}
                if auth:
                    parts = auth.split(":", 1)
                    if len(parts) == 2:
                        sr_conf["basic.auth.user.info"] = auth
                sr_client = SchemaRegistryClient(sr_conf)
                self._deserializer = _AvroDeser(sr_client)
            except ImportError:
                logger.warning(
                    "confluent_kafka.schema_registry not available, "
                    "Avro deserialization will fall back to JSON"
                )

    def deserialize(self, data: bytes) -> Any:
        if self._deserializer:
            try:
                return self._deserializer(data, None)
            except Exception as e:
                raise DeserializationError(f"Avro deserialization failed: {e}") from e
        # Fallback: try JSON
        return JsonDeserializer().deserialize(data)


def create_deserializer(
    format_type: str,
    schema_registry_url: str | None = None,
    schema_registry_auth: str | None = None,
) -> Deserializer:
    """Factory for creating format-specific deserializers."""
    if format_type == "json":
        return JsonDeserializer()
    elif format_type == "avro":
        return AvroDeserializer(schema_registry_url, schema_registry_auth)
    elif format_type == "raw":
        return RawDeserializer()
    else:
        logger.warning(f"Unknown format '{format_type}', defaulting to JSON")
        return JsonDeserializer()
