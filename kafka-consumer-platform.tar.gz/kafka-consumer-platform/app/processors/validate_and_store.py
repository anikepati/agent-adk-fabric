"""
Validate-and-Store processor: validates against schema, then writes to DB.
Convenience processor combining validate + db_write in a single step.
"""
from __future__ import annotations

import json
from typing import Any

from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult
from app.processors.base import BaseProcessor, ProcessorContext
from app.processors.registry import register_processor


@register_processor("validate_and_store")
class ValidateAndStoreProcessor(BaseProcessor):

    def __init__(self, config: dict[str, Any], context: ProcessorContext) -> None:
        super().__init__(config, context)
        self._schema_name: str | None = config.get("schema")
        self._target_table: str = config["target_table"]
        self._validation_rules: list[str] = config.get("validation_rules", [])
        self._column_map: dict[str, str] = config.get("column_map", {})
        self._dsn: str | None = config.get("dsn")
        self._engine = None

    async def startup(self) -> None:
        if self._dsn:
            from sqlalchemy.ext.asyncio import create_async_engine
            self._engine = create_async_engine(self._dsn, pool_size=5, pool_pre_ping=True)

    async def process(self, message: ConsumerMessage) -> ProcessorResult:
        data = message.value
        if not isinstance(data, dict):
            return ProcessorResult.dlq(f"Expected dict, got {type(data).__name__}")

        # Validation phase
        for rule in self._validation_rules:
            if rule == "required_fields":
                required = self.config.get("required", [])
                missing = [f for f in required if f not in data or data[f] is None]
                if missing:
                    return ProcessorResult.dlq(f"Missing required fields: {missing}")

        # Apply column mapping
        if self._column_map:
            mapped = {}
            for src, dst in self._column_map.items():
                if src in data:
                    mapped[dst] = data[src]
            data = mapped

        # Store phase
        if self._engine:
            try:
                from sqlalchemy import text
                from sqlalchemy.ext.asyncio import AsyncSession
                from sqlalchemy.orm import sessionmaker

                async_session = sessionmaker(
                    self._engine, class_=AsyncSession, expire_on_commit=False
                )
                columns = ", ".join(data.keys())
                placeholders = ", ".join(f":{k}" for k in data.keys())
                sql = f"INSERT INTO {self._target_table} ({columns}) VALUES ({placeholders})"

                async with async_session() as session:
                    async with session.begin():
                        await session.execute(text(sql), data)

                return ProcessorResult.success(
                    {"table": self._target_table, "rows": 1}
                )
            except Exception as e:
                error_str = str(e)
                if any(kw in error_str.lower() for kw in ["timeout", "connection", "deadlock"]):
                    return ProcessorResult.retry(f"DB error: {error_str}", e)
                return ProcessorResult.dlq(f"DB error: {error_str}", e)
        else:
            # No DSN: just validate and pass through
            self.logger.info(
                f"Validated message for {self._target_table} (no DSN configured, store skipped)"
            )
            return ProcessorResult.success({"table": self._target_table, "stored": False})

    async def shutdown(self) -> None:
        if self._engine:
            await self._engine.dispose()
