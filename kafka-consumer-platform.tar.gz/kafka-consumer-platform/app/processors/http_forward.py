"""
HTTP Forward processor: sends message payload to a REST endpoint.
"""
from __future__ import annotations

import json
from typing import Any

import httpx

from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult
from app.processors.base import BaseProcessor, ProcessorContext
from app.processors.registry import register_processor


@register_processor("http_forward")
class HttpForwardProcessor(BaseProcessor):

    def __init__(self, config: dict[str, Any], context: ProcessorContext) -> None:
        super().__init__(config, context)
        self._url: str = config["url"]
        self._method: str = config.get("method", "POST").upper()
        self._headers: dict[str, str] = config.get("headers", {})
        self._success_codes: set[int] = set(config.get("success_codes", [200, 201, 202]))
        self._timeout: float = config.get("http_timeout_s", 30.0)
        self._client: httpx.AsyncClient | None = None

    async def startup(self) -> None:
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(self._timeout),
            headers=self._headers,
        )

    async def process(self, message: ConsumerMessage) -> ProcessorResult:
        if self._client is None:
            await self.startup()

        try:
            payload = message.value if isinstance(message.value, (str, bytes)) else json.dumps(message.value)
            response = await self._client.request(
                method=self._method,
                url=self._url,
                content=payload,
                headers={"Content-Type": "application/json"},
            )

            if response.status_code in self._success_codes:
                return ProcessorResult.success({"status_code": response.status_code})

            if response.status_code >= 500:
                return ProcessorResult.retry(
                    f"HTTP {response.status_code} from {self._url}"
                )

            return ProcessorResult.dlq(
                f"HTTP {response.status_code}: {response.text[:200]}"
            )

        except httpx.TimeoutException as e:
            return ProcessorResult.retry(f"Timeout calling {self._url}: {e}", e)
        except httpx.ConnectError as e:
            return ProcessorResult.retry(f"Connection error to {self._url}: {e}", e)
        except Exception as e:
            return ProcessorResult.dlq(f"Unexpected error: {e}", e)

    async def shutdown(self) -> None:
        if self._client:
            await self._client.aclose()
