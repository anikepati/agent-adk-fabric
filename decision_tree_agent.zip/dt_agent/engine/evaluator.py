"""Condition evaluator with 14-operator registry."""

import re, math, logging
from typing import Any, Callable, Dict, Optional, Union
from models.schemas import SimpleCondition, CompoundCondition, Condition

logger = logging.getLogger(__name__)
RowData = Dict[str, Any]


def _is_null(v):
    return v is None or (isinstance(v, float) and math.isnan(v))

def _safe_cmp(l, r, op):
    if _is_null(l) or _is_null(r): return False
    try: return op(float(l), float(r))
    except: return op(str(l), str(r))

def _safe_eq(l, r):
    if _is_null(l) and _is_null(r): return True
    if _is_null(l) or _is_null(r): return False
    try: return float(l) == float(r)
    except: return str(l).strip() == str(r).strip()

def _str_op(l, r, op):
    return False if _is_null(l) else op(str(l), str(r))


OPERATORS: Dict[str, Callable] = {
    "gt":  lambda l, r, **_: _safe_cmp(l, r, lambda a,b: a>b),
    "gte": lambda l, r, **_: _safe_cmp(l, r, lambda a,b: a>=b),
    "lt":  lambda l, r, **_: _safe_cmp(l, r, lambda a,b: a<b),
    "lte": lambda l, r, **_: _safe_cmp(l, r, lambda a,b: a<=b),
    "eq":  lambda l, r, **_: _safe_eq(l, r),
    "neq": lambda l, r, **_: not _safe_eq(l, r),
    "contains":    lambda l, r, **_: _str_op(l, r, lambda s,v: v in s),
    "starts_with": lambda l, r, **_: _str_op(l, r, lambda s,v: s.startswith(v)),
    "ends_with":   lambda l, r, **_: _str_op(l, r, lambda s,v: s.endswith(v)),
    "is_empty":    lambda l, **_: _is_null(l) or str(l).strip()=="",
    "regex":       lambda l, pattern=None, **_: bool(re.match(pattern, str(l or ""))),
    "is_null":     lambda l, **_: _is_null(l),
    "is_not_null": lambda l, **_: not _is_null(l),
    "between":     lambda l, low=None, high=None, **_: (not _is_null(l)) and float(low)<=float(l)<=float(high),
    "in":          lambda l, values=None, **_: l in (values or []),
    "not_in":      lambda l, values=None, **_: l not in (values or []),
}

UNARY_OPS = {"is_null", "is_not_null", "is_empty", "regex"}
KWARGS_ONLY_OPS = {"between", "in", "not_in"}


def evaluate(condition: Condition, row: RowData) -> bool:
    """Evaluate a condition (simple or compound) against a row."""
    if isinstance(condition, CompoundCondition):
        if condition.operator == "and":
            return all(evaluate(c, row) for c in condition.conditions)
        return any(evaluate(c, row) for c in condition.conditions)

    c = condition
    left = row.get(c.left_column)
    right = row.get(c.right_column) if c.right_column else c.right_value
    kwargs = {"pattern": c.pattern, "low": c.low, "high": c.high, "values": c.values}
    op = OPERATORS[c.operator]

    if c.operator in UNARY_OPS:
        return op(left, **kwargs)
    if c.operator in KWARGS_ONLY_OPS:
        return op(left, **kwargs)
    return op(left, right, **kwargs)
