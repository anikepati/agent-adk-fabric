"""
Validate processor: validate message against JSON Schema or custom rules.
"""
from __future__ import annotations

import json
from typing import Any

from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult
from app.processors.base import BaseProcessor, ProcessorContext
from app.processors.registry import register_processor


@register_processor("validate")
class ValidateProcessor(BaseProcessor):

    def __init__(self, config: dict[str, Any], context: ProcessorContext) -> None:
        super().__init__(config, context)
        self._schema_ref: str | None = config.get("schema_ref") or config.get("schema")
        self._rules: list[str] = config.get("rules", [])
        self._on_fail: str = config.get("on_fail", "dlq")  # dlq | skip
        self._compiled_schema = None

    async def startup(self) -> None:
        if self._schema_ref:
            try:
                import jsonschema
                # Load schema from file or registry
                schema_path = f"/config/schemas/{self._schema_ref}.json"
                try:
                    with open(schema_path) as f:
                        self._compiled_schema = json.load(f)
                except FileNotFoundError:
                    self.logger.warning(
                        f"Schema file not found: {schema_path}, "
                        "validation will be skipped"
                    )
            except ImportError:
                self.logger.warning("jsonschema not installed, schema validation disabled")

    async def process(self, message: ConsumerMessage) -> ProcessorResult:
        data = message.value
        if not isinstance(data, dict):
            return self._fail(f"Expected dict, got {type(data).__name__}")

        # JSON Schema validation
        if self._compiled_schema:
            try:
                import jsonschema
                jsonschema.validate(instance=data, schema=self._compiled_schema)
            except jsonschema.ValidationError as e:
                return self._fail(f"Schema validation failed: {e.message}")

        # Custom rule validation
        for rule in self._rules:
            if rule == "required_fields":
                required = self.config.get("required", [])
                missing = [f for f in required if f not in data or data[f] is None]
                if missing:
                    return self._fail(f"Missing required fields: {missing}")

            elif rule == "amount_range":
                amount_field = self.config.get("amount_field", "amount")
                min_val = self.config.get("amount_min", 0)
                max_val = self.config.get("amount_max", float("inf"))
                amount = data.get(amount_field)
                if amount is not None and not (min_val <= float(amount) <= max_val):
                    return self._fail(
                        f"Amount {amount} outside range [{min_val}, {max_val}]"
                    )

        return ProcessorResult.success()

    def _fail(self, reason: str) -> ProcessorResult:
        if self._on_fail == "skip":
            return ProcessorResult.skip(reason)
        return ProcessorResult.dlq(reason)
