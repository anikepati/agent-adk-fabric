"""
Test v4 engine — validates calculated fields, nested trees, DAG, and exceptions.
Runs without google-adk (tests core engine only).

Usage: python test_engine.py
"""

import yaml
import json
from models.schemas import DecisionTreeConfig
from engine.evaluator import compute_fields
from engine.walker import walk_all, walk_tree, collect_actions
from engine.dag_executor import DAGExecutor


def test():
    with open("config/example_rules.yaml") as f:
        raw = yaml.safe_load(f)
    config = DecisionTreeConfig(**raw)
    print(f"Config: {len(config.decision_trees)} trees, "
          f"{len(config.calculated_fields or [])} calc fields, "
          f"DAG={'yes' if config.dag else 'no'}\n")

    rows = [
        {
            "ID": "ROW-001",
            "BB": 5000, "BC": 3000, "Amount": 150000, "Currency": "USD",
            "Email": "user@test.com", "Country": "US",
            "HardCost": 200000, "LotCost": 100000,
            "Profit": 30000, "Revenue": 100000,
            "Mobile": None, "WorkPhone": "555-1234", "HomePhone": "555-9999",
            "FirstName": "John", "LastName": "Doe",
        },
        {
            "ID": "ROW-002",
            "BB": 1000, "BC": 9000, "Amount": 500, "Currency": "EUR",
            "Email": None, "Country": "BR",
            "HardCost": 300000, "LotCost": 250000,
            "Profit": 10000, "Revenue": 100000,
            "Mobile": "555-0001", "WorkPhone": None, "HomePhone": None,
            "FirstName": "Jane", "LastName": "Smith",
        },
        {
            "ID": "ROW-003",
            "BB": 7000, "BC": 7000, "Amount": 100000, "Currency": "JPY",
            "Email": "test@example.com", "Country": "DE",
            "HardCost": 100000, "LotCost": 50000,
            "Profit": 5000, "Revenue": 50000,
            "Mobile": None, "WorkPhone": None, "HomePhone": None,
            "FirstName": "Bob", "LastName": "Lee",
        },
    ]

    tree_map = {t.id: t for t in config.decision_trees}
    dag = DAGExecutor(config.dag) if config.dag else None

    for row in rows:
        row = dict(row)
        row_id = row["ID"]
        print(f"{'═' * 60}")
        print(f"ROW: {row_id}")
        print(f"{'═' * 60}")

        # 1. Calculated fields
        calc = {}
        if config.calculated_fields:
            calc = compute_fields(config.calculated_fields, row)
            print(f"\n  Calculated fields:")
            for k, v in calc.items():
                print(f"    {k} = {v}")

        # 2. Tree evaluation (DAG or flat)
        if dag:
            dag_report = dag.execute(row, row_id, tree_map, walk_tree)
            decisions = dag.all_results()
            print(f"\n  DAG: {dag_report['executed']} nodes executed, {dag_report['skipped']} skipped")
            for lr in dag_report["layers"]:
                ids = [n["id"] for n in lr["nodes"]]
                print(f"    Layer {lr['layer']}: {ids}")
        else:
            decisions = walk_all(config.decision_trees, row)

        # 3. Flatten actions
        all_actions = []
        for d in decisions:
            all_actions.extend(collect_actions(d))

        # 4. Exceptions
        exceptions = [
            a for a in all_actions
            if "exception" in str(a.get("endpoint", "")).lower()
            or "exception_id" in (a.get("payload") or {})
        ]
        passed = len(exceptions) == 0

        # 5. Print tree results
        print(f"\n  Decision paths:")
        for d in decisions:
            _print(d, 4)

        # 6. Summary
        print(f"\n  Actions: {len(all_actions)}")
        print(f"  Exceptions: {len(exceptions)}")
        print(f"  Passed: {'✓' if passed else '✗'}")
        if exceptions:
            for e in exceptions:
                eid = e.get("payload", {}).get("exception_id", "?")
                etype = e.get("payload", {}).get("exception_type", "?")
                print(f"    → Exception {eid}: {etype}")
        print()


def _print(node, indent):
    p = " " * indent
    icon = "✓" if node["result"] else "✗"
    act = node["action"]["action"]
    detail = ""
    if act == "api_call":
        ep = node["action"].get("endpoint", "")
        detail = f" → {ep}"
        pl = node["action"].get("payload", {})
        if "exception_id" in pl:
            detail += f" [Exc {pl['exception_id']}]"
    elif act == "db_update":
        detail = f" → SET {node['action'].get('set', {})}"
    elif act == "none":
        detail = " → (skip)"

    print(f"{p}{icon} [{node['node_id']}] {node['node_name']} → {node['branch']}: {act}{detail}")
    for c in node.get("children", []):
        _print(c, indent + 4)


if __name__ == "__main__":
    test()
