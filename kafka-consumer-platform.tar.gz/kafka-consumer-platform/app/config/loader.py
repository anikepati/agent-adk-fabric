"""
Configuration loader: YAML → secret resolution → pydantic validation → AppConfig.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path

import yaml

from app.config.models import AppConfig
from app.config.secret_resolver import resolve_config

logger = logging.getLogger(__name__)

DEFAULT_CONFIG_PATH = "/config/consumer-config.yaml"


def load_config(config_path: str | None = None) -> AppConfig:
    """Load, resolve, and validate the application configuration."""
    path = config_path or os.environ.get("CONFIG_PATH", DEFAULT_CONFIG_PATH)
    config_file = Path(path)

    if not config_file.exists():
        raise FileNotFoundError(f"Configuration file not found: {path}")

    logger.info("Loading configuration", extra={"config_path": str(config_file)})

    # 1. Parse YAML
    with open(config_file) as f:
        raw_config = yaml.safe_load(f)

    if not raw_config:
        raise ValueError("Configuration file is empty")

    # 2. Resolve secret placeholders
    resolved_config = resolve_config(raw_config)

    # 3. Validate with pydantic
    app_config = AppConfig.model_validate(resolved_config)

    # 4. Apply defaults to topics
    app_config.resolve_topic_defaults()

    # 5. Validate processor types exist (done later during bootstrap)
    total_topics = sum(len(c.topics) for c in app_config.clusters.values())
    total_clusters = len(app_config.clusters)
    logger.info(
        "Configuration loaded successfully",
        extra={
            "total_clusters": total_clusters,
            "total_topics": total_topics,
            "cluster_names": list(app_config.clusters.keys()),
        },
    )

    return app_config
