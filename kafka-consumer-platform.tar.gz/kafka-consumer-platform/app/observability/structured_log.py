"""
Structured JSON logging setup using structlog.
Every log entry includes contextual fields for filtering and correlation.
"""
from __future__ import annotations

import logging
import os
import sys

import structlog


def setup_logging(level: str = "INFO") -> None:
    """Configure structured JSON logging for the entire application."""
    log_level = getattr(logging, level.upper(), logging.INFO)

    # Add common context
    pod_name = os.environ.get("HOSTNAME", "unknown")
    ocp_cluster = os.environ.get("OCP_CLUSTER", "unknown")

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.StackInfoRenderer(),
            structlog.dev.set_exc_info,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(log_level),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )

    # Also configure standard library logging to use structlog
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=log_level,
    )

    # Set structlog as the default renderer for stdlib loggers
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    # Bind common context
    structlog.contextvars.bind_contextvars(
        pod=pod_name,
        ocp_cluster=ocp_cluster,
    )
