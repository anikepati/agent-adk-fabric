"""
Leader election using Kubernetes Lease API.
Each pod attempts to acquire a Lease. The winner becomes the leader.
Leader renews the lease periodically. If the leader dies, the lease expires
and another pod takes over.
"""
from __future__ import annotations

import logging
import os
import threading
import time
from datetime import datetime, timezone

from app.config.models import LeaderElectionConfig

logger = logging.getLogger(__name__)


class LeaderElector:
    """Kubernetes Lease-based leader election."""

    def __init__(
        self,
        config: LeaderElectionConfig,
        shutdown_event: threading.Event,
        on_elected: callable | None = None,
        on_demoted: callable | None = None,
    ) -> None:
        self._config = config
        self._shutdown_event = shutdown_event
        self._on_elected = on_elected
        self._on_demoted = on_demoted

        self._is_leader = False
        self._identity = os.environ.get("HOSTNAME", f"pod-{os.getpid()}")
        self._namespace = self._get_namespace()
        self._thread: threading.Thread | None = None

        # K8s client (lazy init)
        self._k8s_api = None

    @property
    def is_leader(self) -> bool:
        return self._is_leader

    def start(self) -> None:
        """Start the leader election thread."""
        if not self._config.enabled:
            logger.info("Leader election disabled")
            return

        self._thread = threading.Thread(
            target=self._election_loop,
            name="leader-elector",
            daemon=True,
        )
        self._thread.start()
        logger.info(
            "Leader election started",
            extra={
                "identity": self._identity,
                "lease_name": self._config.lease_name,
            },
        )

    def _election_loop(self) -> None:
        """Main election loop: try to acquire/renew lease."""
        while not self._shutdown_event.is_set():
            try:
                if self._is_leader:
                    # Renew the lease
                    success = self._renew_lease()
                    if not success:
                        self._is_leader = False
                        logger.warning("Lost leadership (renewal failed)")
                        if self._on_demoted:
                            self._on_demoted()
                    interval = self._config.renew_interval_s
                else:
                    # Try to acquire the lease
                    success = self._try_acquire()
                    if success:
                        self._is_leader = True
                        logger.info("Elected as leader", extra={"identity": self._identity})
                        if self._on_elected:
                            self._on_elected()
                    interval = self._config.retry_interval_s

            except Exception as e:
                logger.error(f"Leader election error: {e}", exc_info=True)
                if self._is_leader:
                    self._is_leader = False
                    if self._on_demoted:
                        self._on_demoted()
                interval = self._config.retry_interval_s

            # Wait with early exit on shutdown
            self._shutdown_event.wait(timeout=interval)

    def _try_acquire(self) -> bool:
        """Try to acquire the lease."""
        api = self._get_k8s_api()
        if not api:
            return self._fallback_election()

        try:
            from kubernetes.client.rest import ApiException

            try:
                lease = api.read_namespaced_lease(
                    name=self._config.lease_name,
                    namespace=self._namespace,
                )

                # Check if lease is expired
                if lease.spec.renew_time:
                    renew_time = lease.spec.renew_time
                    if isinstance(renew_time, str):
                        renew_time = datetime.fromisoformat(renew_time.replace("Z", "+00:00"))

                    elapsed = (datetime.now(timezone.utc) - renew_time).total_seconds()
                    if elapsed < self._config.lease_duration_s:
                        # Lease is still held by someone else
                        return False

                # Lease expired — try to take it
                lease.spec.holder_identity = self._identity
                lease.spec.lease_duration_seconds = self._config.lease_duration_s
                lease.spec.renew_time = datetime.now(timezone.utc).isoformat()
                lease.spec.acquire_time = datetime.now(timezone.utc).isoformat()

                api.replace_namespaced_lease(
                    name=self._config.lease_name,
                    namespace=self._namespace,
                    body=lease,
                )
                return True

            except ApiException as e:
                if e.status == 404:
                    # Lease doesn't exist — create it
                    return self._create_lease(api)
                raise

        except ImportError:
            return self._fallback_election()
        except Exception as e:
            logger.debug(f"Lease acquisition failed: {e}")
            return False

    def _renew_lease(self) -> bool:
        """Renew the held lease."""
        api = self._get_k8s_api()
        if not api:
            return True  # If no K8s, fallback always stays leader

        try:
            lease = api.read_namespaced_lease(
                name=self._config.lease_name,
                namespace=self._namespace,
            )

            if lease.spec.holder_identity != self._identity:
                # Someone else holds the lease
                return False

            lease.spec.renew_time = datetime.now(timezone.utc).isoformat()
            api.replace_namespaced_lease(
                name=self._config.lease_name,
                namespace=self._namespace,
                body=lease,
            )
            return True

        except Exception as e:
            logger.error(f"Lease renewal failed: {e}")
            return False

    def _create_lease(self, api) -> bool:
        """Create a new Lease resource."""
        try:
            from kubernetes.client import V1Lease, V1LeaseSpec, V1ObjectMeta

            lease = V1Lease(
                metadata=V1ObjectMeta(
                    name=self._config.lease_name,
                    namespace=self._namespace,
                ),
                spec=V1LeaseSpec(
                    holder_identity=self._identity,
                    lease_duration_seconds=self._config.lease_duration_s,
                    acquire_time=datetime.now(timezone.utc),
                    renew_time=datetime.now(timezone.utc),
                ),
            )
            api.create_namespaced_lease(
                namespace=self._namespace,
                body=lease,
            )
            return True
        except Exception as e:
            logger.debug(f"Lease creation failed: {e}")
            return False

    def _get_k8s_api(self):
        """Lazy-initialize K8s API client."""
        if self._k8s_api is not None:
            return self._k8s_api

        try:
            from kubernetes import client, config as k8s_config

            try:
                k8s_config.load_incluster_config()
            except k8s_config.ConfigException:
                try:
                    k8s_config.load_kube_config()
                except k8s_config.ConfigException:
                    logger.info("K8s config not available, using fallback election")
                    return None

            self._k8s_api = client.CoordinationV1Api()
            return self._k8s_api
        except ImportError:
            logger.info("kubernetes package not installed, using fallback election")
            return None

    def _fallback_election(self) -> bool:
        """Simple fallback: first pod (alphabetically by hostname) is leader.
        Used when K8s API is not available (e.g., local development).
        """
        # Without K8s, there's no coordination — just become leader
        return True

    def _get_namespace(self) -> str:
        """Get the current K8s namespace."""
        ns_file = "/var/run/secrets/kubernetes.io/serviceaccount/namespace"
        try:
            with open(ns_file) as f:
                return f.read().strip()
        except FileNotFoundError:
            return os.environ.get("POD_NAMESPACE", "default")

    def stop(self) -> None:
        """Release leadership on shutdown."""
        if self._is_leader:
            self._is_leader = False
            logger.info("Released leadership")
