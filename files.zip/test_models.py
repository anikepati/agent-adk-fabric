"""Tests for core.models."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from core.models import (
    ElementInfo,
    PageState,
    ExecutionResult,
    ErrorContext,
    ErrorCategory,
    ScriptAttempt,
    WorkflowExecution,
    WorkflowStatus,
)


class TestElementInfo:
    def test_best_selector_id(self):
        el = ElementInfo(tag="button", selector="#submit")
        assert el.best_selector() == "#submit"

    def test_best_selector_name(self):
        el = ElementInfo(tag="input", name="email")
        assert el.best_selector() == '[name="email"]'

    def test_best_selector_aria(self):
        el = ElementInfo(tag="button", aria_label="Save")
        assert el.best_selector() == '[aria-label="Save"]'

    def test_best_selector_fallback(self):
        el = ElementInfo(tag="div", selector=".custom")
        assert el.best_selector() == ".custom"


class TestPageState:
    def test_compact_dict_limits_elements(self):
        elements = [ElementInfo(tag="button", text=f"btn{i}") for i in range(60)]
        ps = PageState(url="http://x", title="T", interactive_elements=elements)
        d = ps.to_compact_dict()
        assert len(d["elements"]) == 40

    def test_compact_dict_skips_empty_fields(self):
        ps = PageState(url="http://x", title="T", interactive_elements=[
            ElementInfo(tag="button", text="Click"),
        ])
        d = ps.to_compact_dict()
        el = d["elements"][0]
        assert "tag" in el and "txt" in el
        assert "sel" not in el  # no selector set


class TestExecutionResult:
    def test_progress_pct(self):
        r = ExecutionResult(success=False, executed_lines=3, total_lines=10, duration_ms=0)
        assert r.progress_pct == 30.0

    def test_progress_pct_zero_total(self):
        r = ExecutionResult(success=False, executed_lines=0, total_lines=0, duration_ms=0)
        assert r.progress_pct == 0.0

    def test_all_validations_passed_empty(self):
        r = ExecutionResult(success=True, executed_lines=1, total_lines=1, duration_ms=0)
        assert r.all_validations_passed is True


class TestScriptAttempt:
    def test_hash_deterministic(self):
        h1 = ScriptAttempt.compute_hash("page.goto('x')")
        h2 = ScriptAttempt.compute_hash("page.goto('x')")
        assert h1 == h2

    def test_hash_changes_with_content(self):
        h1 = ScriptAttempt.compute_hash("page.goto('x')")
        h2 = ScriptAttempt.compute_hash("page.goto('y')")
        assert h1 != h2


class TestWorkflowExecution:
    def test_audit_dict_redacts_secrets(self):
        we = WorkflowExecution(
            workflow_name="test",
            params={"bu_name": "ACME", "password": "secret123", "token": "tok"},
        )
        d = we.to_audit_dict()
        assert "bu_name" in d["params"]
        assert "password" not in d["params"]
        assert "token" not in d["params"]

    def test_status_tracking(self):
        we = WorkflowExecution(workflow_name="test")
        assert we.status == WorkflowStatus.PENDING
        assert we.attempt_count == 0
