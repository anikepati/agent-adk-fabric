"""
Column Extractor — scans decision tree config and extracts all referenced columns.
Used to validate Excel has required columns before processing.
"""

from typing import Set
from models.schemas import (
    DecisionNode, DecisionTreeConfig,
    SimpleCondition, CompoundCondition, ActionBranch,
)


def extract_columns(config: DecisionTreeConfig) -> Set[str]:
    columns = set()
    columns.add(config.settings.row_id_column)
    for tree in config.decision_trees:
        _extract_from_node(tree, columns)
    return columns


def _extract_from_node(node: DecisionNode, columns: Set[str]):
    _extract_from_condition(node.condition, columns)
    _extract_from_branch(node.on_true, columns)
    _extract_from_branch(node.on_false, columns)


def _extract_from_condition(condition, columns: Set[str]):
    if isinstance(condition, SimpleCondition):
        columns.add(condition.left_column)
        if condition.right_column:
            columns.add(condition.right_column)
    elif isinstance(condition, CompoundCondition):
        for sub in condition.conditions:
            _extract_from_condition(sub, columns)


def _extract_from_branch(branch: ActionBranch, columns: Set[str]):
    if branch.next_decision:
        _extract_from_node(branch.next_decision, columns)
