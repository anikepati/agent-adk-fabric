"""Tests for core.config — SkillRegistry and AppConfig."""

import pytest
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from core.config import SkillRegistry, ConfigError


_VALID_YAML = """
scripts:
  test_workflow:
    name: Test Workflow
    description: A test
    version: "1.0.0"
    params_required: [url, name]
    params_optional:
      timeout: "5000"
    tags: [test]
    timeout_seconds: 60
    max_retries: 2
    script: |
      page.goto("{url}")
      page.fill("#name", "{name}")
    validation:
      - type: text_present
        value: "Success"
      - type: url_contains
        value: "/done"
    recovery_hints:
      - "Check the URL"
"""


class TestSkillRegistry:
    def _write(self, content: str) -> str:
        f = tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False)
        f.write(content)
        f.close()
        return f.name

    def test_load_valid(self):
        path = self._write(_VALID_YAML)
        reg = SkillRegistry.from_yaml(path)
        assert reg.skill_count == 1

        skill = reg.get("test_workflow")
        assert skill.name == "Test Workflow"
        assert skill.params_required == ["url", "name"]
        assert skill.max_retries == 2
        assert len(skill.validation) == 2
        assert len(skill.recovery_hints) == 1

    def test_unknown_workflow_raises(self):
        path = self._write(_VALID_YAML)
        reg = SkillRegistry.from_yaml(path)
        with pytest.raises(ConfigError, match="nonexistent"):
            reg.get("nonexistent")

    def test_missing_script_raises(self):
        bad = """
scripts:
  bad:
    name: Bad
    params_required: [x]
"""
        path = self._write(bad)
        with pytest.raises(ConfigError, match="script"):
            SkillRegistry.from_yaml(path)

    def test_invalid_validation_type_raises(self):
        bad = """
scripts:
  bad:
    name: Bad
    params_required: []
    script: "page.goto('x')"
    validation:
      - type: invalid_type
        value: "x"
"""
        path = self._write(bad)
        with pytest.raises(ConfigError, match="invalid validation type"):
            SkillRegistry.from_yaml(path)

    def test_validate_params(self):
        path = self._write(_VALID_YAML)
        reg = SkillRegistry.from_yaml(path)
        skill = reg.get("test_workflow")
        assert skill.validate_params({"url": "x", "name": "y"}) == []
        assert "name" in skill.validate_params({"url": "x"})

    def test_list_skills(self):
        path = self._write(_VALID_YAML)
        reg = SkillRegistry.from_yaml(path)
        listing = reg.list_skills()
        assert len(listing) == 1
        assert listing[0]["key"] == "test_workflow"
        assert listing[0]["version"] == "1.0.0"
