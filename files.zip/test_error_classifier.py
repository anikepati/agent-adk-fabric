"""Tests for core.error_classifier."""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from core.error_classifier import classify_error, is_same_error
from core.models import ErrorAction, ErrorCategory


class TestClassifyError:
    # ── terminal ──────────────────────────────────────────────

    def test_auth_401(self):
        cat, act = classify_error("401 Unauthorized", "Error")
        assert cat == ErrorCategory.AUTH_FAILURE
        assert act == ErrorAction.ABORT

    def test_auth_403(self):
        cat, act = classify_error("403 Forbidden", "Error")
        assert cat == ErrorCategory.AUTH_FAILURE
        assert act == ErrorAction.ABORT

    def test_server_500(self):
        cat, act = classify_error("500 Internal Server Error", "Error")
        assert cat == ErrorCategory.SERVER_ERROR
        assert act == ErrorAction.ABORT

    def test_browser_closed(self):
        cat, act = classify_error("Browser has been closed", "Error")
        assert cat == ErrorCategory.BROWSER_ERROR
        assert act == ErrorAction.ABORT

    def test_dns_failure(self):
        cat, act = classify_error("net::ERR_NAME_NOT_RESOLVED", "Error")
        assert cat == ErrorCategory.NAVIGATION_ERROR
        assert act == ErrorAction.ABORT

    # ── transient ─────────────────────────────────────────────

    def test_network_changed(self):
        cat, act = classify_error("net::ERR_NETWORK_CHANGED", "Error")
        assert cat == ErrorCategory.TRANSIENT
        assert act == ErrorAction.RETRY

    def test_connection_reset(self):
        cat, act = classify_error("net::ERR_CONNECTION_RESET", "Error")
        assert cat == ErrorCategory.TRANSIENT
        assert act == ErrorAction.RETRY

    # ── recoverable ───────────────────────────────────────────

    def test_selector_not_found(self):
        cat, act = classify_error(
            'Timeout 5000ms exceeded waiting for selector "#btn"', "TimeoutError"
        )
        assert cat == ErrorCategory.SELECTOR_NOT_FOUND
        assert act == ErrorAction.REPLAN

    def test_element_not_visible(self):
        cat, act = classify_error("Element is not visible", "Error")
        assert cat == ErrorCategory.ELEMENT_NOT_INTERACTABLE
        assert act == ErrorAction.REPLAN

    def test_generic_timeout(self):
        cat, act = classify_error("Timeout 30000ms exceeded", "TimeoutError")
        assert cat == ErrorCategory.TIMEOUT
        assert act == ErrorAction.REPLAN

    def test_unknown_defaults_to_replan(self):
        cat, act = classify_error("Something weird happened", "CustomError")
        assert cat == ErrorCategory.UNKNOWN
        assert act == ErrorAction.REPLAN


class TestIsSameError:
    def test_same(self):
        assert is_same_error(
            "Timeout 5000ms exceeded waiting for selector '#btn'",
            "Timeout 8000ms exceeded waiting for selector '#btn'",
        )

    def test_different(self):
        assert not is_same_error(
            "Timeout waiting for selector '#btn'",
            "Element is not visible",
        )
