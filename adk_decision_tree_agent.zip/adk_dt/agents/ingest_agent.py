"""
IngestAgent — Loads Excel data into session state for the DecisionTreeAgent.

This is a deterministic agent (no LLM). It reads an Excel file,
converts rows to dicts, and writes them to session state.

State Contract:
  INPUT:
    dt:excel_file      — path to Excel file
    dt:sheet_name      — sheet name (default: "Sheet1")
    dt:row_id_column   — row ID column name (default: "ID")

  OUTPUT:
    dt:rows            — list of row dicts
    dt:row_count       — number of rows loaded
    dt:columns         — list of column names
    dt:ingest_status   — "completed" | "failed"
    dt:ingest_error    — error message if failed
"""

import logging
from typing import Any, AsyncIterator, Optional

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.genai import types

import pandas as pd

logger = logging.getLogger(__name__)


class IngestAgent(BaseAgent):
    """Loads Excel data into session state."""

    excel_file: Optional[str] = None
    sheet_name: str = "Sheet1"
    state_prefix: str = "dt"

    model_config = {"arbitrary_types_allowed": True}

    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncIterator[types.Content]:
        prefix = self.state_prefix

        try:
            file_path = ctx.session.state.get(f"{prefix}:excel_file") or self.excel_file
            sheet = ctx.session.state.get(f"{prefix}:sheet_name") or self.sheet_name

            if not file_path:
                ctx.session.state[f"{prefix}:ingest_status"] = "failed"
                ctx.session.state[f"{prefix}:ingest_error"] = "No excel_file provided"
                yield self._msg("Error: No Excel file path provided.")
                return

            logger.info(f"[{self.name}] Loading: {file_path} | Sheet: {sheet}")

            df = pd.read_excel(file_path, sheet_name=sheet)
            rows = df.to_dict(orient="records")

            ctx.session.state[f"{prefix}:rows"] = rows
            ctx.session.state[f"{prefix}:row_count"] = len(rows)
            ctx.session.state[f"{prefix}:columns"] = list(df.columns)
            ctx.session.state[f"{prefix}:ingest_status"] = "completed"

            logger.info(f"[{self.name}] Loaded {len(rows)} rows, {len(df.columns)} columns")

            yield self._msg(
                f"Loaded {len(rows)} rows from {file_path} "
                f"({len(df.columns)} columns: {', '.join(df.columns[:5])}...)"
            )

        except Exception as e:
            logger.error(f"[{self.name}] Error: {e}", exc_info=True)
            ctx.session.state[f"{prefix}:ingest_status"] = "failed"
            ctx.session.state[f"{prefix}:ingest_error"] = str(e)
            yield self._msg(f"Error loading Excel: {e}")

    @staticmethod
    def _msg(text: str) -> types.Content:
        return types.Content(
            role="model",
            parts=[types.Part.from_text(text=text)],
        )
