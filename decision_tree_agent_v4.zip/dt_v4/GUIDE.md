# Guide: Creating YAML Decision Trees and DAGs

A step-by-step guide for building config-driven validation rules.
No Python knowledge required. Edit YAML, re-run, done.

---

## Table of contents

1. Quick start — your first rule in 60 seconds
2. Conditions — the 16 operators
3. Actions — what happens when a condition fires
4. Nesting — building deep decision trees
5. Compound conditions — AND / OR logic
6. Calculated fields — derived values before evaluation
7. DAG — dependency ordering and parallel sections
8. Patterns — real-world recipes
9. Flowchart-to-YAML conversion
10. Validation checklist

---

## 1. Quick start — your first rule in 60 seconds

Create a file `config/my_rules.yaml`:

```yaml
decision_trees:
  - id: "check_amount"
    name: "Amount exceeds threshold"
    condition:
      operator: "gt"
      left_column: "Amount"
      right_value: 100000
    on_true:
      action: "api_call"
      endpoint: "/flag"
      payload:
        result: "OVER_THRESHOLD"
    on_false:
      action: "db_update"
      set:
        result: "WITHIN_THRESHOLD"
```

Use it in your agent:

```python
from agents.decision_tree_agent import DecisionTreeAgent

agent = DecisionTreeAgent(
    name="AmountChecker",
    config_path="config/my_rules.yaml",
    output_key="amount_result",
)

# Set the row in session state before running:
# ctx.session.state["dt:row"] = {"Amount": 150000, "Currency": "USD"}
```

That's it. The agent reads `dt:row`, evaluates the tree, writes `dt:passed` (True/False)
and `dt:actions` (list of actions to execute) back to state.

---

## 2. Conditions — the 16 operators

Every condition has an `operator` and a `left_column` (the Excel/data column to read).
Some operators need a second operand.

### 2.1 Comparison operators

Compare two values. Works with numbers and strings.

```yaml
# Column vs literal value
condition:
  operator: "gt"          # greater than
  left_column: "BB"
  right_value: 5000

# Column vs another column
condition:
  operator: "lte"         # less than or equal
  left_column: "Debit"
  right_column: "Credit"
```

| Operator | Meaning | Example |
|----------|---------|---------|
| `gt` | Greater than | Amount > 100000 |
| `gte` | Greater than or equal | Score >= 80 |
| `lt` | Less than | Age < 18 |
| `lte` | Less than or equal | Balance <= Credit |
| `eq` | Equal | Status == "Active" |
| `neq` | Not equal | Type != "INVALID" |

**Type handling:** The engine tries numeric comparison first. If either value
isn't a number, it falls back to string comparison automatically. You don't
need to worry about types in the YAML.

**Null handling:** If either side is null/NaN, comparison operators return `false`.
Exception: `eq(null, null)` returns `true`.

### 2.2 String operators

Check text patterns.

```yaml
# Contains substring
condition:
  operator: "contains"
  left_column: "Description"
  right_value: "RESTRICTED"

# Regex match
condition:
  operator: "regex"
  left_column: "TransactionRef"
  pattern: "^TXN-[A-Z]{3}-\\d{6}$"
```

| Operator | Meaning | Extra field |
|----------|---------|------------|
| `contains` | Right is a substring of left | `right_value` |
| `starts_with` | Left starts with right | `right_value` |
| `ends_with` | Left ends with right | `right_value` |
| `regex` | Left matches pattern | `pattern` |
| `is_empty` | Left is null or whitespace | (none) |

### 2.3 Null operators

Check for missing values.

```yaml
condition:
  operator: "is_null"
  left_column: "Email"
```

| Operator | Meaning |
|----------|---------|
| `is_null` | Value is None or NaN |
| `is_not_null` | Value exists and is not NaN |

### 2.4 Range operator

Check if a value falls within a range (inclusive).

```yaml
condition:
  operator: "between"
  left_column: "RiskScore"
  low: 0
  high: 100
```

### 2.5 Set operators

Check membership in a list of values.

```yaml
condition:
  operator: "in"
  left_column: "Country"
  values: ["US", "UK", "CA", "AU", "DE"]

condition:
  operator: "not_in"
  left_column: "ConversionType"
  values: ["LOT_TO_SPEC", "LUD_TO_SPEC", "LOT_TO_MODEL"]
```

### 2.6 Compound operators

Combine multiple conditions with AND / OR. Nest as deep as you need.

```yaml
condition:
  operator: "and"
  conditions:
    - operator: "eq"
      left_column: "Status"
      right_value: "Active"
    - operator: "gt"
      left_column: "Balance"
      right_value: 50000
```

See section 5 for detailed compound examples.

---

## 3. Actions — what happens when a condition fires

Each tree node has `on_true` and `on_false` branches. Each branch has an `action`.

### 3.1 API call

Send data to an external API.

```yaml
on_true:
  action: "api_call"
  method: "POST"                    # POST, PUT, DELETE
  endpoint: "/validations/update"   # appended to settings.api_base_url
  payload:
    validation_id: "val_001"
    result: "Yes"
    message: "BB exceeds BC"
```

### 3.2 Database update

Write key-value pairs to the database.

```yaml
on_false:
  action: "db_update"
  set:
    val_001_result: "No"
    val_001_message: "BB does not exceed BC"
  table: "custom_table"            # optional, defaults to settings.db_table
```

### 3.3 Log exception

This is an `api_call` to the exception endpoint — a convention, not a special action type.
The agent detects exceptions by looking for "exception" in the endpoint or
"exception_id" in the payload.

```yaml
on_true:
  action: "api_call"
  endpoint: "/exceptions/log"
  payload:
    exception_id: 14
    exception_type: "UNEXPECTED_HARD_COST_CHANGE"
    message: "Hard cost changed on non-applicable conversion"
    section: "5. Hard Cost"
```

### 3.4 None (skip/pass-through)

Do nothing on this branch. Useful when a branch only has `next_decision`.

```yaml
on_true:
  action: "none"
  next_decision:           # continue evaluation on this branch
    id: "sub_check"
    ...
```

**Shorthand:** You can omit `on_true` or `on_false` entirely — they default to
`action: "none"`.

```yaml
# These are equivalent:
on_false:
  action: "none"

# (just don't include on_false at all)
```

### 3.5 Log only

Log to stdout without side effects (useful for debugging).

```yaml
on_true:
  action: "log_only"
  set:
    debug_info: "This branch was taken"
```

---

## 4. Nesting — building deep decision trees

Any `on_true` or `on_false` branch can contain a `next_decision` — another
complete decision node. This creates arbitrarily deep trees.

### 4.1 Simple two-level tree

```yaml
decision_trees:
  - id: "amount_check"
    name: "Amount classification"
    condition:
      operator: "gte"
      left_column: "Amount"
      right_value: 100000
    on_true:
      action: "api_call"
      endpoint: "/flag"
      payload:
        tier: "HIGH"
      next_decision:                      # ← second level
        id: "currency_check"
        name: "Currency sub-check"
        condition:
          operator: "eq"
          left_column: "Currency"
          right_value: "USD"
        on_true:
          action: "api_call"
          endpoint: "/flag"
          payload:
            sub_tier: "HIGH_USD"
        on_false:
          action: "db_update"
          set:
            sub_tier: "HIGH_NON_USD"
    on_false:
      action: "db_update"
      set:
        tier: "LOW"
```

**How it executes:**
```
Amount >= 100000?
├─ YES → flag HIGH
│        └─ Currency == USD?
│           ├─ YES → flag HIGH_USD
│           └─ NO  → set HIGH_NON_USD
└─ NO  → set LOW
```

### 4.2 Deep validation chain (3+ levels)

A common compliance pattern — each check gates the next.

```yaml
  - id: "plan_appraisal_hardcost"
    name: "Plan → Appraisal → Hard Cost validation"
    condition:
      operator: "eq"
      left_column: "PlanNameExistsInLAM"
      right_value: "Yes"
    on_true:
      next_decision:
        id: "appraisal_match"
        name: "Appraisal value matched"
        condition:
          operator: "eq"
          left_column: "AppraisalValueMatched"
          right_value: "Yes"
        on_true:
          next_decision:
            id: "hard_cost"
            name: "BDR has hard cost"
            condition:
              operator: "eq"
              left_column: "CustomerBDRHasHardCost"
              right_value: "Yes"
            on_true:
              action: "api_call"
              endpoint: "/lam/update"
              payload:
                fields: ["CollateralType", "ConversionDate", "HardCost"]
            on_false:
              action: "api_call"
              endpoint: "/exceptions/log"
              payload:
                exception_id: 7
                exception_type: "NO_HARD_COST"
        on_false:
          action: "api_call"
          endpoint: "/exceptions/log"
          payload:
            exception_id: 6
            exception_type: "APPRAISAL_MISMATCH"
    on_false:
      action: "api_call"
      endpoint: "/exceptions/log"
      payload:
        exception_id: 5
        exception_type: "PLAN_NAME_MISSING"
```

**Decision path:**
```
Plan exists?
├─ YES → Appraisal matched?
│        ├─ YES → BDR has hard cost?
│        │        ├─ YES → Update LAM (3 fields)
│        │        └─ NO  → Exception 7
│        └─ NO  → Exception 6
└─ NO  → Exception 5
```

---

## 5. Compound conditions — AND / OR logic

### 5.1 AND — all must be true

```yaml
condition:
  operator: "and"
  conditions:
    - operator: "eq"
      left_column: "Status"
      right_value: "Active"
    - operator: "gt"
      left_column: "Balance"
      right_value: 50000
    - operator: "is_not_null"
      left_column: "Email"
```

### 5.2 OR — at least one true

```yaml
condition:
  operator: "or"
  conditions:
    - operator: "gt"
      left_column: "Amount"
      right_value: 500000
    - operator: "eq"
      left_column: "FlagStatus"
      right_value: "SUSPICIOUS"
```

### 5.3 Nested AND + OR

"Active AND balance > 50k AND (US or EU region)"

```yaml
condition:
  operator: "and"
  conditions:
    - operator: "eq"
      left_column: "Status"
      right_value: "Active"
    - operator: "gt"
      left_column: "Balance"
      right_value: 50000
    - operator: "or"
      conditions:
        - operator: "eq"
          left_column: "Region"
          right_value: "US"
        - operator: "eq"
          left_column: "Region"
          right_value: "EU"
```

### 5.4 Guard pattern — "NOT these types AND something changed"

Common in compliance: "If conversion is NOT one of these types, and a field
changed, log an exception."

```yaml
condition:
  operator: "and"
  conditions:
    - operator: "not_in"
      left_column: "ConversionType"
      values: ["LOT_TO_SPEC", "LUD_TO_SPEC", "LOT_TO_MODEL", "LUD_TO_MODEL"]
    - operator: "eq"
      left_column: "HardCostChange"
      right_value: "Yes"
on_true:
  action: "api_call"
  endpoint: "/exceptions/log"
  payload:
    exception_id: 14
    exception_type: "UNEXPECTED_HARD_COST_CHANGE"
```

---

## 6. Calculated fields — derived values before evaluation

Computed BEFORE tree evaluation. Later trees can reference these values.
Uses safe operators — no eval(), no Python expressions.

### 6.1 Available operators

| Operator | Description | Required fields |
|----------|-------------|----------------|
| `add` | left + right | `left_column`, `right_column` or `right_value` |
| `subtract` | left - right | same |
| `multiply` | left × right | same |
| `divide` | left ÷ right (null if right=0) | same |
| `percent` | (left ÷ right) × 100 | same |
| `coalesce` | First non-null from column list | `columns` (list) |
| `concat` | Join column values with separator | `columns`, `format` (separator) |
| `lookup` | Copy a column value | `left_column` |
| `constant` | Fixed value | `value` |

### 6.2 Examples

```yaml
calculated_fields:
  # Total = Hard Cost + Lot Cost
  - output_key: "total_cost"
    operator: "add"
    left_column: "HardCost"
    right_column: "LotCost"

  # Margin % = (Revenue - Cost) / Revenue × 100
  - output_key: "net_amount"
    operator: "subtract"
    left_column: "Revenue"
    right_column: "Cost"

  - output_key: "margin_pct"
    operator: "percent"
    left_column: "net_amount"         # references the field computed above
    right_column: "Revenue"

  # Use the first available phone number
  - output_key: "contact_phone"
    operator: "coalesce"
    columns: ["MobilePhone", "WorkPhone", "HomePhone"]

  # Build a full name
  - output_key: "full_name"
    operator: "concat"
    columns: ["FirstName", "LastName"]
    format: " "                       # separator

  # Fixed threshold
  - output_key: "max_allowed"
    operator: "constant"
    value: 500000

decision_trees:
  # Now trees can reference total_cost, margin_pct, etc.
  - id: "margin_check"
    name: "Low margin warning"
    condition:
      operator: "lt"
      left_column: "margin_pct"       # uses computed field
      right_value: 15
    on_true:
      action: "api_call"
      endpoint: "/alerts/low-margin"
      payload:
        alert: "Margin below 15%"
    on_false:
      action: "none"
```

### 6.3 Chaining computed fields

Fields are computed in order. Later fields can reference earlier ones:

```yaml
calculated_fields:
  - output_key: "subtotal"
    operator: "add"
    left_column: "Price"
    right_column: "Shipping"

  - output_key: "tax"
    operator: "multiply"
    left_column: "subtotal"        # uses subtotal computed above
    right_value: 0.08

  - output_key: "grand_total"
    operator: "add"
    left_column: "subtotal"        # uses subtotal
    right_column: "tax"            # uses tax computed above
```

---

## 7. DAG — dependency ordering and parallel sections

When your validations have independent sections AND sections that depend on
others, use a DAG. The engine auto-detects DAG mode when the `dag` key exists.

### 7.1 When to use DAG

Use DAG when:
- Some sections must run BEFORE others (e.g., conversion type must be
  determined before checking hard cost changes)
- Some sections are fully independent (e.g., borrowing base checks have
  no dependency on conversion checks)
- You want the execution plan to be explicit and auditable

Don't use DAG when:
- All trees are independent (flat mode works fine)
- Trees have no meaningful dependency order

### 7.2 DAG structure

```yaml
dag:
  nodes:
    - id: "percentage"                   # DAG node ID
      tree_id: "sec2_percentage"         # single tree to execute
      depends_on: []                     # no dependencies → Layer 0

    - id: "conversion"
      tree_ids:                          # multiple trees in one DAG node
        - "sec3_logical_progression"
        - "sec3_spec_to_model"
        - "sec3_land_in_lud"
      depends_on: []                     # Layer 0 (parallel with percentage)

    - id: "hard_cost"
      tree_id: "sec5_hard_cost"
      depends_on: ["conversion"]         # Layer 1 (runs after conversion)

    - id: "borrowing_base"
      tree_id: "sec9_borrowing_base"
      depends_on: []                     # Layer 0 (independent)

  on_dependency_failure: "skip"          # skip | continue | abort
```

**Resulting execution plan:**
```
Layer 0 (parallel): percentage, conversion, borrowing_base
    ↓
Layer 1 (parallel): hard_cost
```

### 7.3 Dependency failure modes

| Mode | Behavior |
|------|----------|
| `skip` | If a dependency fails, skip this node. Propagates to dependents. |
| `continue` | Run this node even if a dependency failed. |
| `abort` | Stop processing this row entirely. |

### 7.4 Single vs multiple trees per DAG node

```yaml
# Single tree — use tree_id:
- id: "simple_check"
  tree_id: "check_amount"
  depends_on: []

# Multiple trees — use tree_ids (all execute sequentially within the node):
- id: "conversion_section"
  tree_ids:
    - "check_type_a"
    - "check_type_b"
    - "check_type_c"
  depends_on: []
```

### 7.5 Complete DAG example

```yaml
calculated_fields:
  - output_key: "total_cost"
    operator: "add"
    left_column: "HardCost"
    right_column: "LotCost"

decision_trees:
  - id: "percentage_update"
    name: "Percentage change check"
    condition:
      operator: "eq"
      left_column: "PercentageChanged"
      right_value: "Yes"
    on_true:
      action: "api_call"
      endpoint: "/exceptions/log"
      payload:
        exception_id: 1
        exception_type: "PCT_CHANGED"
    on_false:
      action: "none"

  - id: "conversion_type"
    name: "Conversion type validation"
    condition:
      operator: "in"
      left_column: "ConversionType"
      values: ["SPEC_TO_PRESOLD", "MODEL_TO_PRESOLD"]
    on_true:
      action: "api_call"
      endpoint: "/lam/update"
      payload:
        fields: ["CollateralType", "ContractPrice"]
    on_false:
      action: "none"

  - id: "hard_cost_guard"
    name: "Hard cost change guard"
    condition:
      operator: "and"
      conditions:
        - operator: "not_in"
          left_column: "ConversionType"
          values: ["LOT_TO_SPEC", "LUD_TO_SPEC"]
        - operator: "eq"
          left_column: "HardCostChanged"
          right_value: "Yes"
    on_true:
      action: "api_call"
      endpoint: "/exceptions/log"
      payload:
        exception_id: 14
        exception_type: "HARD_COST_GUARD"
    on_false:
      action: "db_update"
      set:
        hard_cost_status: "OK"

  - id: "total_cost_check"
    name: "Total cost exceeds limit"
    condition:
      operator: "gt"
      left_column: "total_cost"       # uses calculated field
      right_value: 1000000
    on_true:
      action: "api_call"
      endpoint: "/exceptions/log"
      payload:
        exception_id: 20
        exception_type: "TOTAL_COST_EXCEEDED"
    on_false:
      action: "none"

dag:
  nodes:
    - id: "sec_pct"
      tree_id: "percentage_update"
      depends_on: []

    - id: "sec_conv"
      tree_id: "conversion_type"
      depends_on: []

    - id: "sec_hard"
      tree_id: "hard_cost_guard"
      depends_on: ["sec_conv"]        # needs conversion result first

    - id: "sec_total"
      tree_id: "total_cost_check"
      depends_on: []                  # independent

  on_dependency_failure: "skip"
```

---

## 8. Patterns — real-world recipes

### 8.1 Simple flag check

"If X is true, flag it."

```yaml
  - id: "lot_cost_change"
    name: "Lot cost changed"
    condition:
      operator: "eq"
      left_column: "LotCostChanged"
      right_value: "Yes"
    on_true:
      action: "api_call"
      endpoint: "/exceptions/log"
      payload:
        exception_id: 15
        exception_type: "LOT_COST_CHANGE"
    on_false:
      action: "db_update"
      set:
        lot_cost_status: "OK"
```

### 8.2 Type-based routing

"Route to different actions based on conversion type."

```yaml
  - id: "spec_to_presold"
    name: "SPEC or MODEL to PRESOLD"
    condition:
      operator: "and"
      conditions:
        - operator: "in"
          left_column: "FromType"
          values: ["SPEC", "MODEL"]
        - operator: "eq"
          left_column: "ToType"
          right_value: "PRESOLD"
    on_true:
      action: "api_call"
      endpoint: "/lam/update"
      payload:
        fields: ["CollateralType", "ContractPrice"]
```

### 8.3 Gated validation chain

"Check A, then B, then C — each must pass before checking the next."

```yaml
  - id: "gated_chain"
    name: "Appraisal → Plan → Hard Cost gate"
    condition:
      operator: "eq"
      left_column: "AppraisalAvailable"
      right_value: "Yes"
    on_true:
      next_decision:
        id: "plan_check"
        name: "Plan in LAM"
        condition:
          operator: "eq"
          left_column: "PlanNameInLAM"
          right_value: "Yes"
        on_true:
          next_decision:
            id: "hard_cost_check"
            name: "Hard cost available"
            condition:
              operator: "eq"
              left_column: "HasHardCost"
              right_value: "Yes"
            on_true:
              action: "api_call"
              endpoint: "/lam/update"
              payload:
                fields: ["CollateralType", "HardCost"]
            on_false:
              action: "api_call"
              endpoint: "/exceptions/log"
              payload:
                exception_id: 7
        on_false:
          action: "api_call"
          endpoint: "/exceptions/log"
          payload:
            exception_id: 5
    on_false:
      action: "api_call"
      endpoint: "/exceptions/log"
      payload:
        exception_id: 8
```

### 8.4 Guard pattern — "not these types, then check"

```yaml
  - id: "appraisal_guard"
    name: "Appraisal change guard"
    condition:
      operator: "and"
      conditions:
        - operator: "not_in"
          left_column: "ConversionType"
          values:
            - "LAND_TO_LUD"
            - "LUD_TO_LOT"
            - "LOT_TO_SPEC"
            - "LOT_TO_PRESOLD"
        - operator: "eq"
          left_column: "AppraisalChanged"
          right_value: "Yes"
    on_true:
      action: "api_call"
      endpoint: "/exceptions/log"
      payload:
        exception_id: 17
```

### 8.5 Two-tier classification with nesting

```yaml
  - id: "risk_tier"
    name: "Risk classification"
    condition:
      operator: "gte"
      left_column: "RiskScore"
      right_value: 80
    on_true:
      action: "api_call"
      endpoint: "/risk/flag"
      payload:
        tier: "CRITICAL"
      next_decision:
        id: "critical_auto_block"
        name: "Auto-block if score > 95"
        condition:
          operator: "gt"
          left_column: "RiskScore"
          right_value: 95
        on_true:
          action: "api_call"
          endpoint: "/risk/block"
          payload:
            auto_blocked: true
        on_false:
          action: "api_call"
          endpoint: "/risk/review"
          payload:
            needs_review: true
    on_false:
      action: "db_update"
      set:
        risk_tier: "NORMAL"
```

---

## 9. Flowchart-to-YAML conversion

### 9.1 Element mapping

| Flowchart shape | YAML equivalent |
|----------------|----------------|
| Diamond (decision) | `condition:` block with `operator` |
| Rectangle (action) | `action: "api_call"` or `action: "db_update"` |
| Arrow labeled YES | `on_true:` branch |
| Arrow labeled NO | `on_false:` branch |
| Exception box | `endpoint: "/exceptions/log"` with `exception_id` |
| Update box | `endpoint: "/lam/update"` with `fields` |
| Sequential diamonds | Nested `next_decision` |
| Independent sections | Separate DAG `nodes` |

### 9.2 Process

1. **Number each diamond** in the flowchart. Each gets an `id`.
2. **Trace YES path** from each diamond. What it reaches becomes `on_true`.
3. **Trace NO path.** What it reaches becomes `on_false`.
4. **If YES/NO leads to another diamond,** use `next_decision`.
5. **If YES/NO leads to a rectangle,** use an `action`.
6. **Identify sections** that can run independently → DAG nodes.

### 9.3 Example: chain of NO-pass-through diamonds

Flowchart:
```
LAND→LUD? → NO → LUD→LOT? → NO → LOT→SPEC? → NO → Changed? → YES → Exception
```

This is a guard pattern. Collapse into one compound condition:

```yaml
condition:
  operator: "and"
  conditions:
    - operator: "not_in"
      left_column: "ConversionType"
      values: ["LAND_TO_LUD", "LUD_TO_LOT", "LOT_TO_SPEC"]
    - operator: "eq"
      left_column: "ValueChanged"
      right_value: "Yes"
```

### 9.4 Example: chain of YES-gated diamonds

Flowchart:
```
Plan exists? → YES → Appraisal matched? → YES → Has cost? → YES → Update
```

This is a gated chain. Use nested `next_decision`:

```yaml
condition:
  operator: "eq"
  left_column: "PlanExists"
  right_value: "Yes"
on_true:
  next_decision:
    id: "appraisal"
    condition:
      operator: "eq"
      left_column: "AppraisalMatched"
      right_value: "Yes"
    on_true:
      next_decision:
        id: "cost"
        condition:
          operator: "eq"
          left_column: "HasCost"
          right_value: "Yes"
        on_true:
          action: "api_call"
          endpoint: "/update"
```

---

## 10. Validation checklist

Before deploying a new YAML config, verify:

**Structure:**
- [ ] Every tree has a unique `id`
- [ ] Every tree has a `name`
- [ ] Every tree has a `condition` with an `operator`
- [ ] Every condition has `left_column`
- [ ] Comparison operators have `right_column` or `right_value`
- [ ] `regex` has `pattern`
- [ ] `between` has `low` and `high`
- [ ] `in` / `not_in` have `values` (non-empty list)

**Actions:**
- [ ] `api_call` has `endpoint`
- [ ] Exception actions have `exception_id` in `payload`
- [ ] `db_update` has `set` (non-empty dict)

**Nesting:**
- [ ] Every `next_decision` is a complete tree node (has `id`, `name`, `condition`)
- [ ] Every NO path that should log an exception has the correct `exception_id`

**DAG (if used):**
- [ ] Every `depends_on` reference points to an existing DAG node `id`
- [ ] Every `tree_id` / `tree_ids` reference points to an existing `decision_trees` entry
- [ ] No circular dependencies
- [ ] `on_dependency_failure` is set (`skip`, `continue`, or `abort`)

**Calculated fields (if used):**
- [ ] Fields are ordered correctly (earlier fields computed before later ones that reference them)
- [ ] `output_key` names don't collide with existing column names
- [ ] `divide` / `percent` won't divide by zero (or if they might, the null result is handled)

**Testing:**
- [ ] At least one test row that follows the happy path (all validations pass)
- [ ] At least one test row that triggers each exception
- [ ] At least one test row with null values in key columns
- [ ] Run with `--dry-run` first to verify decision paths without side effects
