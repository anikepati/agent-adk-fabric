"""
Error Classifier — categorizes Playwright errors and determines recovery action.

Three-tier classification:
  RETRY   — transient error, run same script again (no LLM)
  REPLAN  — recoverable error, LLM rewrites script
  ABORT   — terminal error, stop immediately
"""

from __future__ import annotations

import re
from core.models import ErrorAction, ErrorCategory


# ═══════════════════════════════════════════════════════════════
# Error pattern matching
# ═══════════════════════════════════════════════════════════════

# Terminal errors — abort immediately, no recovery possible
_TERMINAL_PATTERNS = [
    (r"net::ERR_NAME_NOT_RESOLVED", ErrorCategory.NAVIGATION_ERROR),
    (r"net::ERR_CONNECTION_REFUSED", ErrorCategory.SERVER_ERROR),
    (r"net::ERR_CERT_", ErrorCategory.NAVIGATION_ERROR),
    (r"\b403\b\s*(Forbidden)?", ErrorCategory.AUTH_FAILURE),
    (r"\b401\b\s*(Unauthorized)?", ErrorCategory.AUTH_FAILURE),
    (r"Access\s+denied", ErrorCategory.AUTH_FAILURE),
    (r"\b404\b\s*(Not\s*Found)?", ErrorCategory.SERVER_ERROR),
    (r"\b500\b\s*(Internal\s*Server\s*Error)?", ErrorCategory.SERVER_ERROR),
    (r"\b502\b\s*(Bad\s*Gateway)?", ErrorCategory.SERVER_ERROR),
    (r"\b503\b\s*(Service\s*Unavailable)?", ErrorCategory.SERVER_ERROR),
    (r"Browser\s*(has\s+been\s+)?closed", ErrorCategory.BROWSER_ERROR),
    (r"Target\s+closed", ErrorCategory.BROWSER_ERROR),
    (r"Execution\s+context\s+was\s+destroyed", ErrorCategory.BROWSER_ERROR),
    (r"Protocol\s+error", ErrorCategory.BROWSER_ERROR),
]

# Transient errors — auto-retry with same script (1 retry before replan)
_TRANSIENT_PATTERNS = [
    (r"net::ERR_NETWORK_CHANGED", ErrorCategory.TRANSIENT),
    (r"net::ERR_CONNECTION_RESET", ErrorCategory.TRANSIENT),
    (r"net::ERR_TIMED_OUT", ErrorCategory.TRANSIENT),
    (r"net::ERR_INTERNET_DISCONNECTED", ErrorCategory.TRANSIENT),
    (r"Page\s+crashed", ErrorCategory.TRANSIENT),
    (r"Navigation\s+interrupted", ErrorCategory.TRANSIENT),
]

# Recoverable errors — send to Replanner for script rewrite
_RECOVERABLE_PATTERNS = [
    (r"waiting\s+for\s+selector", ErrorCategory.SELECTOR_NOT_FOUND),
    (r"No\s+element.*matches\s+selector", ErrorCategory.SELECTOR_NOT_FOUND),
    (r"Element\s+is\s+not\s+visible", ErrorCategory.ELEMENT_NOT_INTERACTABLE),
    (r"Element\s+is\s+not\s+attached", ErrorCategory.ELEMENT_NOT_INTERACTABLE),
    (r"Element\s+is\s+outside\s+of\s+the\s+viewport", ErrorCategory.ELEMENT_NOT_INTERACTABLE),
    (r"Element\s+is\s+not\s+enabled", ErrorCategory.ELEMENT_NOT_INTERACTABLE),
    (r"intercepts\s+pointer\s+events", ErrorCategory.UNEXPECTED_DIALOG),
    (r"Timeout\s+\d+ms\s+exceeded", ErrorCategory.TIMEOUT),
    (r"frame\s+was\s+detached", ErrorCategory.PAGE_STRUCTURE_CHANGED),
    (r"Navigating\s+frame\s+was\s+detached", ErrorCategory.PAGE_STRUCTURE_CHANGED),
]

# Compile patterns once
_COMPILED_TERMINAL = [(re.compile(p, re.IGNORECASE), c) for p, c in _TERMINAL_PATTERNS]
_COMPILED_TRANSIENT = [(re.compile(p, re.IGNORECASE), c) for p, c in _TRANSIENT_PATTERNS]
_COMPILED_RECOVERABLE = [(re.compile(p, re.IGNORECASE), c) for p, c in _RECOVERABLE_PATTERNS]


def classify_error(
    error_message: str,
    error_type: str = "",
    page_url: str = "",
) -> tuple[ErrorCategory, ErrorAction]:
    """
    Classify a Playwright error and determine recovery action.

    Args:
        error_message: The error message string
        error_type: Python exception type name (e.g., "TimeoutError")
        page_url: Current page URL for context

    Returns:
        Tuple of (ErrorCategory, ErrorAction)
    """
    combined = f"{error_type}: {error_message}"

    # Check terminal patterns first
    for pattern, category in _COMPILED_TERMINAL:
        if pattern.search(combined):
            return category, ErrorAction.ABORT

    # Check transient patterns
    for pattern, category in _COMPILED_TRANSIENT:
        if pattern.search(combined):
            return category, ErrorAction.RETRY

    # Check recoverable patterns
    for pattern, category in _COMPILED_RECOVERABLE:
        if pattern.search(combined):
            return category, ErrorAction.REPLAN

    # Error type fallbacks
    if error_type in ("TimeoutError", "PlaywrightTimeoutError"):
        return ErrorCategory.TIMEOUT, ErrorAction.REPLAN

    if error_type == "NavigationError":
        return ErrorCategory.NAVIGATION_ERROR, ErrorAction.ABORT

    # Default: assume recoverable — let Replanner decide
    return ErrorCategory.UNKNOWN, ErrorAction.REPLAN


def is_same_error(prev_error: str, curr_error: str) -> bool:
    """
    Check if two errors are essentially the same failure.
    Used to detect when Replanner isn't making progress.
    """
    # Normalize: strip line numbers, timestamps, memory addresses
    def normalize(s: str) -> str:
        s = re.sub(r"\d+", "N", s)
        s = re.sub(r"0x[a-fA-F0-9]+", "ADDR", s)
        s = re.sub(r"\s+", " ", s).strip().lower()
        return s

    return normalize(prev_error) == normalize(curr_error)
