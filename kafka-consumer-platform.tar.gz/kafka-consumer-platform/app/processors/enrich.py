"""
Enrich processor: call an enrichment API and merge response into message.
"""
from __future__ import annotations

import json
from typing import Any

import httpx

from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult
from app.processors.base import BaseProcessor, ProcessorContext
from app.processors.registry import register_processor


@register_processor("enrich")
class EnrichProcessor(BaseProcessor):

    def __init__(self, config: dict[str, Any], context: ProcessorContext) -> None:
        super().__init__(config, context)
        self._url: str = config["url"]
        self._merge_key: str | None = config.get("merge_key")
        self._method: str = config.get("method", "POST")
        self._timeout: float = config.get("timeout_s", 15.0)
        self._client: httpx.AsyncClient | None = None

    async def startup(self) -> None:
        self._client = httpx.AsyncClient(timeout=httpx.Timeout(self._timeout))

    async def process(self, message: ConsumerMessage) -> ProcessorResult:
        if self._client is None:
            await self.startup()

        try:
            data = message.value
            if not isinstance(data, dict):
                return ProcessorResult.dlq("Expected dict payload for enrichment")

            # Build request with optional key-based lookup
            params = {}
            if self._merge_key and self._merge_key in data:
                params["key"] = str(data[self._merge_key])

            response = await self._client.request(
                method=self._method,
                url=self._url,
                content=json.dumps(data),
                headers={"Content-Type": "application/json"},
                params=params,
            )

            if response.status_code >= 500:
                return ProcessorResult.retry(f"Enrichment API returned {response.status_code}")

            if response.status_code >= 400:
                return ProcessorResult.dlq(f"Enrichment API error: {response.status_code}")

            enrichment_data = response.json()
            if isinstance(enrichment_data, dict):
                data.update(enrichment_data)
                message.value = data

            return ProcessorResult.success()

        except httpx.TimeoutException as e:
            return ProcessorResult.retry(f"Enrichment timeout: {e}", e)
        except Exception as e:
            return ProcessorResult.retry(f"Enrichment error: {e}", e)

    async def shutdown(self) -> None:
        if self._client:
            await self._client.aclose()
