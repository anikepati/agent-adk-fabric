"""Tree walker v4 — recursive walk, audit trail, action collection."""

from typing import Any, Dict, List
from models.schemas import DecisionNode, ActionBranch
from engine.evaluator import evaluate

RowData = Dict[str, Any]


def walk_tree(node: DecisionNode, row: RowData, depth: int = 0) -> Dict[str, Any]:
    """Walk one tree recursively. Returns full decision path."""
    result = evaluate(node.condition, row)
    branch: ActionBranch = node.on_true if result else node.on_false
    label = "on_true" if result else "on_false"

    action_out = {"action": branch.action}
    if branch.endpoint:   action_out["endpoint"] = branch.endpoint
    if branch.method and branch.action == "api_call": action_out["method"] = branch.method
    if branch.payload:    action_out["payload"] = branch.payload
    if branch.set:        action_out["set"] = branch.set

    record = {
        "node_id": node.id,
        "node_name": node.name,
        "result": result,
        "branch": label,
        "action": action_out,
        "children": [],
    }

    if branch.next_decision:
        record["children"].append(walk_tree(branch.next_decision, row, depth + 1))

    return record


def walk_all(trees: List[DecisionNode], row: RowData) -> List[Dict]:
    """Walk all trees for a single row."""
    return [walk_tree(t, row) for t in trees]


def collect_actions(tree_result: Dict) -> List[Dict]:
    """Flatten tree result into a list of non-none actions."""
    actions = []
    if tree_result["action"]["action"] != "none":
        actions.append({
            "node_id": tree_result["node_id"],
            "node_name": tree_result["node_name"],
            "result": tree_result["result"],
            "branch": tree_result["branch"],
            **tree_result["action"],
        })
    for child in tree_result.get("children", []):
        actions.extend(collect_actions(child))
    return actions
