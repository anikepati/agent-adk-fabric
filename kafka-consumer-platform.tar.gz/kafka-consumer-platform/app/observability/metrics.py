"""
Prometheus metrics for Kafka consumer platform.
"""
from __future__ import annotations

from prometheus_client import Counter, Gauge, Histogram, Info

# ─── Message processing ───
MESSAGES_TOTAL = Counter(
    "kafka_messages_total",
    "Total messages processed",
    ["cluster", "topic", "status"],
)

HANDLER_DURATION = Histogram(
    "kafka_handler_duration_seconds",
    "Handler execution duration",
    ["cluster", "topic", "processor"],
    buckets=(0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0, 60.0),
)

# ─── Consumer health ───
CONSUMER_LAG = Gauge(
    "kafka_consumer_lag",
    "Consumer lag per partition",
    ["cluster", "group_id", "topic", "partition"],
)

IN_FLIGHT_MESSAGES = Gauge(
    "kafka_in_flight_messages",
    "Number of messages currently being processed",
    ["cluster"],
)

WORKER_POOL_UTILIZATION = Gauge(
    "kafka_worker_pool_utilization",
    "Worker pool utilization (0.0 to 1.0)",
)

# ─── Resilience ───
CIRCUIT_BREAKER_STATE = Gauge(
    "kafka_circuit_breaker_state",
    "Circuit breaker state (0=closed, 1=open, 2=half_open)",
    ["topic", "processor"],
)

DLQ_MESSAGES_TOTAL = Counter(
    "kafka_dlq_messages_total",
    "Total messages sent to DLQ",
    ["cluster", "topic"],
)

RETRY_TOTAL = Counter(
    "kafka_retry_total",
    "Total retry attempts",
    ["cluster", "topic", "attempt"],
)

DESERIALIZATION_ERRORS = Counter(
    "kafka_deserialization_errors_total",
    "Total deserialization errors (poison pills)",
    ["cluster", "topic"],
)

# ─── Consumer internals ───
POLL_DURATION = Histogram(
    "kafka_consumer_poll_duration_seconds",
    "Time spent in consumer.poll()",
    ["cluster"],
    buckets=(0.001, 0.01, 0.05, 0.1, 0.5, 1.0, 2.0),
)

REBALANCE_TOTAL = Counter(
    "kafka_rebalance_total",
    "Total consumer group rebalances",
    ["cluster", "type"],  # type: assign | revoke
)

# ─── Leader ───
IS_LEADER = Gauge(
    "kafka_consumer_is_leader",
    "Whether this pod is the leader (1=leader, 0=worker)",
)

# ─── App info ───
APP_INFO = Info(
    "kafka_consumer_platform",
    "Application build information",
)


def record_message(cluster: str, topic: str, status: str, duration: float, processor: str) -> None:
    """Record a processed message with all relevant metrics."""
    MESSAGES_TOTAL.labels(cluster=cluster, topic=topic, status=status).inc()
    HANDLER_DURATION.labels(cluster=cluster, topic=topic, processor=processor).observe(duration)


def record_dlq(cluster: str, topic: str) -> None:
    DLQ_MESSAGES_TOTAL.labels(cluster=cluster, topic=topic).inc()


def record_retry(cluster: str, topic: str, attempt: int) -> None:
    RETRY_TOTAL.labels(cluster=cluster, topic=topic, attempt=str(attempt)).inc()


def record_deserialization_error(cluster: str, topic: str) -> None:
    DESERIALIZATION_ERRORS.labels(cluster=cluster, topic=topic).inc()
