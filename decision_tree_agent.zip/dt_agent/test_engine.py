"""
Test runner — validates the decision tree engine works correctly.
Runs without google-adk installed (tests the core engine only).

Usage:
    python test_engine.py
"""

import yaml
import json
from models.schemas import DecisionTreeConfig
from engine.walker import walk_all, collect_actions


def test():
    # Load config
    with open("config/rules.yaml") as f:
        raw = yaml.safe_load(f)
    config = DecisionTreeConfig(**raw)
    print(f"Config loaded: {len(config.decision_trees)} trees\n")

    # Test rows
    rows = [
        {
            "ID": "ROW-001",
            "BB": 5000, "BC": 3000,           # BB > BC → true
            "Amount": 150000,                   # >= 100k → HIGH
            "Currency": "USD",                  # → HIGH_USD
            "Email": "user@test.com",           # not null → OK
            "Status": "Active", "Balance": 80000,  # active + >50k → HIGH priority
            "Country": "US",                    # in approved list
        },
        {
            "ID": "ROW-002",
            "BB": 1000, "BC": 9000,            # BB < BC → false
            "Amount": 500,                      # < 100k → LOW
            "Currency": "EUR",
            "Email": None,                      # null → MISSING_EMAIL exception
            "Status": "Inactive", "Balance": 20000,
            "Country": "BR",                    # not in approved → UNAPPROVED exception
        },
        {
            "ID": "ROW-003",
            "BB": 7000, "BC": 7000,            # equal → false (gt, not gte)
            "Amount": 100000,                   # exactly 100k → HIGH (gte)
            "Currency": "JPY",                  # non-USD → HIGH_NON_USD
            "Email": "test@example.com",
            "Status": "Active", "Balance": 30000,  # active but balance < 50k → false
            "Country": "DE",                    # approved
        },
    ]

    for row in rows:
        row_id = row["ID"]
        print(f"{'═' * 60}")
        print(f"ROW: {row_id}")
        print(f"{'═' * 60}")

        # Walk all trees
        decisions = walk_all(config.decision_trees, row)

        # Flatten actions
        all_actions = collect_actions_from_all(decisions)

        # Extract exceptions
        exceptions = [
            a for a in all_actions
            if "exception" in str(a.get("endpoint", "")).lower()
            or "exception_id" in (a.get("payload") or {})
        ]

        passed = len(exceptions) == 0

        # Print decisions
        for d in decisions:
            print_tree(d, indent=2)

        # Print summary
        print(f"\n  Actions: {len(all_actions)}")
        print(f"  Exceptions: {len(exceptions)}")
        print(f"  Passed: {'✓ YES' if passed else '✗ NO'}")

        if exceptions:
            for e in exceptions:
                pid = e.get("payload", {}).get("exception_id", "?")
                ptype = e.get("payload", {}).get("exception_type", "?")
                print(f"    → Exception {pid}: {ptype}")

        # Print state output (what the agent would write)
        print(f"\n  State output:")
        print(f"    dt:passed     = {passed}")
        print(f"    dt:actions    = [{len(all_actions)} items]")
        print(f"    dt:exceptions = [{len(exceptions)} items]")
        print()


def collect_actions_from_all(decisions):
    """Collect all actions from all tree results."""
    all_actions = []
    for d in decisions:
        all_actions.extend(collect_actions(d))
    return all_actions


def print_tree(node, indent=0):
    """Pretty-print a decision tree result."""
    prefix = " " * indent
    result_icon = "✓" if node["result"] else "✗"
    action = node["action"]["action"]
    action_detail = ""

    if action == "api_call":
        endpoint = node["action"].get("endpoint", "")
        action_detail = f" → {endpoint}"
        payload = node["action"].get("payload", {})
        if "exception_id" in payload:
            action_detail += f" [Exception {payload['exception_id']}]"
    elif action == "db_update":
        set_vals = node["action"].get("set", {})
        action_detail = f" → SET {set_vals}"
    elif action == "none":
        action_detail = " → (pass-through)"

    print(f"{prefix}{result_icon} [{node['node_id']}] {node['node_name']} "
          f"→ {node['branch']}: {action}{action_detail}")

    for child in node.get("children", []):
        print_tree(child, indent + 4)


if __name__ == "__main__":
    test()
