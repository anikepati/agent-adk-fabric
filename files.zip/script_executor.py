"""
Script Executor — runs complete Playwright scripts deterministically.

Key properties:
- Zero LLM involvement
- Sandboxed execution via explicit method dispatch (no eval/exec)
- Line-by-line progress tracking
- Rich error context capture on failure
- Post-execution validation
"""

from __future__ import annotations

import ast
import asyncio
import time
import logging
import re
from pathlib import Path
from typing import Optional

from playwright.async_api import Page

from core.models import (
    ExecutionResult,
    ErrorContext,
    ErrorCategory,
    PageState,
    ElementInfo,
    ValidationRule,
    ValidationResult,
    ValidationType,
    ExecutionConfig,
)
from core.error_classifier import classify_error

logger = logging.getLogger("core.executor")

# ═══════════════════════════════════════════════════════════════
# Script line parser
# ═══════════════════════════════════════════════════════════════

# Match:  page.method("arg1", "arg2", key="val")
_LINE_RE = re.compile(
    r'^page\.(\w+)\((.*)?\)\s*$',
    re.DOTALL,
)

# Allowed Playwright Page methods (whitelist for security)
_ALLOWED_METHODS = frozenset({
    # Navigation
    "goto", "go_back", "go_forward", "reload",
    # Actions
    "click", "dblclick", "fill", "type", "press",
    "check", "uncheck", "select_option", "set_input_files",
    "hover", "focus", "tap", "drag_and_drop",
    # Keyboard / mouse
    "keyboard",
    # Waiting
    "wait_for_selector", "wait_for_load_state",
    "wait_for_url", "wait_for_timeout", "wait_for_event",
    # Evaluation (read-only DOM queries only)
    "evaluate", "query_selector", "query_selector_all",
    "input_value", "text_content", "inner_text", "inner_html",
    "is_visible", "is_enabled", "is_checked",
    # Screenshots (diagnostic)
    "screenshot",
    # Frame
    "frame_locator",
    # Locator
    "locator",
    # Dispatch
    "dispatch_event",
})


def _parse_script_lines(script: str) -> list[str]:
    """Parse script text into executable lines, stripping blanks + comments."""
    lines = []
    for raw in script.strip().splitlines():
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("await "):
            stripped = stripped[6:]
        lines.append(stripped)
    return lines


def _parse_method_call(line: str) -> tuple[str, str]:
    """
    Parse a page.method(...) line into (method_name, raw_args_string).
    Raises ValueError on invalid lines.
    """
    m = _LINE_RE.match(line)
    if not m:
        raise ValueError(f"Cannot parse line (expected page.method(...)): {line[:80]}")
    method = m.group(1)
    args_raw = (m.group(2) or "").strip()
    if method not in _ALLOWED_METHODS:
        raise ValueError(f"Method '{method}' is not in the allowed whitelist")
    return method, args_raw


def _safe_parse_args(args_raw: str) -> tuple[list, dict]:
    """
    Parse argument string into positional and keyword args using AST.
    This is safe — AST only parses literals, no code execution.
    """
    if not args_raw:
        return [], {}

    # Wrap in a function call node so ast can parse it
    try:
        tree = ast.parse(f"_f({args_raw})", mode="eval")
    except SyntaxError as exc:
        raise ValueError(f"Cannot parse arguments: {exc}") from exc

    call_node = tree.body
    if not isinstance(call_node, ast.Call):
        raise ValueError("Expected a function call expression")

    positional = []
    for arg in call_node.args:
        positional.append(ast.literal_eval(arg))

    keyword = {}
    for kw in call_node.keywords:
        keyword[kw.arg] = ast.literal_eval(kw.value)

    return positional, keyword


# ═══════════════════════════════════════════════════════════════
# Executor
# ═══════════════════════════════════════════════════════════════

class ScriptExecutor:
    """
    Executes Playwright scripts deterministically.
    No eval(). No LLM. Just method dispatch.
    """

    def __init__(self, config: ExecutionConfig):
        self._config = config

    async def execute(
        self,
        script: str,
        params: dict,
        page: Page,
        validation_rules: Optional[list[ValidationRule]] = None,
        screenshot_dir: Optional[str] = None,
    ) -> ExecutionResult:
        """Run a complete Playwright script and return structured result."""
        from core.param_resolver import resolve_params

        start = time.monotonic()
        resolved = resolve_params(script, params)
        lines = _parse_script_lines(resolved)
        total = len(lines)

        if total == 0:
            return ExecutionResult(
                success=False, executed_lines=0, total_lines=0, duration_ms=0,
                error=ErrorContext(
                    error_type="EmptyScript",
                    error_message="Script contains no executable lines",
                    category=ErrorCategory.UNKNOWN,
                    failed_line="", failed_line_number=0,
                ),
            )

        logger.info("Executing script (%d lines)", total)

        executed = 0
        for idx, line in enumerate(lines):
            try:
                await self._dispatch(line, page)
                executed = idx + 1
                logger.debug("[%d/%d] %s", executed, total, line[:80])
            except Exception as exc:
                elapsed = int((time.monotonic() - start) * 1000)
                err_ctx = await self._build_error_ctx(
                    exc, line, idx, lines, page, screenshot_dir, elapsed,
                )
                logger.warning(
                    "Execution failed at line %d/%d: %s",
                    idx + 1, total, str(exc)[:160],
                )
                return ExecutionResult(
                    success=False,
                    executed_lines=executed,
                    total_lines=total,
                    duration_ms=elapsed,
                    page_url=page.url,
                    page_title=await _safe_title(page),
                    error=err_ctx,
                )

        # All lines passed — run validation
        elapsed = int((time.monotonic() - start) * 1000)
        val_results: list[ValidationResult] = []
        if validation_rules:
            val_results = await self._validate(page, validation_rules)
            failed = [v for v in val_results if not v.passed]
            if failed:
                ps = await self.capture_page_state(page)
                return ExecutionResult(
                    success=False,
                    executed_lines=total,
                    total_lines=total,
                    duration_ms=elapsed,
                    page_url=page.url,
                    page_title=await _safe_title(page),
                    validation_results=val_results,
                    error=ErrorContext(
                        error_type="ValidationError",
                        error_message=f"Post-execution validation failed: {failed[0].message}",
                        category=ErrorCategory.VALIDATION_FAILED,
                        failed_line=lines[-1],
                        failed_line_number=total - 1,
                        page_state=ps,
                        elapsed_ms=elapsed,
                    ),
                )

        logger.info("Script completed (%d lines, %dms)", total, elapsed)
        return ExecutionResult(
            success=True,
            executed_lines=total,
            total_lines=total,
            duration_ms=elapsed,
            page_url=page.url,
            page_title=await _safe_title(page),
            validation_results=val_results,
        )

    # ── dispatch (replaces eval) ──────────────────────────────

    async def _dispatch(self, line: str, page: Page) -> None:
        """Dispatch a single page.method(...) call safely."""
        method_name, args_raw = _parse_method_call(line)
        pos, kw = _safe_parse_args(args_raw)

        # Resolve nested calls like page.keyboard.press(...)
        obj = page
        for part in method_name.split("."):
            obj = getattr(obj, part)

        if callable(obj):
            result = obj(*pos, **kw)
            if asyncio.iscoroutine(result):
                await result
        else:
            raise ValueError(f"page.{method_name} is not callable")

    # ── page state capture ────────────────────────────────────

    async def capture_page_state(self, page: Page) -> PageState:
        """Compact DOM snapshot for LLM context — token-optimized."""
        max_el = self._config.page_state_max_elements
        try:
            raw = await page.evaluate("""(max) => {
                const out = [];
                const sel = 'a,button,input,select,textarea,'
                    + '[role="button"],[role="alert"],[role="listbox"],'
                    + '[role="option"],[role="dialog"],[role="menuitem"]';
                for (const el of document.querySelectorAll(sel)) {
                    const r = el.getBoundingClientRect();
                    if (r.width <= 0 || r.height <= 0) continue;
                    out.push({
                        tag: el.tagName.toLowerCase(),
                        type: el.type || null,
                        txt: (el.textContent||'').trim().slice(0,60),
                        aria: el.getAttribute('aria-label'),
                        id: el.id || null,
                        name: el.name || null,
                        role: el.getAttribute('role'),
                        val: el.value || null,
                        ph: el.placeholder || null,
                        dis: el.disabled || false,
                    });
                    if (out.length >= max) break;
                }
                return out;
            }""", max_el)
        except Exception:
            raw = []

        elements = [
            ElementInfo(
                tag=e["tag"],
                selector=_best_selector(e),
                text=e.get("txt"),
                aria_label=e.get("aria"),
                element_type=e.get("type"),
                name=e.get("name"),
                role=e.get("role"),
                value=e.get("val"),
                is_enabled=not e.get("dis", False),
            )
            for e in raw
        ]

        try:
            alerts = await page.evaluate("""() => {
                const a = [];
                const sel = '[role="alert"],.error,.warning,.notification,.toast,'
                    + '.ms-MessageBar,[data-automation-id="error"],.alert-danger';
                for (const el of document.querySelectorAll(sel)) {
                    const t = (el.textContent||'').trim();
                    if (t.length > 3) a.push(t.slice(0,120));
                }
                return [...new Set(a)].slice(0,5);
            }""")
        except Exception:
            alerts = []

        return PageState(
            url=page.url,
            title=await _safe_title(page),
            interactive_elements=elements,
            alerts=alerts,
        )

    # ── error context ─────────────────────────────────────────

    async def _build_error_ctx(
        self, exc, line, idx, lines, page, ss_dir, elapsed,
    ) -> ErrorContext:
        etype = type(exc).__name__
        emsg = str(exc)
        cat, _ = classify_error(emsg, etype, page.url)

        ps = await self.capture_page_state(page)
        ss = await _take_screenshot(page, idx, ss_dir) if ss_dir else None

        return ErrorContext(
            error_type=etype,
            error_message=emsg[:500],
            category=cat,
            failed_line=line,
            failed_line_number=idx,
            lines_before=lines[max(0, idx - 2) : idx],
            lines_after=lines[idx + 1 : idx + 3],
            page_url=page.url,
            page_title=await _safe_title(page),
            page_state=ps,
            screenshot_path=ss,
            elapsed_ms=elapsed,
        )

    # ── validation ────────────────────────────────────────────

    async def _validate(
        self, page: Page, rules: list[ValidationRule],
    ) -> list[ValidationResult]:
        return [await self._check(page, r) for r in rules]

    async def _check(self, page: Page, rule: ValidationRule) -> ValidationResult:
        try:
            if rule.type == ValidationType.TEXT_PRESENT:
                cnt = await page.locator(f"text={rule.value}").count()
                return ValidationResult(rule=rule, passed=cnt > 0,
                    actual_value=f"{cnt} matches",
                    message=f"Text '{rule.value}' {'found' if cnt else 'not found'}")

            elif rule.type == ValidationType.TEXT_NOT_PRESENT:
                cnt = await page.locator(f"text={rule.value}").count()
                return ValidationResult(rule=rule, passed=cnt == 0,
                    actual_value=f"{cnt} matches",
                    message=f"Text '{rule.value}' should be absent (found {cnt})")

            elif rule.type == ValidationType.URL_CONTAINS:
                ok = rule.value in page.url
                return ValidationResult(rule=rule, passed=ok,
                    actual_value=page.url,
                    message=f"URL {'contains' if ok else 'missing'} '{rule.value}'")

            elif rule.type == ValidationType.ELEMENT_VISIBLE:
                sel = rule.selector or rule.value
                vis = await page.locator(sel).is_visible()
                return ValidationResult(rule=rule, passed=vis,
                    message=f"Element '{sel}' {'visible' if vis else 'not visible'}")

            elif rule.type == ValidationType.ELEMENT_NOT_VISIBLE:
                sel = rule.selector or rule.value
                vis = await page.locator(sel).is_visible()
                return ValidationResult(rule=rule, passed=not vis,
                    message=f"Element should be hidden but is visible")

            elif rule.type == ValidationType.FIELD_VALUE:
                val = await page.input_value(rule.selector)
                ok = val == rule.value
                return ValidationResult(rule=rule, passed=ok,
                    actual_value=val,
                    message=f"Expected '{rule.value}', got '{val}'")

            return ValidationResult(rule=rule, passed=False,
                message=f"Unknown validation type: {rule.type}")
        except Exception as exc:
            return ValidationResult(rule=rule, passed=False,
                message=f"Validation error: {str(exc)[:100]}")


# ═══════════════════════════════════════════════════════════════
# helpers
# ═══════════════════════════════════════════════════════════════

def _best_selector(e: dict) -> Optional[str]:
    if e.get("id"):
        return f"#{e['id']}"
    if e.get("name"):
        return f'[name="{e["name"]}"]'
    if e.get("aria"):
        return f'[aria-label="{e["aria"]}"]'
    if e.get("ph"):
        return f'[placeholder="{e["ph"]}"]'
    if e.get("role") and e.get("txt"):
        return f'{e["tag"]}[role="{e["role"]}"]:has-text("{e["txt"][:30]}")'
    return None


async def _safe_title(page: Page) -> str:
    try:
        return await page.title()
    except Exception:
        return ""


async def _take_screenshot(page: Page, idx: int, directory: str) -> Optional[str]:
    try:
        Path(directory).mkdir(parents=True, exist_ok=True)
        path = f"{directory}/failure_line_{idx}.png"
        await page.screenshot(path=path, full_page=False)
        return path
    except Exception:
        return None
