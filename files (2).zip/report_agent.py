"""
agents/report_agent.py
========================
ReportAgent — Final QA disposition and consolidated action plan.

Reads upstream agent outputs that earlier agents wrote to session state
via their output_key:
    {ingest_result}   ← IngestAgent
    {si_result}       ← SecurityInstrumentAgent
    {title_result}    ← TitleReportAgent
    {lien_result}     ← LienValidationAgent

ADK Integration:
  - Input  : reads {ingest_result}, {si_result}, {title_result},
             {lien_result} from session state
  - Output : writes "report" to session state
"""

from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm


REPORT_INSTRUCTION = """
You are ReportAgent — the final agent in a Senior Lien Verification QA pipeline.

You receive the JSON outputs from four upstream agents. Each is already in
session state and provided below.

───────────────────────────────────────────────────────────────
STEPS
───────────────────────────────────────────────────────────────
1. Collect all flags from all four agent results.
2. Deduplicate by code — if the same code appears more than once,
   keep the instance with the highest severity.
3. Sort the final list: critical → high → medium → info.
4. Count flags by severity.

5. Disposition (first matching rule wins):
   - END_PROCESS   : lien_result.end_process is true
   - REFER_TRU     : any critical OR high flag
   - CAUTION       : any medium flag (no critical/high)
   - CLEAR         : no flags (or only info)

6. Collect every non-null arrow_activity from all flags → arrow_activities.
7. Collect all ecar_actions from si_result → ecar_actions.
   Append lien_result.ecar_senior_review_comment if present.
8. Collect all email_actions from title_result → email_actions.

9. Write a processor_next_steps narrative appropriate to the disposition:
   - CLEAR       : proceed to payoff calculation; return to ARROW DQ queue.
   - CAUTION     : complete email/follow-up actions; set ARROW follow-up.
   - REFER_TRU   : add listed ARROW activities; complete ECaR actions;
                   go to Sending File to TRU section; re-run after TRU review.
   - END_PROCESS : halt; add ARROW activity; set deficiency to Satisfied;
                   refer to TRU; do NOT proceed to title order or payoff.

───────────────────────────────────────────────────────────────
UPSTREAM AGENT OUTPUTS
───────────────────────────────────────────────────────────────
case_id: {case_id}

ingest_result:
{ingest_result}

si_result:
{si_result}

title_result:
{title_result}

lien_result:
{lien_result}

───────────────────────────────────────────────────────────────
OUTPUT
───────────────────────────────────────────────────────────────
Return ONLY a valid JSON object (no markdown, no code fences, no preamble):

{{
  "case_id": "{case_id}",
  "disposition": "CLEAR" | "CAUTION" | "REFER_TRU" | "END_PROCESS",
  "disposition_reason": "<brief>",
  "critical_count": <int>,
  "high_count": <int>,
  "medium_count": <int>,
  "info_count": <int>,
  "all_flags": [
    {{
      "severity": "...",
      "code": "...",
      "message": "...",
      "arrow_activity": null | {{}}
    }}
  ],
  "arrow_activities": [
    {{
      "type": "Request",
      "party": "Internal",
      "result": "Additional Research Needed",
      "activity_text": "...",
      "deficiency_status": "Satisfied"
    }}
  ],
  "ecar_actions": [
    {{ "screen": "...", "action": "..." }}
  ],
  "email_actions": [
    {{ "to": "...", "subject": "...", "body": "..." }}
  ],
  "processor_next_steps": "<narrative paragraph>",
  "agent_summaries": {{
    "ingest": "<ingest summary>",
    "security_instrument": "<si summary>",
    "title_report": "<title summary>",
    "lien_validation": "<lien summary>"
  }}
}}
"""


def build_report_agent(model: str = "gemini-2.0-flash") -> LlmAgent:
    """Returns the configured ReportAgent."""
    return LlmAgent(
        name="ReportAgent",
        model=LiteLlm(model=f"gemini/{model}"),
        description=(
            "Aggregates upstream agent findings into the final QA "
            "disposition, consolidated ARROW activity list, ECaR action "
            "plan, email action list, and processor next-step narrative."
        ),
        instruction=REPORT_INSTRUCTION,
        output_key="report",
    )
