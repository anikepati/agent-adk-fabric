"""
Processor registry with @register_processor decorator.
Discovers all processor types at startup by scanning the processors package.
"""
from __future__ import annotations

import importlib
import logging
import pkgutil
from typing import Any, Type

from app.processors.base import BaseProcessor, ProcessorContext

logger = logging.getLogger(__name__)

# Global registry: processor_type_name → processor_class
_REGISTRY: dict[str, Type[BaseProcessor]] = {}


def register_processor(name: str):
    """Decorator to register a processor class under a given name."""

    def decorator(cls: Type[BaseProcessor]) -> Type[BaseProcessor]:
        if name in _REGISTRY:
            raise ValueError(
                f"Duplicate processor registration: '{name}' "
                f"(existing: {_REGISTRY[name].__name__}, new: {cls.__name__})"
            )
        _REGISTRY[name] = cls
        logger.debug(f"Registered processor: {name} → {cls.__name__}")
        return cls

    return decorator


def discover_processors() -> None:
    """Import all modules in the processors package to trigger @register_processor."""
    import app.processors as pkg

    for importer, modname, ispkg in pkgutil.walk_packages(
        pkg.__path__, prefix="app.processors."
    ):
        if modname == "app.processors.base" or modname == "app.processors.registry":
            continue
        try:
            importlib.import_module(modname)
            logger.debug(f"Discovered processor module: {modname}")
        except Exception as e:
            logger.error(f"Failed to import processor module {modname}: {e}")


def create_processor(
    processor_type: str,
    config: dict[str, Any],
    cluster_name: str,
    topic: str,
) -> BaseProcessor:
    """Create a processor instance by type name."""
    cls = _REGISTRY.get(processor_type)
    if cls is None:
        available = ", ".join(sorted(_REGISTRY.keys()))
        raise ValueError(
            f"Unknown processor type: '{processor_type}'. "
            f"Available: [{available}]"
        )

    context = ProcessorContext(
        cluster_name=cluster_name,
        topic=topic,
        config=config,
    )
    return cls(config=config, context=context)


def get_registered_types() -> list[str]:
    return sorted(_REGISTRY.keys())


def is_registered(name: str) -> bool:
    return name in _REGISTRY
