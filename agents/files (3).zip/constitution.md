# Resumable Pipeline — Constitution

Non-negotiable principles for this design. Any plan that violates one MUST
be rejected and re-planned. These override convenience, brevity, or speed
of delivery.

---

## Article I — ADK-Native Primitives Only

The design MUST use only the primitives ADK already exposes:
`BaseAgent`, `LlmAgent`, `output_key`, `session.state`, `Event`,
`EventActions`, `App`, `Runner`, `DatabaseSessionService`,
`ResumabilityConfig`. We DO NOT build a parallel framework (Step protocol,
PauseRequest dataclasses, custom ledger tables, custom audit tables) on
top of ADK. Where ADK already provides a mechanism, we use it.

## Article II — State Is the Contract

Sub-agent completion is determined exclusively by whether the sub-agent's
declared `output_key` is set in `session.state`. There MUST NOT be parallel
maps, completion flags, status enums, or any other secondary signal of
"doneness". `state.get(sub.output_key) is not None` is the sole skip
criterion.

## Article III — DatabaseSessionService Is the Durability Layer

All durable state MUST live in `session.state` persisted by
`DatabaseSessionService`. We MUST NOT create our own tables for tracking
workflow state. A workflow that pauses today and resumes in 40 days
depends only on the session row still existing in the configured database.

## Article IV — The Orchestrator Is Mechanical, Not Semantic

The orchestrator MUST NOT contain domain logic (no mention of "approval",
"decision", "case", "verdict"). Its responsibilities are:

1. Iterate sub-agents in declared order.
2. Skip those whose `output_key` is set.
3. Run those whose `output_key` is unset.
4. Stop on `EventActions.escalate=True`.
5. Pause if a sub-agent ran without setting its `output_key`.

Adding any sixth responsibility is a violation.

## Article V — The Gate Is the Only Domain-Aware Piece

The pause point is implemented by a single `AgentGate(BaseAgent)`. It
reads a configurable decision key from state and decides via a
configurable allow-list. All domain knowledge about what counts as
"approved" lives in the gate's `approved_values`, not in the orchestrator.

## Article VI — Vanilla Sub-Agents Without Wrapping

Any existing `LlmAgent` or `BaseAgent` with an `output_key` MUST be usable
as a sub-agent without modification — no adapter classes, no protocol
implementations. Drop it into `sub_agents=[...]` and it works.

## Article VII — Resume by Session ID

Resume MUST require only a session_id and a decision payload. Callers
MUST NOT need to know `invocation_id`, `function_call_id`, or any
ADK internal. The decision is written into `session.state` via
`session_service.append_event(...)` and the orchestrator picks it up
on the next `run_async`.

## Article VIII — Long-Pause Tolerance

The design MUST tolerate arbitrary gaps between pause and resume —
seconds, days, or weeks. No in-memory state may be required to bridge
the gap. The Postgres pool MUST use `pool_pre_ping` (default in ADK
≥ 1.21 for non-SQLite engines) so that stale connections are detected
on resume. This is the 40-day requirement.

## Article IX — Simplicity Over Generality

If a generalization is not needed by an existing use case in this repo,
it is not added. We do not introduce typed step outcomes, retry
policies, audit sinks, or pluggable persistence "in case we need them
later". When we need them, we add them with their use case.

## Article X — Test the Behavior, Not the LLM

Acceptance tests MUST be runnable without a real Gemini API key. Tests
for the orchestrator and the gate use deterministic `BaseAgent` stubs in
place of `LlmAgent`s. LLM integration is tested separately and is not
gating for the framework changes.

---

## Process Constraints

- **Spec → Plan → Code**: order is mandatory.
- **One file is fine.** The current implementation lives in `main.py`. We
  split only when the file exceeds 700 lines or two unrelated concerns
  emerge.
- **No backward-incompatible state-key changes** without a migration.
  `decision_key`, `output_key` defaults are part of the contract once
  shipped.
- **ADK version pin** lives in `requirements.txt` with `>=` and a tested
  upper bound documented in `plan.md` §Framework Decisions.
