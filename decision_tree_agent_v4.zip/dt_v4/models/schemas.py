"""
Pydantic schemas v4 — merged best of both approaches.

New in v4:
  - calculated_fields section for safe derived value computation
  - settings section is optional (agent can work without it)
  - dag section passes through via extra="allow"
"""

from __future__ import annotations
from typing import Any, Dict, List, Literal, Optional, Union
from pydantic import BaseModel, Field, model_validator


# ── Condition Models ─────────────────────────────────────────

class SimpleCondition(BaseModel):
    operator: Literal[
        "gt", "gte", "lt", "lte", "eq", "neq",
        "contains", "starts_with", "ends_with", "regex", "is_empty",
        "is_null", "is_not_null", "between", "in", "not_in",
    ]
    left_column: str
    right_column: Optional[str] = None
    right_value: Optional[Any] = None
    pattern: Optional[str] = None
    low: Optional[Union[int, float]] = None
    high: Optional[Union[int, float]] = None
    values: Optional[List[Any]] = None

    @model_validator(mode="after")
    def check(self):
        op = self.operator
        if op in ("gt","gte","lt","lte","eq","neq","contains","starts_with","ends_with"):
            if self.right_column is None and self.right_value is None:
                raise ValueError(f"'{op}' needs right_column or right_value")
        if op == "regex" and not self.pattern:
            raise ValueError("'regex' needs 'pattern'")
        if op == "between" and (self.low is None or self.high is None):
            raise ValueError("'between' needs 'low' and 'high'")
        if op in ("in","not_in") and not self.values:
            raise ValueError(f"'{op}' needs 'values'")
        return self


class CompoundCondition(BaseModel):
    operator: Literal["and", "or"]
    conditions: List[Union[SimpleCondition, "CompoundCondition"]]

Condition = Union[SimpleCondition, CompoundCondition]


# ── Action Models ────────────────────────────────────────────

class ActionBranch(BaseModel):
    action: Literal["api_call", "db_update", "log_only", "none"] = "none"
    method: Optional[str] = "POST"
    endpoint: Optional[str] = None
    payload: Optional[Dict[str, Any]] = None
    set: Optional[Dict[str, Any]] = None
    table: Optional[str] = None
    next_decision: Optional["DecisionNode"] = None


# ── Decision Node ────────────────────────────────────────────

class DecisionNode(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    condition: Condition
    on_true: ActionBranch = Field(default_factory=lambda: ActionBranch(action="none"))
    on_false: ActionBranch = Field(default_factory=lambda: ActionBranch(action="none"))


# ── Calculated Field ─────────────────────────────────────────

class CalculatedField(BaseModel):
    """
    Safe computed field — no eval(). Uses operator + column references.
    Computed BEFORE tree evaluation so trees can reference derived values.
    """
    output_key: str
    operator: Literal["add", "subtract", "multiply", "divide", "concat",
                       "coalesce", "lookup", "percent", "constant"]
    left_column: Optional[str] = None
    right_column: Optional[str] = None
    right_value: Optional[Any] = None
    value: Optional[Any] = None           # for constant
    columns: Optional[List[str]] = None   # for coalesce, concat
    format: Optional[str] = None          # for concat separator


# ── DAG Node ─────────────────────────────────────────────────

class DAGNode(BaseModel):
    id: str
    tree_id: Optional[str] = None
    tree_ids: Optional[List[str]] = None
    depends_on: List[str] = []

    @model_validator(mode="after")
    def check_tree_ref(self):
        if not self.tree_id and not self.tree_ids:
            raise ValueError("DAG node needs tree_id or tree_ids")
        return self


class DAGConfig(BaseModel):
    nodes: List[DAGNode]
    on_dependency_failure: Literal["skip", "continue", "abort"] = "skip"


# ── Settings (optional) ─────────────────────────────────────

class Settings(BaseModel):
    api_base_url: str = ""
    db_connection_string: str = "sqlite:///results.db"
    db_table: str = "validation_results"
    dry_run: bool = True


# ── Top-Level Config ─────────────────────────────────────────

class DecisionTreeConfig(BaseModel):
    model_config = {"extra": "allow"}
    settings: Optional[Settings] = None
    calculated_fields: Optional[List[CalculatedField]] = None
    decision_trees: List[DecisionNode]
    dag: Optional[DAGConfig] = None


# Forward reference rebuild
CompoundCondition.model_rebuild()
ActionBranch.model_rebuild()
DecisionNode.model_rebuild()
DecisionTreeConfig.model_rebuild()
