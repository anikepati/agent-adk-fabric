"""
ADK Agent Composition.

LoopAgent("BrowserWorkflowAgent")
  └── SequentialAgent("ExecuteAndReplan")
        ├── LlmAgent("ScriptExecutor")     → run_playwright_script
        └── LlmAgent("Replanner")          → rewrite script on failure
"""

from google.adk.agents import LlmAgent, SequentialAgent, LoopAgent

from tools.adk_tools import (
    run_playwright_script,
    apply_rewritten_script,
    get_live_page_state,
    abort_workflow,
)

# ═══════════════════════════════════════════════════════════════
# System Prompts
# ═══════════════════════════════════════════════════════════════

_EXECUTOR_PROMPT = """\
You are a script executor. Your only job:
1. Call run_playwright_script immediately.
2. Report its return value verbatim.
Do NOT add reasoning or commentary. Do NOT call any other tool."""

_REPLANNER_PROMPT = """\
You are a Playwright script recovery specialist.

## Gate check — do this FIRST

Read session state:
- If needs_replan is False → say "No replan needed." and STOP.
- If task_complete is True  → say "Task already complete." and STOP.
- Otherwise proceed.

## Context

Read replan_context from state. It has:
  original_script   – the script that broke
  failed_line       – exact line that threw
  failed_line_number
  lines_before / lines_after
  error_type, error_message, category
  page_url
  page_state        – compact DOM snapshot (elements + alerts)
  recovery_hints    – domain tips from the skill definition

## Your job

Rewrite the COMPLETE script so it succeeds given the current page.

Rules:
- Every executable line starts with page.  (Playwright async API).
- Use selectors you can see in page_state.elements — never guess.
- The script must be self-contained (all lines, not just the patch).
- Do NOT add try/except, comments, or explanations — just the fix.
- If you need a fresh DOM snapshot call get_live_page_state first.

## When to abort

Call abort_workflow with a clear reason if:
- Authentication error (401/403)
- Server error (500/502/503)
- Required element is absent from page_state entirely
- Same error repeats across multiple attempts (check script_history)

## Submit

Call apply_rewritten_script with the full new script.
"""


# ═══════════════════════════════════════════════════════════════
# Agent Definitions
# ═══════════════════════════════════════════════════════════════

def build_agents(model: str = "gemini-2.0-flash") -> LoopAgent:
    """Construct the full agent tree."""

    executor = LlmAgent(
        name="ScriptExecutor",
        model=model,
        instruction=_EXECUTOR_PROMPT,
        tools=[run_playwright_script],
        output_key="executor_output",
    )

    replanner = LlmAgent(
        name="Replanner",
        model=model,
        instruction=_REPLANNER_PROMPT,
        tools=[apply_rewritten_script, get_live_page_state, abort_workflow],
        output_key="replanner_output",
    )

    cycle = SequentialAgent(
        name="ExecuteAndReplan",
        sub_agents=[executor, replanner],
    )

    return LoopAgent(
        name="BrowserWorkflowAgent",
        sub_agents=[cycle],
        max_iterations=5,
    )


# Convenience for ADK app discovery
root_agent = build_agents()
