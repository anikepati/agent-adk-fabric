"""
ConsumerThread: one per Kafka cluster.
Runs the poll loop, dispatches messages to the worker pool,
manages partition queues for ordered offset commit.
"""
from __future__ import annotations

import asyncio
import logging
import time
import threading
from collections import defaultdict
from concurrent.futures import Future, ThreadPoolExecutor
from typing import Any, Callable

from confluent_kafka import Consumer, KafkaError, KafkaException, TopicPartition

from app.config.models import ClusterConfig, TopicConfig
from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult, ResultStatus
from app.core.topic_map import TopicMap
from app.observability import metrics as m
from app.resilience.backpressure import BackpressureController
from app.resilience.circuit_breaker import CircuitBreaker
from app.resilience.dlq_producer import DLQProducer
from app.resilience.retry import RetryHandler
from app.serialization import create_deserializer, DeserializationError

logger = logging.getLogger(__name__)


class ConsumerThread(threading.Thread):
    """
    Kafka consumer thread for a single cluster.
    Subscribes to all topics configured for this cluster in YAML.
    Dispatches processing to a shared worker pool.
    Commits offsets per-partition after successful processing.
    """

    def __init__(
        self,
        cluster_name: str,
        cluster_config: ClusterConfig,
        topic_configs: list[TopicConfig],
        topic_map: TopicMap,
        worker_pool: ThreadPoolExecutor,
        backpressure: BackpressureController,
        shutdown_event: threading.Event,
        dlq_suffix: str = ".dlq",
    ) -> None:
        super().__init__(name=f"consumer-{cluster_name}", daemon=True)
        self.cluster_name = cluster_name
        self._cluster_config = cluster_config
        self._topic_configs = {tc.topic: tc for tc in topic_configs}
        self._topic_map = topic_map
        self._worker_pool = worker_pool
        self._backpressure = backpressure
        self._shutdown_event = shutdown_event
        self._dlq_suffix = dlq_suffix

        # State
        self._consumer: Consumer | None = None
        self._dlq_producer: DLQProducer | None = None
        self._is_ready = False
        self._assigned_partitions: list[TopicPartition] = []

        # Per-partition ordered queues
        self._partition_queues: dict[tuple[str, int], list[ConsumerMessage]] = defaultdict(list)
        self._in_flight: dict[tuple[str, int], Future] = {}
        self._lock = threading.Lock()

        # Circuit breakers per topic
        self._circuit_breakers: dict[str, CircuitBreaker] = {}
        for tc in topic_configs:
            if tc.circuit_breaker:
                self._circuit_breakers[tc.topic] = CircuitBreaker(tc.topic, tc.circuit_breaker)

        # Retry handlers per topic
        self._retry_handlers: dict[str, RetryHandler] = {}
        for tc in topic_configs:
            if tc.retry:
                self._retry_handlers[tc.topic] = RetryHandler(tc.retry)

        # Deserializers per topic
        sr_url = cluster_config.schema_registry.url if cluster_config.schema_registry else None
        sr_auth = cluster_config.schema_registry.auth if cluster_config.schema_registry else None
        self._deserializers = {}
        for tc in topic_configs:
            self._deserializers[tc.topic] = create_deserializer(tc.format, sr_url, sr_auth)

        # Async event loop for processor execution
        self._loop: asyncio.AbstractEventLoop | None = None

    @property
    def is_ready(self) -> bool:
        return self._is_ready

    @property
    def subscribed_topics(self) -> list[str]:
        return list(self._topic_configs.keys())

    @property
    def assigned_partitions_info(self) -> list[dict[str, Any]]:
        return [
            {"topic": tp.topic, "partition": tp.partition}
            for tp in self._assigned_partitions
        ]

    def run(self) -> None:
        """Main thread entry point: create consumer, subscribe, poll."""
        self._loop = asyncio.new_event_loop()

        try:
            self._consumer = Consumer(self._cluster_config.build_consumer_params())
            self._dlq_producer = DLQProducer(self.cluster_name, self._cluster_config)

            topic_names = list(self._topic_configs.keys())
            self._consumer.subscribe(
                topic_names,
                on_assign=self._on_assign,
                on_revoke=self._on_revoke,
            )

            logger.info(
                "Consumer thread started",
                extra={
                    "cluster": self.cluster_name,
                    "topics": topic_names,
                    "group_id": self._cluster_config.group_id,
                },
            )

            self._poll_loop()

        except Exception as e:
            logger.error(
                "Consumer thread crashed",
                extra={"cluster": self.cluster_name, "error": str(e)},
                exc_info=True,
            )
        finally:
            self._cleanup()
            if self._loop:
                self._loop.close()

    def _poll_loop(self) -> None:
        """Core poll loop: poll → deserialize → dispatch → commit."""
        while not self._shutdown_event.is_set():
            poll_start = time.monotonic()
            try:
                msg = self._consumer.poll(timeout=1.0)
            except KafkaException as e:
                logger.error(f"Kafka poll error: {e}", extra={"cluster": self.cluster_name})
                continue

            poll_duration = time.monotonic() - poll_start
            m.POLL_DURATION.labels(cluster=self.cluster_name).observe(poll_duration)

            if msg is None:
                self._harvest_completed()
                continue

            if msg.error():
                if msg.error().code() == KafkaError._PARTITION_EOF:
                    continue  # Normal: reached end of partition
                logger.error(
                    "Kafka message error",
                    extra={
                        "cluster": self.cluster_name,
                        "error": str(msg.error()),
                        "topic": msg.topic(),
                    },
                )
                continue

            # Deserialize
            topic_name = msg.topic()
            deserializer = self._deserializers.get(topic_name)
            if not deserializer:
                logger.error(f"No deserializer for topic {topic_name}")
                continue

            try:
                value = deserializer.deserialize(msg.value())
            except DeserializationError as e:
                # Poison pill: straight to DLQ, no retry
                logger.warning(
                    "Deserialization failed (poison pill)",
                    extra={
                        "topic": topic_name,
                        "partition": msg.partition(),
                        "offset": msg.offset(),
                        "error": str(e),
                    },
                )
                m.record_deserialization_error(self.cluster_name, topic_name)

                # Build minimal message for DLQ
                consumer_msg = ConsumerMessage(
                    topic=topic_name,
                    partition=msg.partition(),
                    offset=msg.offset(),
                    key=msg.key(),
                    value=None,
                    raw_value=msg.value() or b"",
                    headers=self._extract_headers(msg),
                    timestamp_ms=msg.timestamp()[1] if msg.timestamp()[0] != 0 else 0,
                    cluster_name=self.cluster_name,
                )
                tc = self._topic_configs.get(topic_name)
                dlq_topic = tc.effective_dlq(self._dlq_suffix) if tc else f"{topic_name}.dlq"
                self._dlq_producer.send(
                    consumer_msg, dlq_topic, str(e), "deserializer", 0
                )
                self._consumer.commit(message=msg, asynchronous=False)
                m.record_dlq(self.cluster_name, topic_name)
                continue

            # Build consumer message
            consumer_msg = ConsumerMessage(
                topic=topic_name,
                partition=msg.partition(),
                offset=msg.offset(),
                key=msg.key(),
                value=value,
                raw_value=msg.value() or b"",
                headers=self._extract_headers(msg),
                timestamp_ms=msg.timestamp()[1] if msg.timestamp()[0] != 0 else 0,
                cluster_name=self.cluster_name,
            )

            # Enqueue to partition queue
            pk = consumer_msg.partition_key
            with self._lock:
                self._partition_queues[pk].append(consumer_msg)
                self._submit_next(pk)

            # Harvest completed futures
            self._harvest_completed()

    def _submit_next(self, partition_key: tuple[str, int]) -> None:
        """Submit the next message from a partition queue to the worker pool.
        Must be called while holding self._lock.
        """
        queue = self._partition_queues.get(partition_key)
        if not queue or partition_key in self._in_flight:
            return  # Queue empty or already processing

        msg = queue[0]

        # Backpressure check
        if not self._backpressure.acquire(timeout=0):
            # Pool saturated — will be retried on next harvest
            return

        m.IN_FLIGHT_MESSAGES.labels(cluster=self.cluster_name).inc()

        future = self._worker_pool.submit(self._execute_message, msg)
        self._in_flight[partition_key] = future

    def _harvest_completed(self) -> None:
        """Check for completed futures, commit offsets, submit next messages."""
        with self._lock:
            completed_keys = []
            for pk, future in self._in_flight.items():
                if future.done():
                    completed_keys.append(pk)

            for pk in completed_keys:
                future = self._in_flight.pop(pk)
                queue = self._partition_queues.get(pk, [])

                try:
                    future.result()  # Raise any exception from worker
                except Exception as e:
                    logger.error(
                        "Worker execution error",
                        extra={"partition_key": pk, "error": str(e)},
                    )

                # Remove the processed message from queue
                if queue:
                    queue.pop(0)

                m.IN_FLIGHT_MESSAGES.labels(cluster=self.cluster_name).dec()
                self._backpressure.release()

                # Submit next message in this partition's queue
                if queue:
                    self._submit_next(pk)

    def _execute_message(self, message: ConsumerMessage) -> None:
        """Execute processor for a message. Runs in the worker pool."""
        topic_name = message.topic
        tc = self._topic_configs.get(topic_name)
        processor = self._topic_map.get(topic_name)

        if not processor:
            logger.error(f"No processor for topic {topic_name}")
            return

        # Circuit breaker check
        cb = self._circuit_breakers.get(topic_name)
        if cb and not cb.allow_request():
            logger.warning(
                "Circuit breaker OPEN, sending to DLQ",
                extra={"topic": topic_name},
            )
            dlq_topic = tc.effective_dlq(self._dlq_suffix) if tc else f"{topic_name}.dlq"
            self._dlq_producer.send(
                message, dlq_topic, "Circuit breaker open",
                processor.__class__.__name__, 0,
            )
            self._commit_offset(message)
            m.record_message(
                self.cluster_name, topic_name, "circuit_breaker",
                0, processor.__class__.__name__,
            )
            return

        # Execute with retry
        retry_handler = self._retry_handlers.get(topic_name)
        max_attempts = retry_handler._config.max_attempts if retry_handler else 1
        last_result = None

        for attempt in range(max_attempts):
            start = time.monotonic()
            try:
                result = self._loop.run_until_complete(processor.process(message))
            except Exception as e:
                result = ProcessorResult.retry(f"Unhandled exception: {e}", e)

            duration = time.monotonic() - start

            if result.is_success:
                self._commit_offset(message)
                if cb:
                    cb.record_success()
                m.record_message(
                    self.cluster_name, topic_name, "success",
                    duration, processor.__class__.__name__,
                )
                return

            if result.status == ResultStatus.SKIP:
                self._commit_offset(message)
                m.record_message(
                    self.cluster_name, topic_name, "skip",
                    duration, processor.__class__.__name__,
                )
                return

            if result.status == ResultStatus.DLQ:
                # No retry for DLQ results
                break

            # RETRY
            if result.is_retriable and attempt < max_attempts - 1:
                m.record_retry(self.cluster_name, topic_name, attempt + 1)
                if retry_handler:
                    retry_handler.wait(attempt)
                continue

            last_result = result

        # Exhausted retries or DLQ result → send to DLQ
        if cb:
            cb.record_failure()
        error = last_result.error if last_result else "Unknown error"
        dlq_topic = tc.effective_dlq(self._dlq_suffix) if tc else f"{topic_name}.dlq"
        self._dlq_producer.send(
            message, dlq_topic, error,
            processor.__class__.__name__, max_attempts,
        )
        self._commit_offset(message)
        m.record_dlq(self.cluster_name, topic_name)
        m.record_message(
            self.cluster_name, topic_name, "dlq",
            0, processor.__class__.__name__,
        )

    def _commit_offset(self, message: ConsumerMessage) -> None:
        """Commit offset for a specific message."""
        try:
            tp = TopicPartition(message.topic, message.partition, message.offset + 1)
            self._consumer.commit(offsets=[tp], asynchronous=False)
        except KafkaException as e:
            logger.error(
                "Offset commit failed",
                extra={
                    "topic": message.topic,
                    "partition": message.partition,
                    "offset": message.offset,
                    "error": str(e),
                },
            )

    def _on_assign(self, consumer: Consumer, partitions: list[TopicPartition]) -> None:
        """Callback when partitions are assigned after rebalance."""
        self._assigned_partitions = partitions
        self._is_ready = True
        m.REBALANCE_TOTAL.labels(cluster=self.cluster_name, type="assign").inc()
        logger.info(
            "Partitions assigned",
            extra={
                "cluster": self.cluster_name,
                "partitions": [
                    {"topic": tp.topic, "partition": tp.partition}
                    for tp in partitions
                ],
                "count": len(partitions),
            },
        )

    def _on_revoke(self, consumer: Consumer, partitions: list[TopicPartition]) -> None:
        """Callback when partitions are revoked before rebalance."""
        m.REBALANCE_TOTAL.labels(cluster=self.cluster_name, type="revoke").inc()
        logger.info(
            "Partitions revoked",
            extra={
                "cluster": self.cluster_name,
                "partitions": [
                    {"topic": tp.topic, "partition": tp.partition}
                    for tp in partitions
                ],
            },
        )

        # Wait for in-flight workers on revoked partitions
        with self._lock:
            for tp in partitions:
                pk = (tp.topic, tp.partition)
                if pk in self._in_flight:
                    future = self._in_flight[pk]
                    try:
                        future.result(timeout=60)
                    except Exception as e:
                        logger.warning(f"In-flight message failed during revoke: {e}")
                    self._in_flight.pop(pk, None)
                    self._backpressure.release()
                    m.IN_FLIGHT_MESSAGES.labels(cluster=self.cluster_name).dec()
                # Clear partition queue
                self._partition_queues.pop(pk, None)

        # Commit pending offsets
        try:
            consumer.commit(asynchronous=False)
        except KafkaException:
            pass

        # Flush DLQ producer
        if self._dlq_producer:
            self._dlq_producer.flush(timeout=10)

    def _extract_headers(self, msg: Any) -> dict[str, str]:
        """Extract headers from Kafka message."""
        headers = {}
        raw_headers = msg.headers()
        if raw_headers:
            for key, value in raw_headers:
                if value:
                    try:
                        headers[key] = value.decode("utf-8")
                    except (UnicodeDecodeError, AttributeError):
                        headers[key] = str(value)
        return headers

    def _cleanup(self) -> None:
        """Cleanup on thread exit."""
        logger.info("Consumer thread shutting down", extra={"cluster": self.cluster_name})

        # Wait for all in-flight workers
        with self._lock:
            for pk, future in list(self._in_flight.items()):
                try:
                    future.result(timeout=30)
                except Exception:
                    pass
                self._backpressure.release()
            self._in_flight.clear()
            self._partition_queues.clear()

        # Commit final offsets and close consumer
        if self._consumer:
            try:
                self._consumer.commit(asynchronous=False)
            except KafkaException:
                pass
            try:
                self._consumer.close()
            except Exception:
                pass

        # Flush DLQ producer
        if self._dlq_producer:
            self._dlq_producer.flush(timeout=10)

        self._is_ready = False
        logger.info("Consumer thread stopped", extra={"cluster": self.cluster_name})
