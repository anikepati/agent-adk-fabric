"""
FastAPI health server providing liveness, readiness, and status endpoints.
Also serves Prometheus metrics.
"""
from __future__ import annotations

import logging
import os
import threading
from typing import TYPE_CHECKING, Any

import uvicorn
from fastapi import FastAPI
from fastapi.responses import JSONResponse, PlainTextResponse
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST

if TYPE_CHECKING:
    from app.core.consumer_thread import ConsumerThread
    from app.leader.elector import LeaderElector

logger = logging.getLogger(__name__)


class HealthServer:
    """HTTP health probe and metrics server."""

    def __init__(self, port: int = 8080, metrics_port: int = 9090) -> None:
        self._port = port
        self._metrics_port = metrics_port
        self._consumer_threads: list[ConsumerThread] = []
        self._leader_elector: LeaderElector | None = None
        self._shutting_down = False
        self._app = self._create_app()
        self._thread: threading.Thread | None = None

    def register_consumer_threads(self, threads: list[ConsumerThread]) -> None:
        self._consumer_threads = threads

    def register_leader_elector(self, elector: LeaderElector) -> None:
        self._leader_elector = elector

    def set_shutting_down(self) -> None:
        self._shutting_down = True

    def _create_app(self) -> FastAPI:
        app = FastAPI(title="Kafka Consumer Platform", docs_url=None, redoc_url=None)

        @app.get("/health/live")
        async def liveness():
            """Pod is alive if process is running and all threads are alive."""
            if self._shutting_down:
                return JSONResponse(
                    {"status": "shutting_down"}, status_code=503
                )

            dead_threads = [
                t.name for t in self._consumer_threads if not t.is_alive()
            ]
            if dead_threads:
                return JSONResponse(
                    {"status": "unhealthy", "dead_threads": dead_threads},
                    status_code=503,
                )
            return {"status": "healthy"}

        @app.get("/health/ready")
        async def readiness():
            """Pod is ready if all consumer threads are actively polling."""
            if self._shutting_down:
                return JSONResponse(
                    {"status": "shutting_down"}, status_code=503
                )

            if not self._consumer_threads:
                return JSONResponse(
                    {"status": "not_ready", "reason": "no consumer threads"},
                    status_code=503,
                )

            not_ready = [
                t.name for t in self._consumer_threads if not t.is_ready
            ]
            if not_ready:
                return JSONResponse(
                    {"status": "not_ready", "waiting_for": not_ready},
                    status_code=503,
                )
            return {"status": "ready"}

        @app.get("/status")
        async def status():
            """Detailed status for debugging and leader aggregation."""
            thread_status = []
            for t in self._consumer_threads:
                thread_status.append({
                    "name": t.name,
                    "cluster": t.cluster_name,
                    "alive": t.is_alive(),
                    "ready": t.is_ready,
                    "topics": t.subscribed_topics,
                    "assigned_partitions": t.assigned_partitions_info,
                })

            return {
                "pod": os.environ.get("HOSTNAME", "unknown"),
                "is_leader": (
                    self._leader_elector.is_leader
                    if self._leader_elector
                    else False
                ),
                "consumer_threads": thread_status,
                "shutting_down": self._shutting_down,
            }

        @app.get("/metrics")
        async def metrics():
            """Prometheus metrics endpoint."""
            return PlainTextResponse(
                generate_latest(), media_type=CONTENT_TYPE_LATEST
            )

        return app

    def start(self) -> None:
        """Start the health server in a daemon thread."""
        self._thread = threading.Thread(
            target=self._run,
            name="health-server",
            daemon=True,
        )
        self._thread.start()
        logger.info(
            "Health server started",
            extra={"port": self._port},
        )

    def _run(self) -> None:
        config = uvicorn.Config(
            self._app,
            host="0.0.0.0",
            port=self._port,
            log_level="warning",
            access_log=False,
        )
        server = uvicorn.Server(config)
        server.run()
