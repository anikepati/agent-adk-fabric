"""
YAML Config Loader — loads and validates decision tree config at startup.
"""

import yaml
from pathlib import Path
from models.schemas import DecisionTreeConfig


def load_config(config_path: str) -> DecisionTreeConfig:
    """Load YAML config and validate against Pydantic schema."""
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with open(path, "r") as f:
        raw = yaml.safe_load(f)

    if not raw:
        raise ValueError(f"Empty config file: {config_path}")

    config = DecisionTreeConfig(**raw)
    return config
