# Implementation Plan: Resumable Sequential Pipeline

**Spec**: `specs/resumable-pipeline/spec.md`
**Constitution**: `memory/constitution.md`
**Status**: Ready for `/speckit tasks`

This plan derives every decision from the spec and the constitution.
The plan is deliberately small — Article IX (simplicity over generality)
constrains us to use only ADK primitives.

---

## 1. Architectural Overview

```
┌───────────────────────────────────────────────────────────────────┐
│                       Resume Caller                               │
│  POST  /resume/{session_id}  body={"decision": "approved"}        │
└───────────────────────────────────────────────────────────────────┘
                              │
                              │ session_service.append_event(
                              │   state_delta={"approval_decision": "approved"})
                              ▼
┌───────────────────────────────────────────────────────────────────┐
│                  DatabaseSessionService (SQLite / Postgres)       │
│  Persists every session.state mutation. Survives process death,   │
│  reboots, and arbitrary delays. Article III, NFR-1.               │
└───────────────────────────────────────────────────────────────────┘
                              │
                              │ runner.run_async(session_id=...)
                              ▼
┌───────────────────────────────────────────────────────────────────┐
│                     ResumableOrchestrator                         │
│  for sub in sub_agents:                                           │
│     if state[sub.output_key]: skip                                │
│     else:                                                         │
│        run(sub)                                                   │
│        if event.escalate:           stop                          │
│        if not state[sub.output_key]: pause                        │
└───────────────────────────────────────────────────────────────────┘
        │                  │                       │
        ▼                  ▼                       ▼
   LlmAgent ×N          AgentGate              LlmAgent ×M
   (pre-gate work)      (pause point)          (post-gate work)
```

Every box above maps to an ADK construct we already have. Nothing
custom except `ResumableOrchestrator` and `AgentGate`, both ~50 lines.

## 2. Module Layout

```
main.py                              the whole thing (~400 lines)
  ├── AgentGate(BaseAgent)            §3
  ├── ResumableOrchestrator(BaseAgent) §4
  ├── build_pipeline() → ResumableOrchestrator
  ├── build_app_and_runner() → (App, Runner)
  └── CLI: cmd_start, cmd_resume, cmd_status

memory/constitution.md
specs/resumable-pipeline/spec.md
specs/resumable-pipeline/plan.md   (this file)
tests/
  test_orchestrator.py              FR-1..FR-5, EC-3, EC-9
  test_agent_gate.py                FR-6..FR-9, EC-4..EC-7
  test_resume.py                    FR-10..FR-14, EC-1..EC-2
```

Article IX: one file unless we cross 700 lines or two unrelated
concerns emerge. Currently at ~440 lines.

## 3. AgentGate Design

```python
class AgentGate(BaseAgent):
    decision_key:    str       = "approval_decision"
    approved_values: list[str] = ["approved", "yes", "ok", "accept"]
    output_key:      str       = "gate_result"
```

Behavior table (covers FR-6 .. FR-9):

| state[decision_key]      | output_key written? | escalate? | Orchestrator sees |
|--------------------------|---------------------|-----------|-------------------|
| `None` / `""`            | no                  | no        | PAUSE             |
| `"approved"` / variant   | `"approved"`        | no        | DONE → next       |
| `"foo"` (not in list)    | `"denied"`          | **yes**   | STOP              |

The gate is the only place in the codebase that knows what "approved"
means (Article V). The orchestrator stays mechanical.

## 4. Orchestrator Design

The orchestrator's `_run_async_impl` is a single for-loop. Pseudocode:

```python
for sub in self.sub_agents:
    out_key = getattr(sub, "output_key", None)
    if out_key is None:
        raise RuntimeError(f"sub-agent {sub.name!r} must declare output_key")

    if state.get(out_key) is not None:
        emit "[skip] {sub.name}"
        continue

    emit "[run] {sub.name}"
    stop = False
    async for event in sub.run_async(ctx):
        yield event
        if event.actions and event.actions.escalate:
            stop = True

    if stop:
        emit "[stop] {sub.name}"
        return

    if state.get(out_key) is None:
        emit "[pause] {sub.name}"
        return

    emit "[done] {sub.name}"
```

Mapping to FRs: FR-1 (loop order), FR-2 (skip on output_key set),
FR-3 (raise on missing output_key), FR-4 (pause on output_key unset
after run), FR-5 (stop on escalate), FR-18 (log lines).

### 4.1 Permanent-stop sentinel (EC-3, OQ-2 → recommended Option B)

On stop, the orchestrator writes a sentinel:

```python
yield Event(
    author=self.name, invocation_id=ctx.invocation_id,
    actions=EventActions(state_delta={"__pipeline_halted__": True}),
)
return
```

At the top of `_run_async_impl`, the orchestrator checks the sentinel
first:

```python
if ctx.session.state.get("__pipeline_halted__"):
    emit "[halt] pipeline permanently halted"
    return
```

This makes the denied state sticky across resumes (EC-3 closed).

## 5. App and Runner Wiring

```python
def build_app_and_runner() -> tuple[App, Runner]:
    pipeline = build_pipeline()
    app = App(
        name="resumable_demo",
        root_agent=pipeline,
        resumability_config=ResumabilityConfig(is_resumable=True),  # FR-17
    )
    session_service = DatabaseSessionService(db_url=DB_URL)         # FR-15
    return app, Runner(app=app, session_service=session_service)
```

`DB_URL` for local dev is `sqlite:///~/.resumable_demo.db`. For prod it
is a Postgres URL injected via environment variable. ADK ≥ 1.21
enables `pool_pre_ping=True` by default for non-SQLite engines (NFR-2).

## 6. Resume Mechanism

Two-step, both on `session_service`:

1. **Inject decision** (`cmd_resume` → `cmd_resume` body):
   ```python
   await session_service.append_event(
       session,
       Event(
           author="human",
           invocation_id=str(uuid.uuid4()),
           actions=EventActions(state_delta={"approval_decision": decision}),
       ),
   )
   ```
   This persists the decision to the durable store. FR-11.

2. **Run the orchestrator**:
   ```python
   async for event in runner.run_async(
       user_id=USER_ID, session_id=session_id, new_message=...,
   ):
       ...
   ```
   The orchestrator skips every sub-agent whose `output_key` is in
   `session.state` and re-enters the gate. FR-12 / FR-13 / FR-14.

Resume requires no token store, no opaque identifiers — only the
session_id (Article VII, NFR-4).

## 7. Status Helper

```python
async def _status(session_service, session_id) -> dict:
    session = await session_service.get_session(...)
    state = session.state or {}
    return {
        "paused":  state.get("gate_result") is None
                   and state.get("review_summary") is not None,
        "stopped": state.get("__pipeline_halted__") is True,
        "done":    state.get("final_verdict") is not None,
    }
```

Read-only, no orchestrator invocation (FR-19, NFR-3).

## 8. Framework Decisions

| Concern                     | Choice                                  | Rationale                |
|-----------------------------|-----------------------------------------|--------------------------|
| ADK version                 | `google-adk >= 1.21.0, < 2.0.0`         | Async DB session, pool_pre_ping default, JSON schema. Upper bound until v2 migration documented. |
| Session persistence (dev)   | `DatabaseSessionService(sqlite:///...)` | Article III              |
| Session persistence (prod)  | `DatabaseSessionService(postgresql://...)` | Article III + NFR-2   |
| Custom tables               | none                                    | Article I, Article IX    |
| Resume tokens               | none                                    | Article VII, NFR-4       |
| Audit                       | ADK session event log + structured logs | Article I                |
| Migration tool              | `adk migrate session` invoked from deploy script | EC-11, OQ-3      |
| Testing                     | pytest + pytest-asyncio, BaseAgent stubs | Article X               |

Rejected alternatives:

- **Custom ledger / pause-store tables.** Rejected per Article I. ADK's
  session table already records every state mutation; we have no need
  for parallel storage.
- **Opaque resume tokens.** Rejected per Article VII; the session_id
  is the durable handle.
- **`LongRunningFunctionTool`-based pause.** Rejected because it
  couples the pause primitive to LLM tool calls, which the deterministic
  gate doesn't use. Output_key absence is a simpler, agent-agnostic
  pause signal.

## 9. Roll-Out Plan

- **Phase 1.** Single-file `main.py` + tests. Local SQLite.
- **Phase 2.** Switch `DB_URL` to managed Postgres for staging; run
  `adk migrate session` against any pre-existing SQLite DBs.
- **Phase 3.** Production cutover. Add Prometheus counters for
  `[run]/[done]/[skip]/[pause]/[stop]` log lines via a log shipper.
- **Phase 4 (deferred).** Multi-gate pipelines (OQ-1); typed decision
  payloads.

## 10. Test Strategy

Tests are organized one-per-FR, one-per-EC. All run without LLM access
(Article X). A typical orchestrator test:

```python
async def test_FR4_pause_when_output_key_unset():
    # Build a pipeline with two stub agents; the second never sets its key.
    pipeline = ResumableOrchestrator(name="t", sub_agents=[
        StubAgent(name="a", output_key="a_out", write="ok"),
        StubAgent(name="b", output_key="b_out", write=None),
        StubAgent(name="c", output_key="c_out", write="should-not-run"),
    ])
    # Run with InMemoryRunner; assert c never ran.
    ...
    assert state["a_out"] == "ok"
    assert state.get("b_out") is None
    assert state.get("c_out") is None
```

Resume tests use `DatabaseSessionService` against an in-memory SQLite
file (`sqlite:///:memory:` is not durable across processes — for the
40-day test we mock the clock and reload the engine).

## 11. Traceability Matrix

| Spec ID  | Plan §        | Code (file:symbol)                          |
|----------|---------------|---------------------------------------------|
| FR-1     | §4            | `main.py:ResumableOrchestrator._run_async_impl` |
| FR-2     | §4            | same — `if state.get(out_key) is not None`  |
| FR-3     | §4            | same — `if out_key is None: raise`          |
| FR-4     | §4            | same — `if state.get(out_key) is None`      |
| FR-5     | §4            | same — `if event.actions.escalate`          |
| FR-6..9  | §3            | `main.py:AgentGate._run_async_impl`         |
| FR-10..14| §6            | `main.py:cmd_resume`                        |
| FR-15..17| §5            | `main.py:build_app_and_runner`              |
| FR-18    | §4            | `print(f"  [skip|run|done|pause|stop] ...")` |
| FR-19    | §7            | `main.py:_status`                           |
| EC-3     | §4.1          | `__pipeline_halted__` sentinel              |
| EC-6     | §3            | `AgentGate` prefix match                    |
| EC-11    | §8            | deploy-script invocation of `adk migrate session` |
| NFR-1,2  | §5, §8        | DatabaseSessionService + ADK ≥ 1.21         |
| NFR-4    | §6            | no token store; session_id is the handle    |
