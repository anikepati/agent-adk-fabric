"""
Dead Letter Queue producer. Writes failed messages to DLQ topics
with forensic headers for debugging and replay.
"""
from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from confluent_kafka import Producer

from app.core.message import ConsumerMessage

if TYPE_CHECKING:
    from app.config.models import ClusterConfig

logger = logging.getLogger(__name__)


class DLQProducer:
    """Produces messages to DLQ topics on the same Kafka cluster."""

    def __init__(self, cluster_name: str, cluster_config: ClusterConfig) -> None:
        self._cluster_name = cluster_name
        self._producer = Producer(cluster_config.build_producer_params())
        self._pod_name = os.environ.get("HOSTNAME", "unknown")
        self._ocp_cluster = os.environ.get("OCP_CLUSTER", "unknown")
        logger.info("DLQ producer initialized", extra={"cluster": cluster_name})

    def send(
        self,
        message: ConsumerMessage,
        dlq_topic: str,
        error: str,
        processor: str,
        retry_count: int,
        trace_id: str = "",
    ) -> None:
        """Send a message to the DLQ with forensic headers."""
        headers = {
            "x-original-topic": message.topic,
            "x-original-partition": str(message.partition),
            "x-original-offset": str(message.offset),
            "x-failure-reason": error[:500],  # Truncate long errors
            "x-failure-timestamp": datetime.now(timezone.utc).isoformat(),
            "x-retry-count": str(retry_count),
            "x-processor": processor,
            "x-trace-id": trace_id,
            "x-consumer-pod": self._pod_name,
            "x-ocp-cluster": self._ocp_cluster,
            "x-cluster-name": self._cluster_name,
        }

        # Merge original headers
        for k, v in message.headers.items():
            if not k.startswith("x-"):
                headers[f"x-orig-{k}"] = v

        try:
            self._producer.produce(
                topic=dlq_topic,
                key=message.key,
                value=message.raw_value,
                headers=[(k, v.encode()) for k, v in headers.items()],
                callback=self._delivery_callback,
            )
            self._producer.poll(0)  # Trigger delivery callbacks
            logger.warning(
                "Message sent to DLQ",
                extra={
                    "dlq_topic": dlq_topic,
                    "original_topic": message.topic,
                    "partition": message.partition,
                    "offset": message.offset,
                    "error": error[:200],
                },
            )
        except Exception as e:
            logger.error(
                "Failed to send message to DLQ",
                extra={
                    "dlq_topic": dlq_topic,
                    "original_topic": message.topic,
                    "error": str(e),
                },
            )

    def flush(self, timeout: float = 10.0) -> None:
        remaining = self._producer.flush(timeout)
        if remaining > 0:
            logger.warning(
                "DLQ producer flush incomplete",
                extra={"remaining_messages": remaining, "cluster": self._cluster_name},
            )

    def _delivery_callback(self, err: Any, msg: Any) -> None:
        if err:
            logger.error(
                "DLQ delivery failed",
                extra={"error": str(err), "topic": msg.topic() if msg else "unknown"},
            )
