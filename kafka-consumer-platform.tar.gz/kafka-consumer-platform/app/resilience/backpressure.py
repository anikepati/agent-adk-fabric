"""
Backpressure controller using a semaphore to limit in-flight messages.
Coordinates with Kafka consumer pause/resume to prevent poll timeout.
"""
from __future__ import annotations

import logging
from threading import Semaphore

logger = logging.getLogger(__name__)


class BackpressureController:
    """Controls the rate of message submission to the worker pool."""

    def __init__(self, max_in_flight: int) -> None:
        self._semaphore = Semaphore(max_in_flight)
        self._max = max_in_flight
        self._in_flight = 0

    def acquire(self, timeout: float = 0.1) -> bool:
        """Try to acquire a slot. Returns True if acquired."""
        acquired = self._semaphore.acquire(timeout=timeout)
        if acquired:
            self._in_flight += 1
        return acquired

    def acquire_blocking(self) -> None:
        """Block until a slot is available."""
        self._semaphore.acquire(blocking=True)
        self._in_flight += 1

    def release(self) -> None:
        """Release a slot after processing completes."""
        self._in_flight -= 1
        self._semaphore.release()

    @property
    def in_flight_count(self) -> int:
        return self._in_flight

    @property
    def utilization(self) -> float:
        return self._in_flight / self._max if self._max > 0 else 0.0
