"""
tools/context_loader.py
========================
Loads all five data sources and builds the session state dict
that will be passed to the ADK Runner via state_delta.

Session state keys populated:
    case_id                       — the case identifier
    ecar                          — ECaR DB record
    si_primary                    — Security Instrument (authoritative)
    si_compare                    — Security Instrument (compare / 2nd source)
    title_primary                 — Title Report (authoritative)
    title_compare                 — Title Report (compare / 2nd source)

Each agent reads what it needs via {key} placeholders in its instruction.
"""

import json
from pathlib import Path
from typing import Optional

_DATA_DIR = Path(__file__).parent.parent / "data" / "sample_inputs"


def _load(filename: str, root_key: str) -> dict:
    with open(_DATA_DIR / filename) as f:
        return {r["case_id"]: r for r in json.load(f)[root_key]}


def build_session_state(case_id: str) -> Optional[dict]:
    """
    Returns the initial session state for a given case_id,
    containing all five source documents keyed for agent access.

    Returns None if case_id is not found in the ECaR extract.
    """
    ecar         = _load("ecar_db.json",                     "ecar_extract")
    si_primary   = _load("security_instrument_primary.json", "security_instruments_primary")
    si_compare   = _load("security_instrument_compare.json", "security_instruments_compare")
    title_primary = _load("title_report_primary.json",        "title_reports_primary")
    title_compare = _load("title_report_compare.json",        "title_reports_compare")

    if case_id not in ecar:
        return None

    return {
        "case_id":       case_id,
        "ecar":          ecar.get(case_id, {}),
        "si_primary":    si_primary.get(case_id, {}),
        "si_compare":    si_compare.get(case_id, {}),
        "title_primary": title_primary.get(case_id, {}),
        "title_compare": title_compare.get(case_id, {}),
    }


def list_cases() -> list[str]:
    """Returns all available case_ids from the ECaR extract."""
    with open(_DATA_DIR / "ecar_db.json") as f:
        return [r["case_id"] for r in json.load(f)["ecar_extract"]]
