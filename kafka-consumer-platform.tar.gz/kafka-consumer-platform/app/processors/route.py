"""
Route processor: conditional dispatch based on message content.
Evaluates rules in order; first matching rule's processor handles the message.
Falls back to default_processor if no rules match.
"""
from __future__ import annotations

import logging
from typing import Any

import jmespath

from app.core.message import ConsumerMessage
from app.core.result import ProcessorResult
from app.processors.base import BaseProcessor, ProcessorContext
from app.processors.registry import create_processor, register_processor

logger = logging.getLogger(__name__)


@register_processor("route")
class RouteProcessor(BaseProcessor):

    def __init__(self, config: dict[str, Any], context: ProcessorContext) -> None:
        super().__init__(config, context)
        self._rules: list[dict[str, Any]] = config.get("rules", [])
        self._default_config: dict[str, Any] | None = config.get("default")
        self._compiled_rules: list[tuple[Any, BaseProcessor]] = []
        self._default_processor: BaseProcessor | None = None

    async def startup(self) -> None:
        for i, rule in enumerate(self._rules):
            condition = jmespath.compile(rule["condition"])
            proc = create_processor(
                processor_type=rule["processor"]["type"],
                config=rule["processor"].get("config", {}),
                cluster_name=self.context.cluster_name,
                topic=f"{self.context.topic}:route-{i}",
            )
            await proc.startup()
            self._compiled_rules.append((condition, proc))

        if self._default_config:
            self._default_processor = create_processor(
                processor_type=self._default_config["type"],
                config=self._default_config.get("config", {}),
                cluster_name=self.context.cluster_name,
                topic=f"{self.context.topic}:route-default",
            )
            await self._default_processor.startup()

    async def process(self, message: ConsumerMessage) -> ProcessorResult:
        if not self._compiled_rules and self._rules:
            await self.startup()

        data = message.value if isinstance(message.value, dict) else {}

        for condition, processor in self._compiled_rules:
            if condition.search(data):
                return await processor.process(message)

        if self._default_processor:
            return await self._default_processor.process(message)

        return ProcessorResult.skip("No matching route and no default processor")

    async def shutdown(self) -> None:
        for _, proc in self._compiled_rules:
            await proc.shutdown()
        if self._default_processor:
            await self._default_processor.shutdown()
