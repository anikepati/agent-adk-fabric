"""
Bootstrap: reads YAML config and builds the entire runtime topology.
Creates ConsumerThread per cluster, instantiates processors per topic,
builds the shared WorkerPool, and wires everything together.
"""
from __future__ import annotations

import asyncio
import logging
import threading
from concurrent.futures import ThreadPoolExecutor

from app.config.models import AppConfig
from app.core.consumer_thread import ConsumerThread
from app.core.topic_map import TopicMap
from app.core.worker_pool import WorkerPool
from app.observability.health import HealthServer
from app.observability.metrics import APP_INFO, WORKER_POOL_UTILIZATION
from app.processors.registry import create_processor, discover_processors, get_registered_types
from app.resilience.backpressure import BackpressureController

logger = logging.getLogger(__name__)


class ApplicationContext:
    """Holds all runtime components created by bootstrap."""

    def __init__(self) -> None:
        self.config: AppConfig | None = None
        self.worker_pool: WorkerPool | None = None
        self.consumer_threads: list[ConsumerThread] = []
        self.health_server: HealthServer | None = None
        self.shutdown_event = threading.Event()
        self.backpressure: BackpressureController | None = None


def bootstrap(config: AppConfig) -> ApplicationContext:
    """Build the entire application from config. Returns ApplicationContext."""
    ctx = ApplicationContext()
    ctx.config = config

    # 1. Discover processor plugins
    discover_processors()
    registered = get_registered_types()
    logger.info(
        "Processor plugins discovered",
        extra={"registered_types": registered, "count": len(registered)},
    )

    # 2. Create shared worker pool
    ctx.worker_pool = WorkerPool(max_workers=config.worker_pool.max_workers)
    ctx.backpressure = BackpressureController(max_in_flight=config.worker_pool.max_workers)

    # 3. Create consumer threads — one per Kafka cluster
    loop = asyncio.new_event_loop()

    for cluster_name, cluster_config in config.clusters.items():
        if not cluster_config.topics:
            logger.warning(
                f"Cluster '{cluster_name}' has no topics configured, skipping"
            )
            continue

        # Build topic map for this cluster
        topic_map = TopicMap()
        valid_topics = []

        for tc in cluster_config.topics:
            try:
                processor = create_processor(
                    processor_type=tc.processor,
                    config=tc.processor_config,
                    cluster_name=cluster_name,
                    topic=tc.topic,
                )
                # Run async startup
                loop.run_until_complete(processor.startup())
                topic_map.register(tc.topic, processor)
                valid_topics.append(tc)
            except ValueError as e:
                logger.error(
                    f"Failed to create processor for topic '{tc.topic}': {e}. "
                    "Topic will be skipped."
                )
            except Exception as e:
                logger.error(
                    f"Processor startup failed for topic '{tc.topic}': {e}. "
                    "Topic will be skipped.",
                    exc_info=True,
                )

        if not valid_topics:
            logger.warning(
                f"No valid topics for cluster '{cluster_name}', "
                "skipping consumer thread"
            )
            continue

        # Create consumer thread
        consumer_thread = ConsumerThread(
            cluster_name=cluster_name,
            cluster_config=cluster_config,
            topic_configs=valid_topics,
            topic_map=topic_map,
            worker_pool=ctx.worker_pool.executor,
            backpressure=ctx.backpressure,
            shutdown_event=ctx.shutdown_event,
            dlq_suffix=config.defaults.dlq_suffix,
        )
        ctx.consumer_threads.append(consumer_thread)

        logger.info(
            "Consumer thread created",
            extra={
                "cluster": cluster_name,
                "group_id": cluster_config.group_id,
                "topics": [tc.topic for tc in valid_topics],
                "topic_count": len(valid_topics),
            },
        )

    loop.close()

    # 4. Create health server
    ctx.health_server = HealthServer(
        port=config.health.port,
        metrics_port=config.health.metrics_port,
    )
    ctx.health_server.register_consumer_threads(ctx.consumer_threads)

    # 5. Record app info metric
    APP_INFO.info({
        "clusters": str(len(config.clusters)),
        "topics": str(sum(len(c.topics) for c in config.clusters.values())),
        "worker_pool_size": str(config.worker_pool.max_workers),
    })

    total_topics = sum(len(ct.subscribed_topics) for ct in ctx.consumer_threads)
    logger.info(
        "Bootstrap complete",
        extra={
            "consumer_threads": len(ctx.consumer_threads),
            "total_topics": total_topics,
            "worker_pool_size": config.worker_pool.max_workers,
        },
    )

    return ctx
