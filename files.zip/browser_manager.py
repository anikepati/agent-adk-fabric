"""
Browser Manager — Playwright browser lifecycle with explicit resource ownership.

Design:
- Single browser instance reused across workflow executions
- Explicit page acquire / release — no leaking context managers
- Context isolation per page
- Auth state persistence
- Graceful shutdown with resource tracking
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional
import fnmatch

from playwright.async_api import (
    async_playwright,
    Browser,
    BrowserContext,
    Page,
    Playwright,
)

from core.models import BrowserConfig

logger = logging.getLogger("core.browser")


class BrowserManagerError(Exception):
    pass


class BrowserManager:
    """
    Manages Playwright browser lifecycle.

    Usage:
        mgr = BrowserManager(config)
        await mgr.initialize()
        page = await mgr.new_page()
        # ... use page ...
        await mgr.close_page(page)
        await mgr.shutdown()
    """

    def __init__(self, config: BrowserConfig):
        self._config = config
        self._pw: Optional[Playwright] = None
        self._browser: Optional[Browser] = None
        self._contexts: dict[int, BrowserContext] = {}
        self._initialized = False

    # ── lifecycle ──────────────────────────────────────────────

    async def initialize(self) -> None:
        if self._initialized:
            return

        logger.info(
            "Launching %s (headless=%s)",
            self._config.engine,
            self._config.headless,
        )
        self._pw = await async_playwright().start()
        launcher = getattr(self._pw, self._config.engine, None)
        if launcher is None:
            raise BrowserManagerError(f"Unknown browser engine: {self._config.engine}")

        self._browser = await launcher.launch(headless=self._config.headless)
        self._initialized = True
        logger.info("Browser ready")

    async def new_page(self) -> Page:
        """Create an isolated Page inside a fresh BrowserContext."""
        if not self._initialized:
            await self.initialize()

        ctx_opts: dict = {
            "viewport": {
                "width": self._config.viewport_width,
                "height": self._config.viewport_height,
            },
        }
        if self._config.storage_state_path:
            sp = Path(self._config.storage_state_path)
            if sp.exists():
                ctx_opts["storage_state"] = str(sp)
                logger.info("Loaded auth state from %s", sp)

        if self._config.record_video:
            Path(self._config.screenshot_dir).mkdir(parents=True, exist_ok=True)
            ctx_opts["record_video_dir"] = self._config.screenshot_dir

        context = await self._browser.new_context(**ctx_opts)

        if self._config.blocked_patterns:
            patterns = self._config.blocked_patterns
            await context.route(
                lambda url: any(fnmatch.fnmatch(url.url, p) for p in patterns),
                lambda route: route.abort(),
            )

        page = await context.new_page()
        page.set_default_timeout(self._config.default_timeout_ms)
        page.set_default_navigation_timeout(self._config.navigation_timeout_ms)

        self._contexts[id(page)] = context
        return page

    async def close_page(self, page: Page) -> None:
        ctx = self._contexts.pop(id(page), None)
        if ctx:
            try:
                await ctx.close()
            except Exception as exc:
                logger.warning("Error closing context: %s", exc)

    async def save_auth_state(self, page: Page, path: Optional[str] = None) -> None:
        target = path or self._config.storage_state_path
        if not target:
            raise BrowserManagerError("No storage_state_path configured")
        Path(target).parent.mkdir(parents=True, exist_ok=True)
        await page.context.storage_state(path=target)
        logger.info("Auth state saved → %s", target)

    async def shutdown(self) -> None:
        for ctx in list(self._contexts.values()):
            try:
                await ctx.close()
            except Exception:
                pass
        self._contexts.clear()

        if self._browser:
            try:
                await self._browser.close()
            except Exception as exc:
                logger.warning("Browser close error: %s", exc)
            self._browser = None

        if self._pw:
            try:
                await self._pw.stop()
            except Exception as exc:
                logger.warning("Playwright stop error: %s", exc)
            self._pw = None

        self._initialized = False
        logger.info("Browser manager shut down")

    @property
    def is_initialized(self) -> bool:
        return self._initialized
