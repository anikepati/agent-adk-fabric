"""
Leader duties: singleton tasks that run only on the leader pod.
DLQ monitoring, consumer lag aggregation, partition assignment audit.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import TYPE_CHECKING

from app.observability import metrics as m

if TYPE_CHECKING:
    from app.config.models import AppConfig
    from app.core.consumer_thread import ConsumerThread

logger = logging.getLogger(__name__)


class LeaderDuties:
    """Runs singleton observability tasks on the leader pod."""

    def __init__(
        self,
        config: AppConfig,
        consumer_threads: list[ConsumerThread],
        shutdown_event: threading.Event,
    ) -> None:
        self._config = config
        self._consumer_threads = consumer_threads
        self._shutdown_event = shutdown_event
        self._thread: threading.Thread | None = None
        self._running = False

    def start(self) -> None:
        """Start leader duties in a background thread."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._duty_loop,
            name="leader-duties",
            daemon=True,
        )
        self._thread.start()
        logger.info("Leader duties started")

    def stop(self) -> None:
        """Stop leader duties."""
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=5)
        logger.info("Leader duties stopped")

    def _duty_loop(self) -> None:
        """Main duty loop: runs tasks periodically."""
        while self._running and not self._shutdown_event.is_set():
            try:
                self._monitor_consumer_lag()
                self._audit_partition_assignments()
            except Exception as e:
                logger.error(f"Leader duty error: {e}", exc_info=True)

            # Wait 30 seconds between duty cycles
            self._shutdown_event.wait(timeout=30)

    def _monitor_consumer_lag(self) -> None:
        """Query Kafka AdminClient for consumer group lag."""
        for ct in self._consumer_threads:
            try:
                if not ct.is_alive() or not ct._consumer:
                    continue

                # Use the consumer's committed and highwater offsets
                assignment = ct._consumer.assignment()
                for tp in assignment:
                    try:
                        committed = ct._consumer.committed([tp])
                        if committed and committed[0] and committed[0].offset >= 0:
                            _, high = ct._consumer.get_watermark_offsets(tp)
                            lag = high - committed[0].offset
                            m.CONSUMER_LAG.labels(
                                cluster=ct.cluster_name,
                                group_id=ct._cluster_config.group_id,
                                topic=tp.topic,
                                partition=str(tp.partition),
                            ).set(lag)
                    except Exception:
                        pass  # Skip partitions we can't query

            except Exception as e:
                logger.debug(f"Lag monitoring error for {ct.cluster_name}: {e}")

    def _audit_partition_assignments(self) -> None:
        """Log partition assignments for debugging."""
        for ct in self._consumer_threads:
            assignments = ct.assigned_partitions_info
            if assignments:
                logger.debug(
                    "Partition assignment audit",
                    extra={
                        "cluster": ct.cluster_name,
                        "thread": ct.name,
                        "partitions": assignments,
                        "count": len(assignments),
                    },
                )
