"""Tests for core.param_resolver."""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from core.param_resolver import (
    resolve_params,
    find_placeholders,
    validate_params,
    ParamResolutionError,
)


class TestResolveParams:
    def test_simple_substitution(self):
        result = resolve_params("page.goto('{url}')", {"url": "https://example.com"})
        assert result == "page.goto('https://example.com')"

    def test_multiple_placeholders(self):
        t = 'page.fill("{sel}", "{val}")'
        r = resolve_params(t, {"sel": "#name", "val": "ACME"})
        assert r == 'page.fill("#name", "ACME")'

    def test_repeated_placeholder(self):
        t = "{x} and {x}"
        r = resolve_params(t, {"x": "hello"})
        assert r == "hello and hello"

    def test_unresolved_raises(self):
        with pytest.raises(ParamResolutionError, match="missing_param"):
            resolve_params("{missing_param}", {})

    def test_special_chars_escaped(self):
        r = resolve_params("{v}", {"v": 'He said "hi"'})
        assert '\\"' in r

    def test_empty_value(self):
        r = resolve_params("{v}", {"v": ""})
        assert r == ""

    def test_numeric_value(self):
        r = resolve_params("{n}", {"n": 42})
        assert r == "42"


class TestFindPlaceholders:
    def test_finds_all(self):
        p = find_placeholders("{a} {b} {a}")
        assert sorted(p) == ["a", "b"]

    def test_none(self):
        assert find_placeholders("no placeholders here") == []


class TestValidateParams:
    def test_all_present(self):
        r = validate_params({"a": 1, "b": 2}, ["a", "b"])
        assert r == {"a": 1, "b": 2}

    def test_missing(self):
        with pytest.raises(ParamResolutionError, match="c"):
            validate_params({"a": 1}, ["a", "c"])

    def test_optional_defaults(self):
        r = validate_params({"a": 1}, ["a"], {"b": 99})
        assert r == {"a": 1, "b": 99}

    def test_provided_overrides_default(self):
        r = validate_params({"a": 1, "b": 2}, ["a"], {"b": 99})
        assert r["b"] == 2
